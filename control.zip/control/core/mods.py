import os, sys, json, time
from control.core.shared import CFG, cl, A, download_file, show_icon

def get_mods():
    md = os.path.join(CFG['server_dir'], 'mods')
    if not os.path.exists(md):
        return []
    return sorted([f for f in os.listdir(md) if f.endswith('.jar')])

def mr_search(query, limit=15):
    import urllib.request, urllib.parse, json
    try:
        url = f"https://api.modrinth.com/v2/search?query={urllib.parse.quote(query)}&limit={limit}"
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        return data.get('hits', [])
    except:
        return []

def mr_versions(proj_id):
    import urllib.request, json
    try:
        url = f"https://api.modrinth.com/v2/project/{proj_id}/version"
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read())
    except:
        return []

def mr_install(version_id, dest):
    import urllib.request, json
    try:
        url = f"https://api.modrinth.com/v2/version/{version_id}"
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        for fi in data.get('files', []):
            dl = fi.get('url')
            if dl:
                fn = fi.get('filename', 'mod.jar')
                fp = os.path.join(dest, fn)
                ok = download_file(dl, fp)
                if ok:
                    return True, fn
                return False, "Error de descarga"
        return False, "No hay archivos"
    except Exception as e:
        return False, str(e)

def mr_project(proj_id):
    import urllib.request, json
    try:
        url = f"https://api.modrinth.com/v2/project/{proj_id}"
        with urllib.request.urlopen(url, timeout=10) as r:
            return json.loads(r.read())
    except:
        return {}

CF_API_BASE = "https://api.curseforge.com/v1"

def cf_get_api_key():
    k = CFG.get('curseforge_api_key', '') or os.environ.get('CURSEFORGE_API_KEY', '')
    if k:
        return k
    return "$2a$10$t2BUHi3wKkiMw1YEqItui.XaHDvw4yMLK2peaKGkI9ufv3IsYRlkW"

def cf_headers():
    return {"User-Agent": "Mozilla/5.0", "Accept": "application/json",
            "X-API-KEY": cf_get_api_key()}

def cf_request(url):
    import urllib.request, json
    req = urllib.request.Request(url, headers=cf_headers())
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())

def cf_search(query, limit=15):
    import urllib.parse
    try:
        url = f"{CF_API_BASE}/mods/search?gameId=432&searchFilter={urllib.parse.quote(query)}&index=0&pageSize={limit}&sortField=6&sortOrder=desc"
        data = cf_request(url)
        return data.get('data', [])
    except:
        return []

def cf_files(mod_id, game_version=""):
    try:
        url = f"{CF_API_BASE}/mods/{mod_id}/files?pageSize=50"
        if game_version:
            url += f"&gameVersion={game_version}"
        data = cf_request(url)
        return data.get('data', [])
    except:
        return []

def cf_download_url(mod_id, file_id):
    try:
        url = f"{CF_API_BASE}/mods/{mod_id}/files/{file_id}/download-url"
        data = cf_request(url)
        return data.get('data', '')
    except:
        return ""

def cf_install(mod_id, file_id, dest, filename=""):
    dl_url = cf_download_url(mod_id, file_id)
    if not dl_url:
        return False, "No se pudo obtener URL de descarga"
    try:
        fn = filename or f"curseforge_{mod_id}_{file_id}.jar"
        fp = os.path.join(dest, fn)
        ok = download_file(dl_url, fp)
        if ok:
            return True, fn
        return False, "Error de descarga"
    except Exception as e:
        return False, str(e)

def spigot_search(query, limit=20):
    import urllib.request, urllib.parse, json
    try:
        url = f"https://api.spiget.org/v2/search/resources/{urllib.parse.quote(query)}?size={limit}&field=name"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except:
        return []

def spigot_resource(rid):
    import urllib.request, json
    try:
        url = f"https://api.spiget.org/v2/resources/{rid}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except:
        return {}

def spigot_versions(rid, limit=30):
    import urllib.request, json
    try:
        url = f"https://api.spiget.org/v2/resources/{rid}/versions?size={limit}"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read())
    except:
        return []

def spigot_install(rid, version_name, dest):
    import urllib.request, re
    try:
        url = f"https://api.spiget.org/v2/resources/{rid}/download"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as r:
            cd = r.headers.get('Content-Disposition', '')
            m = re.search(r'filename="?([^"]+)"?', cd)
            fn = m.group(1) if m else f"plugin_{rid}.jar"
            fp = os.path.join(dest, fn)
            ok = download_file(url, fp)
            if ok:
                return True, fn
            return False, "Error de descarga"
    except Exception as e:
        return False, str(e)

def clean_spiget_desc(raw):
    import re, base64
    if not raw:
        return ''
    try:
        decoded = base64.b64decode(raw).decode('utf-8', errors='replace')
        clean = re.sub(r'<[^>]+>', '', decoded)
        clean = clean.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&nbsp;', ' ')
        return clean.strip()
    except:
        return raw.strip()

def is_plugin_server():
    ml = CFG.get('mod_loader', 'auto')
    return ml in ('paper', 'spigot', 'purpur', 'bukkit', 'mohist', 'catserver', 'arclight', 'magma',
                  'pufferfish', 'tuinity', 'spongevanilla', 'spongeforge', 'cardboard', 'banner')