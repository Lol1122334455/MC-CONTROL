import os, json, time, datetime, threading, re
from control.core.shared import CFG, BASE_DIR, cl, A, clear, draw_header, get_size, get_key, read_text, notify, toast, confirm, save_config, IS_WIN
from control.core.server import send_cmd, get_pid

CRON_TASKS_FILE = os.path.join(BASE_DIR, "cron_tasks.json")
_cron_thread = None
_cron_running = False

def parse_cron(expr):
    fields = expr.strip().split()
    if len(fields) != 5:
        return None
    result = {}
    names = ['minute', 'hour', 'day', 'month', 'weekday']
    ranges = [(0, 59), (0, 23), (1, 31), (1, 12), (0, 6)]
    for i, field in enumerate(fields):
        lo, hi = ranges[i]
        values = set()
        for part in field.split(','):
            part = part.strip()
            if part == '*':
                values.update(range(lo, hi + 1))
            elif '/' in part:
                base, step = part.split('/', 1)
                step = int(step)
                if base == '*':
                    start = lo
                else:
                    start = int(base)
                values.update(range(start, hi + 1, step))
            elif '-' in part:
                a, b = part.split('-', 1)
                values.update(range(int(a), int(b) + 1))
            else:
                values.add(int(part))
        result[names[i]] = sorted(values)
    return result

def cron_matches(expr, dt):
    parsed = parse_cron(expr)
    if not parsed:
        return False
    checks = [
        (parsed['minute'], dt.minute),
        (parsed['hour'], dt.hour),
        (parsed['day'], dt.day),
        (parsed['month'], dt.month),
        (parsed['weekday'], dt.weekday()),
    ]
    for allowed, actual in checks:
        if actual not in allowed:
            return False
    return True

def load_cron_tasks():
    try:
        if os.path.exists(CRON_TASKS_FILE):
            with open(CRON_TASKS_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return []

def save_cron_tasks(tasks):
    with open(CRON_TASKS_FILE, 'w') as f:
        json.dump(tasks, f, indent=2)

def _execute_cron_task(task):
    cmd = task.get('command', '')
    if cmd == 'backup':
        from control.core.backup import create_backup
        create_backup()
    elif cmd == 'restart':
        from control.core.server import stop, start
        stop()
        time.sleep(3)
        start()
    elif cmd.startswith('broadcast:'):
        text = cmd[len('broadcast:'):]
        send_cmd(f'say {text}')
    else:
        send_cmd(cmd)

def cron_scheduler_loop():
    global _cron_running
    _cron_running = True
    while _cron_running:
        try:
            if get_pid():
                now = datetime.datetime.now()
                tasks = load_cron_tasks()
                changed = False
                for task in tasks:
                    if not task.get('enabled'):
                        continue
                    if cron_matches(task.get('cron', ''), now):
                        last_run = task.get('last_run')
                        if last_run:
                            try:
                                lr = datetime.datetime.fromisoformat(last_run)
                                if (now - lr).total_seconds() < 60:
                                    continue
                            except:
                                pass
                        _execute_cron_task(task)
                        task['last_run'] = now.isoformat()
                        changed = True
                if changed:
                    save_cron_tasks(tasks)
        except:
            pass
        time.sleep(60)

def start_cron_scheduler():
    global _cron_thread
    if _cron_thread and _cron_thread.is_alive():
        return
    _cron_thread = threading.Thread(target=cron_scheduler_loop, daemon=True)
    _cron_thread.start()

def stop_cron_scheduler():
    global _cron_running
    _cron_running = False

def cron_task_menu():
    start_cron_scheduler()
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "Cron Scheduler", "Tareas programadas con expresiones cron")
        tasks = load_cron_tasks()
        y = 5
        if not tasks:
            print(f'\033[{y};2H{cl("k")}No hay tareas programadas{A["0"]}')
            y += 2
        else:
            for i, task in enumerate(tasks):
                status = f'{cl("G")}ON{A["0"]}' if task.get('enabled') else f'{cl("R")}OFF{A["0"]}'
                name = task.get('name', 'Sin nombre')[:30]
                cron_expr = task.get('cron', '')
                cmd = task.get('command', '')[:20]
                line = f'  {cl("c")}{i+1}.{A["0"]} {status} {cl("w")}{name}{A["0"]} {cl("k")}{cron_expr}{A["0"]} -> {cl("y")}{cmd}{A["0"]}'
                print(f'\033[{y};0H{line}')
                y += 1
        y += 1
        print(f'\033[{y};2H{cl("G")}[A] Agregar tarea{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("Y")}[E] Editar tarea{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("R")}[D] Eliminar tarea{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("C")}[T] Activar/Desactivar{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("k")}[Q] Volver{A["0"]}')
        y += 2
        bo = cl("k")
        print(f'\033[{y};0H{bo}┌{"─"*(w-2)}┐{A["0"]}')
        y += 1
        inner = f' {cl("k")}Selecciona una opcion{A["0"]} '
        pad = w - 4 - len(inner)
        print(f'\033[{y};0H{bo}│{A["0"]}{inner}{" "*pad}{bo}│{A["0"]}')
        y += 1
        print(f'\033[{y};0H{bo}└{"─"*(w-2)}┘{A["0"]}')
        key = get_key()
        if key == 'q':
            return
        elif key == 'a':
            add_cron_task()
        elif key == 'e':
            edit_cron_task()
        elif key == 'd':
            delete_cron_task()
        elif key == 't':
            toggle_cron_task()

def add_cron_task():
    clear()
    cols = get_size()
    draw_header(1, "Agregar Tarea Cron", "Nueva tarea programada")
    y = 4
    name = read_text(f'\033[{y};2H{cl("w")}Nombre de la tarea: {A["0"]}')
    if not name:
        return
    y += 2
    print(f'\033[{y};2H{cl("w")}Tipo de comando:{A["0"]}')
    y += 1
    print(f'\033[{y};4H{cl("c")}[1]{A["0"]} Comando say')
    y += 1
    print(f'\033[{y};4H{cl("c")}[2]{A["0"]} Backup')
    y += 1
    print(f'\033[{y};4H{cl("c")}[3]{A["0"]} Reiniciar')
    y += 1
    print(f'\033[{y};4H{cl("c")}[4]{A["0"]} Comando personalizado')
    y += 2
    choice = read_text(f'\033[{y};2H{cl("w")}Selecciona (1-4): {A["0"]}', '1')
    if not choice:
        return
    command = ''
    if choice == '1':
        y += 2
        text = read_text(f'\033[{y};2H{cl("w")}Texto a enviar: {A["0"]}')
        if not text:
            return
        command = f'say {text}'
    elif choice == '2':
        command = 'backup'
    elif choice == '3':
        command = 'restart'
    elif choice == '4':
        y += 2
        cmd = read_text(f'\033[{y};2H{cl("w")}Comando: {A["0"]}')
        if not cmd:
            return
        command = cmd
    else:
        return
    y += 2
    print(f'\033[{y};2H{cl("w")}Horario:{A["0"]}')
    y += 1
    print(f'\033[{y};4H{cl("c")}[1]{A["0"]} Cada hora (0 * * * *)')
    y += 1
    print(f'\033[{y};4H{cl("c")}[2]{A["0"]} Cada 6 horas (0 */6 * * *)')
    y += 1
    print(f'\033[{y};4H{cl("c")}[3]{A["0"]} Cada 12 horas (0 */12 * * *)')
    y += 1
    print(f'\033[{y};4H{cl("c")}[4]{A["0"]} Diario a las 3am (0 3 * * *)')
    y += 1
    print(f'\033[{y};4H{cl("c")}[5]{A["0"]} Semanal domingos 4am (0 4 * * 0)')
    y += 1
    print(f'\033[{y};4H{cl("c")}[6]{A["0"]} Personalizado')
    y += 2
    sched = read_text(f'\033[{y};2H{cl("w")}Selecciona (1-6): {A["0"]}', '1')
    if not sched:
        return
    presets = {
        '1': '0 * * * *',
        '2': '0 */6 * * *',
        '3': '0 */12 * * *',
        '4': '0 3 * * *',
        '5': '0 4 * * 0',
    }
    if sched in presets:
        cron_expr = presets[sched]
    elif sched == '6':
        y += 2
        cron_expr = read_text(f'\033[{y};2H{cl("w")}Expresion cron (min hour day month weekday): {A["0"]}')
        if not cron_expr or not parse_cron(cron_expr):
            toast("Expresion cron invalida", 'r')
            return
    else:
        return
    task = {
        "id": str(int(time.time() * 1000)),
        "name": name,
        "cron": cron_expr,
        "command": command,
        "enabled": True,
        "last_run": None
    }
    tasks = load_cron_tasks()
    tasks.append(task)
    save_cron_tasks(tasks)
    toast(f"Tarea '{name}' creada", 'g')

def edit_cron_task():
    tasks = load_cron_tasks()
    if not tasks:
        toast("No hay tareas para editar", 'r')
        return
    clear()
    cols = get_size()
    draw_header(1, "Editar Tarea Cron", "")
    y = 4
    for i, task in enumerate(tasks):
        print(f'\033[{y};2H{cl("c")}{i+1}.{A["0"]} {cl("w")}{task.get("name", "?")}{A["0"]} -> {cl("y")}{task.get("command", "")}{A["0"]}')
        y += 1
    y += 1
    idx = read_text(f'\033[{y};2H{cl("w")}Numero de tarea: {A["0"]}')
    if not idx or not idx.isdigit():
        return
    idx = int(idx) - 1
    if idx < 0 or idx >= len(tasks):
        return
    task = tasks[idx]
    y += 2
    print(f'\033[{y};2H{cl("w")}Editando: {cl("c")}{task.get("name", "")}{A["0"]}')
    y += 1
    print(f'\033[{y};2H{cl("k")}Deja vacio para mantener el valor actual{A["0"]}')
    y += 2
    name = read_text(f'\033[{y};2H{cl("w")}Nombre [{task.get("name", "")}]: {A["0"]}')
    if name:
        task['name'] = name
    y += 2
    cron_expr = read_text(f'\033[{y};2H{cl("w")}Cron [{task.get("cron", "")}]: {A["0"]}')
    if cron_expr:
        if parse_cron(cron_expr):
            task['cron'] = cron_expr
        else:
            toast("Expresion cron invalida, no se cambio", 'r')
    y += 2
    cmd = read_text(f'\033[{y};2H{cl("w")}Comando [{task.get("command", "")}]: {A["0"]}')
    if cmd:
        task['command'] = cmd
    save_cron_tasks(tasks)
    toast("Tarea actualizada", 'g')

def delete_cron_task():
    tasks = load_cron_tasks()
    if not tasks:
        toast("No hay tareas para eliminar", 'r')
        return
    clear()
    cols = get_size()
    draw_header(1, "Eliminar Tarea Cron", "")
    y = 4
    for i, task in enumerate(tasks):
        print(f'\033[{y};2H{cl("c")}{i+1}.{A["0"]} {cl("w")}{task.get("name", "?")}{A["0"]} -> {cl("y")}{task.get("command", "")}{A["0"]}')
        y += 1
    y += 1
    idx = read_text(f'\033[{y};2H{cl("w")}Numero de tarea: {A["0"]}')
    if not idx or not idx.isdigit():
        return
    idx = int(idx) - 1
    if idx < 0 or idx >= len(tasks):
        return
    if confirm(f'\033[{y+2};2H{cl("R")}Eliminar "{tasks[idx].get("name", "")}"? (s/n): {A["0"]}'):
        removed = tasks.pop(idx)
        save_cron_tasks(tasks)
        toast(f"Tarea '{removed.get('name', '')}' eliminada", 'g')

def toggle_cron_task():
    tasks = load_cron_tasks()
    if not tasks:
        toast("No hay tareas para toggle", 'r')
        return
    clear()
    cols = get_size()
    draw_header(1, "Activar/Desactivar Tarea", "")
    y = 4
    for i, task in enumerate(tasks):
        status = f'{cl("G")}ON{A["0"]}' if task.get('enabled') else f'{cl("R")}OFF{A["0"]}'
        print(f'\033[{y};2H{cl("c")}{i+1}.{A["0"]} {status} {cl("w")}{task.get("name", "?")}{A["0"]}')
        y += 1
    y += 1
    idx = read_text(f'\033[{y};2H{cl("w")}Numero de tarea: {A["0"]}')
    if not idx or not idx.isdigit():
        return
    idx = int(idx) - 1
    if idx < 0 or idx >= len(tasks):
        return
    tasks[idx]['enabled'] = not tasks[idx]['enabled']
    save_cron_tasks(tasks)
    state = "activada" if tasks[idx]['enabled'] else "desactivada"
    toast(f"Tarea {state}", 'g')
