import os, sys, socket, threading, json
from control.core.shared import CFG, IS_WIN, cl, A, clear, draw_header, get_size, get_key, read_text, notify, confirm, BASE_DIR
from control.core.server import send_cmd, get_pid

_server_socket = None
_server_thread = None
_connections = []
_connections_lock = threading.Lock()
_running = False
_port = 25576

def _handle_client(conn, addr):
    global _connections
    try:
        with _connections_lock:
            _connections.append(conn)
        password = CFG.get('remote_console_password', '')
        authenticated = not password
        conn.sendall(f"MC Control Remote Console v1.0\n".encode())
        if password:
            conn.sendall(f"Password: ".encode())
            data = b""
            while b"\n" not in data and len(data) < 256:
                chunk = conn.recv(256)
                if not chunk:
                    return
                data += chunk
            input_pass = data.decode().strip()
            if input_pass != password:
                conn.sendall(f"Autenticacion fallida.\n".encode())
                return
            conn.sendall(f"Autenticado.\n".encode())
        while True:
            data = b""
            while b"\n" not in data and len(data) < 1024:
                chunk = conn.recv(1024)
                if not chunk:
                    return
                data += chunk
            line = data.decode().strip()
            if not line:
                continue
            if line.lower() == 'quit':
                conn.sendall(f"Conexion cerrada.\n".encode())
                break
            if line.lower() == 'status':
                pid = get_pid()
                if pid:
                    resp = f"Servidor: ONLINE (PID {pid})\n"
                else:
                    resp = f"Servidor: OFFLINE\n"
                conn.sendall(resp.encode())
                continue
            result = send_cmd(line)
            if result:
                conn.sendall(f"Comando enviado.\n".encode())
            else:
                conn.sendall(f"Error: no se pudo enviar el comando.\n".encode())
    except:
        pass
    finally:
        with _connections_lock:
            if conn in _connections:
                _connections.remove(conn)
        try:
            conn.close()
        except:
            pass

def start_remote_console(port=25576):
    global _server_socket, _server_thread, _running, _port
    if _running:
        return False, "Ya esta corriendo"
    _port = port
    try:
        _server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        _server_socket.bind(('0.0.0.0', port))
        _server_socket.listen(5)
        _running = True
        def accept_loop():
            while _running:
                try:
                    conn, addr = _server_socket.accept()
                    t = threading.Thread(target=_handle_client, args=(conn, addr), daemon=True)
                    t.start()
                except:
                    if not _running:
                        break
        _server_thread = threading.Thread(target=accept_loop, daemon=True)
        _server_thread.start()
        return True, f"Consola remota iniciada en puerto {port}"
    except Exception as e:
        _running = False
        return False, f"Error: {e}"

def stop_remote_console():
    global _server_socket, _running
    if not _running:
        return False, "No esta corriendo"
    _running = False
    try:
        _server_socket.close()
    except:
        pass
    with _connections_lock:
        for conn in _connections[:]:
            try:
                conn.close()
            except:
                pass
        _connections.clear()
    return True, "Consola remota detenida"

def get_remote_console_status():
    return {
        "running": _running,
        "port": _port,
        "connections": len(_connections)
    }

def remote_console_menu():
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "Consola Remota", "Servidor TCP para comandos remotos")
        status = get_remote_console_status()
        y = 4
        state = f'{cl("G")}ACTIVA{A["0"]}' if status['running'] else f'{cl("R")}INACTIVA{A["0"]}'
        print(f'\033[{y};2H{cl("w")}Estado: {state}{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("w")}Puerto: {cl("c")}{status["port"]}{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("w")}Conexiones: {cl("c")}{status["connections"]}{A["0"]}')
        y += 1
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect(('8.8.8.8', 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            local_ip = '127.0.0.1'
        print(f'\033[{y};2H{cl("w")}IP local: {cl("c")}{local_ip}:{status["port"]}{A["0"]}')
        y += 2
        if status['running']:
            print(f'\033[{y};2H{cl("R")}[D] Detener consola remota{A["0"]}')
        else:
            print(f'\033[{y};2H{cl("G")}[I] Iniciar consola remota{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("Y")}[P] Cambiar puerto{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("k")}[Q] Volver{A["0"]}')
        y += 2
        bo = cl("k")
        print(f'\033[{y};0H{bo}┌{"─"*(w-2)}┐{A["0"]}')
        y += 1
        inner = f' {cl("k")}Selecciona una opcion{A["0"]} '
        pad = w - 4 - len(inner)
        print(f'\033[{y};0H{bo}│{A["0"]}{inner}{" "*pad}{bo}│{A["0"]}')
        y += 1
        print(f'\033[{y};0H{bo}└{"─"*(w-2)}┘{A["0"]}')
        key = get_key()
        if key == 'q':
            return
        elif key == 'i':
            ok, msg = start_remote_console(_port)
            notify(msg, 'g' if ok else 'r')
        elif key == 'd':
            ok, msg = stop_remote_console()
            notify(msg, 'g' if ok else 'r')
        elif key == 'p':
            y += 2
            port_str = read_text(f'\033[{y};2H{cl("w")}Nuevo puerto [{_port}]: {A["0"]}', str(_port))
            if port_str and port_str.isdigit():
                _port = int(port_str)
                notify(f"Puerto actualizado a {_port}", 'g')
