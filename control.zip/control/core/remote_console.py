import os, sys, socket, threading, json, hashlib, time as _time
from control.core.shared import CFG, IS_WIN, cl, A, clear, draw_header, get_size, get_key, read_text, notify, confirm, BASE_DIR, get_log_tail, toast
from control.core.server import send_cmd, get_pid, get_players, get_server_stats, get_world_size, get_uptime

END = "---END---\n"

USERS_FILE = os.path.join(BASE_DIR, "remote_users.json")
REQUESTS_FILE = os.path.join(BASE_DIR, "remote_requests.json")

def _load_json(fp, default):
    try:
        if os.path.exists(fp):
            with open(fp, 'r') as f:
                return json.load(f)
    except:
        pass
    return default

def _save_json(fp, data):
    try:
        with open(fp, 'w') as f:
            json.dump(data, f, indent=2)
        return True
    except:
        return False

def load_users():
    return _load_json(USERS_FILE, {})

def save_users(users):
    return _save_json(USERS_FILE, users)

def load_requests():
    return _load_json(REQUESTS_FILE, [])

def save_requests(reqs):
    return _save_json(REQUESTS_FILE, reqs)

def _hash_pw(password, salt):
    return hashlib.sha256((salt + password).encode()).hexdigest()

ROLES = ('creador', 'admin', 'usuario', 'invitado')
INFO_CMDS = ('status', 'statsline', 'logs', 'players', 'help', 'quit')

def create_user(username, password, role='usuario'):
    username = (username or '').strip()
    if role not in ROLES:
        role = 'usuario'
    if not username or not password or len(username) > 24 or ' ' in username:
        return False, "Nombre invalido (sin espacios, max 24)"
    users = load_users()
    if username in users:
        return False, "El usuario ya existe"
    salt = os.urandom(8).hex()
    users[username] = {'salt': salt, 'hash': _hash_pw(password, salt),
                       'role': role, 'approved': True, 'created': int(_time.time()),
                       'cmd_limit': 50, 'cmd_used': 0, 'cmd_day': ''}
    if save_users(users):
        return True, f"Usuario '{username}' [{role}] creado"
    return False, "Error al guardar"

def delete_user(username):
    users = load_users()
    if username not in users:
        return False, "No existe"
    del users[username]
    if save_users(users):
        return True, f"Usuario '{username}' eliminado"
    return False, "Error al guardar"

def request_registration(username, password, role='usuario'):
    username = (username or '').strip()
    if role not in ('admin', 'usuario', 'invitado'):
        role = 'usuario'
    if not username or not password or len(username) > 24 or ' ' in username:
        return False, "Nombre invalido (sin espacios, max 24)"
    if username.lower() in ('admin', 'register', 'quit', 'help'):
        return False, "Nombre reservado"
    users = load_users()
    if username in users:
        return False, "El usuario ya existe, intenta entrar"
    reqs = load_requests()
    for r in reqs:
        if r.get('username') == username:
            return False, "Ya hay una solicitud pendiente con ese nombre"
    salt = os.urandom(8).hex()
    reqs.append({'username': username, 'salt': salt,
                 'hash': _hash_pw(password, salt), 'password': password,
                 'role': role, 'time': int(_time.time())})
    if save_requests(reqs):
        return True, "Solicitud enviada. El creador debe aprobarla."
    return False, "Error al guardar"

def approve_request(username, role='usuario'):
    if role not in ROLES:
        role = 'usuario'
    reqs = load_requests()
    users = load_users()
    for r in reqs:
        if r.get('username') == username:
            users[username] = {'salt': r['salt'], 'hash': r['hash'],
                               'role': role, 'approved': True, 'created': int(_time.time()),
                               'cmd_limit': 50, 'cmd_used': 0, 'cmd_day': ''}
            reqs = [x for x in reqs if x.get('username') != username]
            save_users(users)
            save_requests(reqs)
            return True, f"'{username}' aprobado como {role}"
    return False, "Solicitud no encontrada"

def reject_request(username):
    reqs = load_requests()
    if any(r.get('username') == username for r in reqs):
        save_requests([x for x in reqs if x.get('username') != username])
        return True, f"'{username}' rechazado"
    return False, "Solicitud no encontrada"

def verify_user(username, password):
    users = load_users()
    u = users.get(username or '')
    if not u or not u.get('approved'):
        return False
    return _hash_pw(password or '', u.get('salt', '')) == u.get('hash', '')

def invitado_left(u):
    return int(u.get('created', 0) + 86400 - _time.time())

def cmds_left(username, role):
    if role in ('creador', 'admin'):
        return -1
    if role != 'usuario':
        return 0
    users = load_users()
    u = users.get(username, {})
    today = _time.strftime('%Y-%m-%d', _time.localtime())
    if u.get('cmd_day') != today:
        return u.get('cmd_limit', 50)
    return max(0, u.get('cmd_limit', 50) - u.get('cmd_used', 0))

def cmd_allowed(username, role):
    if role in ('creador', 'admin'):
        return True, ''
    if role == 'invitado':
        users = load_users()
        if invitado_left(users.get(username, {})) <= 0:
            return False, 'Tu acceso de invitado expiro (24h).'
        return False, 'Los invitados no pueden enviar comandos.'
    users = load_users()
    u = users.get(username, {})
    today = _time.strftime('%Y-%m-%d', _time.localtime())
    if u.get('cmd_day') != today:
        u['cmd_day'] = today
        u['cmd_used'] = 0
    limit = u.get('cmd_limit', 50)
    if u.get('cmd_used', 0) >= limit:
        users[username] = u
        save_users(users)
        return False, f'Limite diario alcanzado ({limit}/dia).'
    u['cmd_used'] = u.get('cmd_used', 0) + 1
    users[username] = u
    save_users(users)
    return True, ''

_cpu_cache = (0, None)

def _fast_cpu():
    global _cpu_cache
    now = _time.time()
    if now - _cpu_cache[0] < 5 and _cpu_cache[1] is not None:
        return _cpu_cache[1]
    try:
        from control.core.monitor import get_cpu_usage
        v = get_cpu_usage()
    except:
        v = None
    _cpu_cache = (now, v)
    return v

_server_socket = None
_server_thread = None
_connections = []
_connections_lock = threading.Lock()
_running = False
_port = 25576
_local_ip_cache = None

def _get_local_ip():
    global _local_ip_cache
    if _local_ip_cache:
        return _local_ip_cache
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        s.connect(('8.8.8.8', 80))
        _local_ip_cache = s.getsockname()[0]
        s.close()
    except:
        try:
            _local_ip_cache = socket.gethostbyname(socket.gethostname())
        except:
            _local_ip_cache = '127.0.0.1'
    return _local_ip_cache

def _read_line(conn, limit=1024):
    data = b""
    while b"\n" not in data and len(data) < limit:
        chunk = conn.recv(1024)
        if not chunk:
            return None
        data += chunk
    return data.decode(errors='replace').strip()

def _handle_client(conn, addr):
    global _connections
    try:
        with _connections_lock:
            _connections.append(conn)
        conn.sendall(f"MC Control Remote Console v2.0\n".encode())
        conn.sendall(f"Usuario: ".encode())
        username = _read_line(conn, 64)
        if username is None:
            return
        username = username.strip()
        if username.lower().startswith('register '):
            parts = username.split(None, 3)
            if len(parts) < 3:
                conn.sendall(f"Uso: register <nombre> <clave> [nivel]\n{END}".encode())
                return
            role = (parts[3] if len(parts) > 3 else 'usuario').lower()
            ok, msg = request_registration(parts[1], parts[2], role)
            conn.sendall(f"{msg}\n{END}".encode())
            return
        users = load_users()
        if not users:
            legacy = CFG.get('remote_console_password', '')
            if legacy:
                users = {'admin': {'salt': '', 'hash': '',
                                  'role': 'admin', 'approved': True,
                                  'legacy': legacy, 'created': int(_time.time())}}
        if not users:
            pending = [r.get('username') for r in load_requests()]
            if username in pending:
                conn.sendall(f"Tu solicitud esta pendiente de aprobacion.\n{END}".encode())
            else:
                conn.sendall(f"Sin usuarios. Pide al creador que te registre.\n{END}".encode())
            return
        u = users.get(username)
        if not u or not u.get('approved'):
            pending = [r.get('username') for r in load_requests()]
            if username in pending:
                conn.sendall(f"Tu solicitud esta pendiente de aprobacion.\n{END}".encode())
            else:
                conn.sendall(f"Usuario desconocido o no aprobado. Usa: register <nombre> <clave>\n{END}".encode())
            return
        conn.sendall(f"Password: ".encode())
        password = _read_line(conn, 256)
        if password is None:
            return
        if u.get('legacy'):
            ok_auth = (password == u['legacy'])
        else:
            ok_auth = _hash_pw(password, u.get('salt', '')) == u.get('hash', '')
        if not ok_auth:
            conn.sendall(f"Clave incorrecta.\n{END}".encode())
            return
        role = u.get('role', 'usuario')
        note = ''
        if role == 'invitado':
            left = invitado_left(u)
            if left <= 0:
                conn.sendall(f"Tu acceso de invitado expiro (24h).\n{END}".encode())
                return
            note = f' Expira en {int(left // 3600)}h.'
        conn.sendall(f"Bienvenido {username} [{role}].{note}\n{END}".encode())
        while True:
            line = _read_line(conn)
            if line is None:
                return
            if not line:
                continue
            low = line.lower()
            if low == 'quit':
                conn.sendall(f"Conexion cerrada.\n{END}".encode())
                break
            if low == 'status':
                pid = get_pid()
                if pid:
                    resp = f"Servidor: ONLINE (PID {pid})\n"
                else:
                    resp = f"Servidor: OFFLINE\n"
                conn.sendall((resp + END).encode())
                continue
            if low == 'statsline':
                try:
                    pid = get_pid()
                    st = get_server_stats() or {}
                    ps = get_players() if pid else []
                    ws = get_world_size()
                    up = get_uptime()
                    cpu = _fast_cpu()
                    resp = '|'.join([
                        'ONLINE' if pid else 'OFFLINE',
                        str(st.get('ram') or 0),
                        str(cpu if cpu is not None else -1),
                        str(len(ps)),
                        ','.join(ps[:20]),
                        str(ws or 0),
                        str(up or 0),
                        role,
                        str(cmds_left(username, role)),
                    ]) + '\n'
                except Exception as e:
                    resp = f"Error: {e}\n"
                conn.sendall((resp + END).encode())
                continue
            if low.startswith('logs'):
                parts = line.split()
                try:
                    n = int(parts[1]) if len(parts) > 1 else 30
                except:
                    n = 30
                n = max(1, min(n, 100))
                try:
                    lines = get_log_tail(n)
                    resp = '\n'.join(l.rstrip() for l in lines) + '\n' if lines else '(sin logs)\n'
                except Exception as e:
                    resp = f"Error: {e}\n"
                conn.sendall((resp + END).encode())
                continue
            if low == 'players':
                try:
                    ps = get_players()
                    resp = (', '.join(ps) + f' ({len(ps)} en linea)\n') if ps else '(nadie en linea)\n'
                except Exception as e:
                    resp = f"Error: {e}\n"
                conn.sendall((resp + END).encode())
                continue
            if low == 'help':
                resp = "Comandos: <comando mc> | status | statsline | logs [n] | players | help | quit\n"
                conn.sendall((resp + END).encode())
                continue
            allowed, why = cmd_allowed(username, role)
            if not allowed:
                conn.sendall((f"Denegado: {why}\n" + END).encode())
                continue
            result = send_cmd(line)
            if result:
                conn.sendall((f"Comando enviado.\n" + END).encode())
            else:
                conn.sendall((f"Error: no se pudo enviar el comando.\n" + END).encode())
    except:
        pass
    finally:
        with _connections_lock:
            if conn in _connections:
                _connections.remove(conn)
        try:
            conn.close()
        except:
            pass

def start_remote_console(port=25576):
    global _server_socket, _server_thread, _running, _port
    if _running:
        return False, "Ya esta corriendo"
    _port = port
    try:
        _server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        _server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        _server_socket.bind(('0.0.0.0', port))
        _server_socket.listen(5)
        _running = True
        def accept_loop():
            while _running:
                try:
                    conn, addr = _server_socket.accept()
                    t = threading.Thread(target=_handle_client, args=(conn, addr), daemon=True)
                    t.start()
                except:
                    if not _running:
                        break
        _server_thread = threading.Thread(target=accept_loop, daemon=True)
        _server_thread.start()
        return True, f"Consola remota iniciada en puerto {port}"
    except Exception as e:
        _running = False
        return False, f"Error: {e}"

def stop_remote_console():
    global _server_socket, _running
    if not _running:
        return False, "No esta corriendo"
    _running = False
    try:
        _server_socket.close()
    except:
        pass
    with _connections_lock:
        for conn in _connections[:]:
            try:
                conn.close()
            except:
                pass
        _connections.clear()
    return True, "Consola remota detenida"

def get_remote_console_status():
    return {
        "running": _running,
        "port": _port,
        "connections": len(_connections)
    }

def remote_console_menu():
    global _port
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "Consola Remota", "Servidor TCP para comandos remotos")
        status = get_remote_console_status()
        y = 4
        state = f'{cl("G")}ACTIVA{A["0"]}' if status['running'] else f'{cl("R")}INACTIVA{A["0"]}'
        print(f'\033[{y};2H{cl("w")}Estado: {state}{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("w")}Puerto: {cl("c")}{status["port"]}{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("w")}Conexiones: {cl("c")}{status["connections"]}{A["0"]}')
        y += 1
        local_ip = _get_local_ip()
        print(f'\033[{y};2H{cl("w")}IP local: {cl("c")}{local_ip}:{status["port"]}{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("k")}Cliente Termux: termux_remote.py {local_ip} {status["port"]}{A["0"]}')
        y += 2
        n_users = len(load_users())
        n_reqs = len(load_requests())
        print(f'\033[{y};2H{cl("w")}Usuarios: {cl("c")}{n_users}{A["0"]}', end='')
        if n_reqs:
            print(f'  {cl("Y")}Solicitudes: {n_reqs} pendientes!{A["0"]}')
        else:
            print(f'  {cl("k")}Solicitudes: 0{A["0"]}')
        y += 1
        if status['running']:
            print(f'\033[{y};2H{cl("R")}[D] Detener consola remota{A["0"]}')
        else:
            print(f'\033[{y};2H{cl("G")}[I] Iniciar consola remota{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("Y")}[P] Cambiar puerto  {cl("c")}[U] Nuevo usuario  {cl("y")}[A] Solicitudes  {cl("r")}[E] Eliminar usuario{A["0"]}')
        y += 1
        print(f'\033[{y};2H{cl("k")}[Q] Volver{A["0"]}')
        y += 2
        bo = cl("k")
        print(f'\033[{y};0H{bo}┌{"─"*(w-2)}┐{A["0"]}')
        y += 1
        inner = f' {cl("k")}Selecciona una opcion{A["0"]} '
        pad = w - 4 - len(inner)
        print(f'\033[{y};0H{bo}│{A["0"]}{inner}{" "*pad}{bo}│{A["0"]}')
        y += 1
        print(f'\033[{y};0H{bo}└{"─"*(w-2)}┘{A["0"]}')
        key = get_key()
        if key in ('q', 'esc'):
            return
        elif key == 'i':
            ok, msg = start_remote_console(_port)
            toast(msg, 'g' if ok else 'r')
        elif key == 'd':
            ok, msg = stop_remote_console()
            toast(msg, 'g' if ok else 'r')
        elif key == 'p':
            y += 2
            port_str = read_text(f'\033[{y};2H{cl("w")}Nuevo puerto [{_port}]: {A["0"]}', str(_port))
            if port_str and port_str.isdigit():
                _port = int(port_str)
                toast(f"Puerto actualizado a {_port}", 'g')
        elif key == 'u':
            nu = read_text("  Nombre de usuario: ")
            if nu:
                pw = read_text("  Clave: ")
                if pw:
                    rr = read_text("  Rol [1]creador [2]admin [3]usuario [4]invitado (3): ", "3")
                    role = {'1': 'creador', '2': 'admin', '3': 'usuario', '4': 'invitado'}.get((rr or '3').strip(), 'usuario')
                    ok, msg = create_user(nu, pw, role)
                    if ok and role == 'usuario':
                        lim = read_text("  Limite diario de comandos (50): ", "50")
                        if lim and lim.isdigit():
                            users = load_users()
                            if nu in users:
                                users[nu]['cmd_limit'] = int(lim)
                                save_users(users)
                    toast(msg, 'g' if ok else 'r')
        elif key == 'a':
            _approve_menu()
        elif key == 'e':
            du = read_text("  Usuario a eliminar: ")
            if du:
                ok, msg = delete_user(du)
                toast(msg, 'g' if ok else 'r')

def _approve_menu():
    while True:
        clear()
        cols = get_size()
        draw_header(1, "SOLICITUDES", "Aprobar o rechazar acceso remoto")
        reqs = load_requests()
        y = 3
        if not reqs:
            print(f'\033[{y};0H  {cl("k")}No hay solicitudes pendientes{A["0"]}')
            y += 2
            print(f'\033[{y};0H  {cl("k")}[Q]{A["0"]} volver')
            k = get_key()
            if k in ('q', 'esc'):
                return
            continue
        for i, r in enumerate(reqs):
            print(f'\033[{y+i*2};0H  {i+1}. {cl("y")}{r.get("username")}{A["0"]} [{r.get("role", "usuario")}]')
            print(f'\033[{y+i*2+1};0H     {cl("k")}Clave: {r.get("password", "?")}{A["0"]}')
        y += len(reqs) * 2 + 1
        print(f'\033[{y};0H  {cl("k")}Numero para aprobar, r+numero para rechazar, Q volver{A["0"]}')
        sel = read_text("  Opcion: ")
        if sel is None or sel.lower() in ('q', ''):
            return
        sel = sel.strip().lower()
        if sel.startswith('r') and sel[1:].isdigit():
            idx = int(sel[1:]) - 1
            if 0 <= idx < len(reqs):
                ok, msg = reject_request(reqs[idx]['username'])
                toast(msg, 'g' if ok else 'r')
            else:
                toast("Numero invalido", 'r')
        elif sel.isdigit():
            idx = int(sel) - 1
            if 0 <= idx < len(reqs):
                want = reqs[idx].get('role', 'usuario')
                dflt = {'creador': '1', 'admin': '2', 'usuario': '3', 'invitado': '4'}.get(want, '3')
                rr = read_text(f"  Rol [1]creador [2]admin [3]usuario [4]invitado (pide {want}): ", dflt)
                role = {'1': 'creador', '2': 'admin', '3': 'usuario', '4': 'invitado'}.get((rr or dflt).strip(), want)
                ok, msg = approve_request(reqs[idx]['username'], role)
                toast(msg, 'g' if ok else 'r')
            else:
                toast("Numero invalido", 'r')
        else:
            toast("Opcion invalida", 'r')
