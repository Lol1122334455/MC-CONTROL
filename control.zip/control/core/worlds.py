import os, shutil, time, sys, tempfile, re
from control.core.shared import CFG, get_worlds_dir, fmt_size
from control.core.server import get_pid, send_cmd, stop

def _get_world_dir():
    sd = CFG['server_dir']
    props = os.path.join(sd, "server.properties")
    if os.path.exists(props):
        try:
            with open(props, 'r') as f:
                for line in f:
                    m = re.match(r'^level-name=(.+)$', line.strip())
                    if m:
                        wn = m.group(1).strip()
                        wp = os.path.join(sd, wn)
                        if os.path.exists(wp):
                            return wp
        except:
            pass
    default = os.path.join(sd, "world")
    if os.path.exists(default):
        return default
    for name in os.listdir(sd):
        fp = os.path.join(sd, name)
        if os.path.isdir(fp) and name not in ('worlds', 'mods', 'plugins', 'profiles', 'logs', 'cache', 'crash-reports', 'stats', 'data', 'advancements'):
            sub = os.path.join(fp, 'level.dat')
            if os.path.exists(sub) or os.path.exists(os.path.join(fp, 'region')):
                return fp
    return default

def get_saved_worlds():
    wd = get_worlds_dir()
    os.makedirs(wd, exist_ok=True)
    return sorted([d for d in os.listdir(wd) if os.path.isdir(os.path.join(wd, d))])

def save_current_world(name):
    sd = CFG['server_dir']
    wd = _get_world_dir()
    if not os.path.exists(wd):
        return False, "No existe el directorio world"
    pid = get_pid()
    if pid:
        send_cmd("save-off")
        send_cmd("save-all")
        time.sleep(2)
    wdir = get_worlds_dir()
    dest = os.path.join(wdir, name)
    if os.path.exists(dest):
        shutil.rmtree(dest)
    os.makedirs(dest)
    try:
        for item in os.listdir(wd):
            fp = os.path.join(wd, item)
            if os.path.isdir(fp):
                shutil.copytree(fp, os.path.join(dest, item))
            else:
                shutil.copy2(fp, os.path.join(dest, item))
        for dim in ['DIM-1', 'DIM1']:
            dp = os.path.join(sd, dim)
            if os.path.exists(dp):
                shutil.copytree(dp, os.path.join(dest, dim))
        sz = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fn in os.walk(dest) for f in fn) if os.path.exists(dest) else 0
        return True, f"Mundo guardado: {name} ({fmt_size(sz)})"
    except Exception as e:
        return False, str(e)

def switch_to_world(name):
    sd = CFG['server_dir']
    wdir = get_worlds_dir()
    src = os.path.join(wdir, name)
    if not os.path.exists(src):
        return False, "Mundo no encontrado"
    pid = get_pid()
    if pid:
        stop()
        time.sleep(3)
    wd = os.path.join(sd, "world")
    if os.path.exists(wd):
        shutil.rmtree(wd)
    os.makedirs(wd)
    try:
        for item in os.listdir(src):
            fp = os.path.join(src, item)
            if os.path.isdir(fp):
                shutil.copytree(fp, os.path.join(wd, item))
            else:
                shutil.copy2(fp, os.path.join(wd, item))
        for dim in ['DIM-1', 'DIM1']:
            sp = os.path.join(src, dim)
            if os.path.exists(sp):
                dp = os.path.join(sd, dim)
                if os.path.exists(dp):
                    shutil.rmtree(dp)
                shutil.copytree(sp, dp)
        return True, f"Mundo cambiado a: {name}"
    except Exception as e:
        return False, str(e)

def download_world_from_url(url, name):
    wdir = get_worlds_dir()
    import urllib.request, ssl
    tmp = tempfile.mktemp(suffix=os.path.splitext(url.split('/')[-1])[1] or '.zip')
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=600, context=ctx) as r:
            total = int(r.headers.get('Content-Length', 0))
            dl = 0
            with open(tmp, 'wb') as f:
                while True:
                    data = r.read(65536)
                    if not data:
                        break
                    f.write(data)
                    dl += len(data)
        dest = os.path.join(wdir, name)
        os.makedirs(wdir, exist_ok=True)
        if os.path.exists(dest):
            shutil.rmtree(dest)
        os.makedirs(dest)
        if tmp.endswith('.tar.gz') or tmp.endswith('.tgz'):
            import tarfile
            with tarfile.open(tmp, 'r:gz') as tar:
                members = tar.getmembers()
                top_dirs = set(m.name.split('/')[0] for m in members if '/' in m.name)
                if top_dirs and all(not m.name.startswith('.') for m in members):
                    tar.extractall(path=dest)
                    if len(os.listdir(dest)) == 1 and os.path.isdir(os.path.join(dest, os.listdir(dest)[0])):
                        inner = os.listdir(dest)[0]
                        for item in os.listdir(os.path.join(dest, inner)):
                            shutil.move(os.path.join(dest, inner, item), os.path.join(dest, item))
                        os.rmdir(os.path.join(dest, inner))
                else:
                    tar.extractall(path=dest)
        elif os.path.splitext(tmp)[1].lower() == '.zip' or os.path.splitext(tmp)[1].lower() == '':
            import zipfile
            with zipfile.ZipFile(tmp, 'r') as z:
                names = z.namelist()
                top_dirs = set(n.split('/')[0] for n in names if '/' in n)
                if len(top_dirs) == 1 and top_dirs != set(['__MACOSX']):
                    z.extractall(path=dest)
                    inner = os.path.join(dest, list(top_dirs)[0])
                    if os.path.isdir(inner):
                        for item in os.listdir(inner):
                            shutil.move(os.path.join(inner, item), os.path.join(dest, item))
                        os.rmdir(inner)
                else:
                    z.extractall(path=dest)
            if os.path.exists(os.path.join(dest, '__MACOSX')):
                shutil.rmtree(os.path.join(dest, '__MACOSX'))
        elif os.path.splitext(tmp)[1].lower() == '.tar':
            import tarfile
            with tarfile.open(tmp, 'r') as tar:
                tar.extractall(path=dest)
        os.remove(tmp)
        sz = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fn in os.walk(dest) for f in fn) if os.path.exists(dest) else 0
        return True, f"Mundo importado: {name} ({fmt_size(sz)})"
    except Exception as e:
        try:
            os.remove(tmp)
        except:
            pass
        return False, str(e)