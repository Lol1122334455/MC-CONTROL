import os, subprocess, time, datetime
from control.core.shared import CFG
from control.core.server import get_pid, send_cmd, stop

def list_backups():
    sd = CFG['server_dir']
    backups = sorted([f for f in os.listdir(sd) if f.startswith('backup_') and f.endswith('.tar.gz')], reverse=True)
    result = []
    for b in backups[:20]:
        try:
            sz = os.path.getsize(os.path.join(sd, b))
            result.append({"name": b, "size": sz})
        except:
            result.append({"name": b, "size": 0})
    return result

def create_backup():
    sd = CFG['server_dir']
    wd = os.path.join(sd, "world")
    if not os.path.exists(wd):
        return None, "No existe el directorio 'world'"
    pid = get_pid()
    if pid:
        send_cmd("save-off")
        send_cmd("save-all")
        time.sleep(2)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"backup_{ts}.tar.gz"
    items = ["world", "mods", "config", "scheduled_msgs.txt", "scheduled_tasks.txt",
             "server.properties", "eula.txt", "banned-ips.json", "banned-players.json",
             "ops.json", "whitelist.json"]
    existing = [i for i in items if os.path.exists(os.path.join(sd, i))]
    try:
        subprocess.run(["tar", "-czf", name] + existing,
                       cwd=sd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        sz = os.path.getsize(os.path.join(sd, name))
        clean_old_backups()
        return name, sz
    except Exception as e:
        return None, str(e)

def clean_old_backups():
    days = CFG.get('backup_keep_days', 30)
    if days <= 0:
        return
    sd = CFG['server_dir']
    now = time.time()
    cutoff = now - days * 86400
    for f in os.listdir(sd):
        if f.startswith('backup_') and f.endswith('.tar.gz'):
            try:
                fp = os.path.join(sd, f)
                if os.path.getmtime(fp) < cutoff:
                    os.remove(fp)
            except:
                pass

def restore_backup_by_name(name):
    sd = CFG['server_dir']
    path = os.path.join(sd, name)
    if not os.path.exists(path):
        return False, "Backup no encontrado"
    pid = get_pid()
    if pid:
        stop()
        time.sleep(3)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    for d in ['world', 'mods', 'config']:
        dp = os.path.join(sd, d)
        if os.path.exists(dp):
            subprocess.run(["mv", d, f"{d}_old_{ts}"], cwd=sd)
    for d in ['DIM-1', 'DIM1']:
        dp = os.path.join(sd, d)
        if os.path.exists(dp):
            os.rename(dp, f"{d}_old_{ts}")
    try:
        subprocess.run(["tar", "-xzf", name], cwd=sd)
        return True, "Backup restaurado"
    except Exception as e:
        return False, str(e)

def delete_backup_by_name(name):
    sd = CFG['server_dir']
    path = os.path.join(sd, name)
    if not os.path.exists(path):
        return False, "No encontrado"
    try:
        os.remove(path)
        return True, "Borrado"
    except Exception as e:
        return False, str(e)