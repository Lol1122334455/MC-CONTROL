import os, shutil, time
from control.core.shared import CFG, get_profiles_dir, fmt_size
from control.core.server import get_pid, send_cmd, stop

def get_profiles():
    pd = get_profiles_dir()
    os.makedirs(pd, exist_ok=True)
    return sorted([d for d in os.listdir(pd) if os.path.isdir(os.path.join(pd, d))])

def save_profile_core(name):
    pd = get_profiles_dir()
    os.makedirs(pd, exist_ok=True)
    sd = CFG['server_dir']
    pid = get_pid()
    if pid:
        send_cmd("save-off")
        send_cmd("save-all")
        time.sleep(2)
    pp = os.path.join(pd, name)
    if os.path.exists(pp):
        shutil.rmtree(pp)
    for sub in ['mods', 'config', 'world']:
        os.makedirs(os.path.join(pp, sub), exist_ok=True)
    try:
        srcs = {
            'mods': [f for f in os.listdir(os.path.join(sd, 'mods')) if f.endswith('.jar')] if os.path.exists(os.path.join(sd, 'mods')) else [],
            'config': os.listdir(os.path.join(sd, 'config')) if os.path.exists(os.path.join(sd, 'config')) else [],
            'world': os.listdir(os.path.join(sd, 'world')) if os.path.exists(os.path.join(sd, 'world')) else [],
        }
        for sub, items in srcs.items():
            sp = os.path.join(sd, sub)
            dp = os.path.join(pp, sub)
            for f in items:
                fp = os.path.join(sp, f)
                if os.path.isdir(fp):
                    shutil.copytree(fp, os.path.join(dp, f))
                else:
                    shutil.copy2(fp, os.path.join(dp, f))
        for dim in ['DIM-1', 'DIM1']:
            dp = os.path.join(sd, dim)
            if os.path.exists(dp):
                shutil.copytree(dp, os.path.join(pp, dim))
        return True, f"Perfil guardado: {name}"
    except Exception as e:
        return False, str(e)

def load_profile_core(name):
    pd = get_profiles_dir()
    sd = CFG['server_dir']
    pp = os.path.join(pd, name)
    if not os.path.exists(pp):
        return False, "Perfil no encontrado"
    if get_pid():
        stop()
        time.sleep(3)
    for d in ['mods', 'config', 'world']:
        dp = os.path.join(sd, d)
        if os.path.exists(dp):
            shutil.rmtree(dp)
        os.makedirs(dp, exist_ok=True)
    try:
        for sub in ['mods', 'config', 'world']:
            sp = os.path.join(pp, sub)
            dp = os.path.join(sd, sub)
            if os.path.exists(sp):
                for f in os.listdir(sp):
                    fp = os.path.join(sp, f)
                    if os.path.isdir(fp):
                        shutil.copytree(fp, os.path.join(dp, f))
                    else:
                        shutil.copy2(fp, os.path.join(dp, f))
        for dim in ['DIM-1', 'DIM1']:
            sp = os.path.join(pp, dim)
            if os.path.exists(sp):
                dp = os.path.join(sd, dim)
                if os.path.exists(dp):
                    shutil.rmtree(dp)
                shutil.copytree(sp, dp)
        return True, f"Perfil cargado: {name}"
    except Exception as e:
        return False, str(e)