import os, json, shutil
from control.core.shared import CFG, BASE_DIR, cl, A, clear, draw_header, get_size, get_key, read_text, notify, confirm, save_config, load_config, IS_WIN


def get_servers():
    path = os.path.join(BASE_DIR, "servers.json")
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception:
        return []


def save_servers(servers):
    path = os.path.join(BASE_DIR, "servers.json")
    with open(path, 'w') as f:
        json.dump(servers, f, indent=2)


def add_server():
    clear()
    draw_header(1, "Agregar Servidor", "Nuevo servidor")
    cols = get_size()
    y = 5

    name = read_text(f"{cl('c')} Nombre del servidor: {cl('0')}")
    if not name:
        return

    server_dir = read_text(f"{cl('c')} Directorio del servidor: {cl('0')}")
    if not server_dir:
        return

    if not os.path.isdir(server_dir):
        notify("Directorio no encontrado", 'r')
        return

    jar_path = ""
    java_path = ""
    server_version = ""
    mod_loader = "vanilla"

    for f in os.listdir(server_dir):
        if f.endswith('.jar'):
            jar_path = os.path.join(server_dir, f)
            mod_loader = detect_mod_loader_from_name(f)
            server_version = extract_version_from_jar(f)
            break

    java_path = auto_detect_java(server_dir)

    servers = get_servers()
    for s in servers:
        if s['name'] == name:
            notify("Ya existe un servidor con ese nombre", 'r')
            return

    servers.append({
        'name': name,
        'server_dir': server_dir,
        'jar_path': jar_path,
        'java_path': java_path,
        'server_version': server_version,
        'mod_loader': mod_loader
    })
    save_servers(servers)
    notify(f"Servidor '{name}' agregado", 'g')


def switch_server(name):
    global CFG
    servers = get_servers()
    for s in servers:
        if s['name'] == name:
            CFG['server_dir'] = s['server_dir']
            CFG['jar_path'] = s['jar_path']
            CFG['java_path'] = s['java_path']
            CFG['server_version'] = s['server_version']
            CFG['mod_loader'] = s['mod_loader']
            save_config(CFG)
            notify(f"Cambiado a: {name}", 'g')
            return True
    notify("Servidor no encontrado", 'r')
    return False


def delete_server(name):
    servers = get_servers()
    new_servers = [s for s in servers if s['name'] != name]
    if len(new_servers) == len(servers):
        notify("Servidor no encontrado", 'r')
        return
    save_servers(new_servers)
    notify(f"Servidor '{name}' eliminado de la lista", 'g')


def server_details(name):
    servers = get_servers()
    for s in servers:
        if s['name'] == name:
            clear()
            draw_header(1, f"Detalles: {s['name']}")
            cols = get_size()
            y = 4
            info = [
                ("Nombre", s['name']),
                ("Directorio", s['server_dir']),
                ("JAR", s['jar_path']),
                ("Java", s['java_path']),
                ("Version", s['server_version'] or "Desconocida"),
                ("Mod Loader", s['mod_loader']),
            ]

            world_dir = os.path.join(s['server_dir'], 'world')
            if os.path.isdir(world_dir):
                world_size = get_dir_size(world_dir)
                info.append(("Mundo", fmt_size(world_size)))
            else:
                info.append(("Mundo", "No encontrado"))

            for label, val in info:
                print(f"{cl('c')} {label}:{cl('0')} {val}")
                y += 1

            print(f"\n{cl('k')} Presiona cualquier tecla para volver...{cl('0')}")
            get_key()
            return
    notify("Servidor no encontrado", 'r')


def multi_server_menu():
    while True:
        clear()
        draw_header(1, "Multi-Servidor", "Gestionar servidores")
        cols = get_size()
        y = 4
        servers = get_servers()
        current_dir = CFG.get('server_dir', '')

        if not servers:
            print(f"{cl('k')} No hay servidores configurados{cl('0')}")
            print(f"{cl('k')} Presiona [A] para agregar uno{cl('0')}")
        else:
            for i, s in enumerate(servers):
                is_current = os.path.abspath(s['server_dir']) == os.path.abspath(current_dir)
                prefix = f"{cl('G')}▸{cl('0')}" if is_current else " "
                marker = f" {cl('Y')}[ACTUAL]{cl('0')}" if is_current else ""
                ver = s.get('server_version', '?') or '?'
                loader = s.get('mod_loader', '?')
                print(f"{prefix} {cl('w')}{s['name']}{cl('0')}{marker}")
                print(f"    {cl('k')}{s['server_dir']}{cl('0')}")
                print(f"    {cl('c')}{ver}{cl('0')} | {cl('p')}{loader}{cl('0')}")
                y += 3

        print()
        print(f" {cl('G')}[A]{cl('0')} Agregar servidor")
        print(f" {cl('G')}[S]{cl('0')} Cambiar a servidor seleccionado")
        print(f" {cl('R')}[D]{cl('0')} Eliminar servidor")
        print(f" {cl('C')}[V]{cl('0')} Ver detalles")
        print(f" {cl('R')}[Q]{cl('0')} Volver")

        key = get_key()
        if key == 'q':
            return
        elif key == 'a':
            add_server()
        elif key == 's' and servers:
            names = [s['name'] for s in servers]
            sel = select_from_list(names, "Selecciona un servidor")
            if sel is not None:
                switch_server(names[sel])
        elif key == 'd' and servers:
            names = [s['name'] for s in servers]
            sel = select_from_list(names, "Selecciona servidor a eliminar")
            if sel is not None:
                if confirm(f"Eliminar '{names[sel]}' de la lista? (s/n): "):
                    delete_server(names[sel])
        elif key == 'v' and servers:
            names = [s['name'] for s in servers]
            sel = select_from_list(names, "Selecciona servidor")
            if sel is not None:
                server_details(names[sel])


def select_from_list(items, title="Selecciona"):
    while True:
        clear()
        draw_header(1, title)
        cols = get_size()
        for i, item in enumerate(items):
            print(f" {cl('G')}{i+1}{cl('0')}. {cl('w')}{item}{cl('0')}")
        print(f"\n {cl('k')}0. Cancelar{cl('0')}")
        key = get_key()
        if key == 'q' or key == '0':
            return None
        try:
            idx = int(key) - 1
            if 0 <= idx < len(items):
                return idx
        except ValueError:
            pass
        if key == 'enter':
            return 0


def detect_mod_loader_from_name(jar_name):
    from control.core.shared import detect_mod_loader
    return detect_mod_loader(jar_name)


def extract_version_from_jar(jar_name):
    import re
    m = re.search(r'(\d+\.\d+(?:\.\d+)?)', jar_name)
    return m.group(1) if m else ""


def auto_detect_java(sd):
    from control.core.shared import auto_detect_java as _detect
    return _detect(sd)


def get_dir_size(path):
    total = 0
    for dirpath, dirnames, filenames in os.walk(path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            try:
                total += os.path.getsize(fp)
            except OSError:
                pass
    return total


def fmt_size(b):
    for u in ['B', 'KB', 'MB', 'GB', 'TB']:
        if b < 1024:
            return f"{b:.1f}{u}"
        b /= 1024
    return f"{b:.1f}PB"
