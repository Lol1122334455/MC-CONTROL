import os, time, datetime, glob, logging
from control.core.shared import CFG, save_config

logging.basicConfig(
    filename=os.path.join(CFG.get('server_dir', '.'), 'backup.log'),
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
log = logging.getLogger('autobackup')


def auto_backup_loop():
    while True:
        try:
            if CFG.get('auto_backup_enabled', False):
                hours = CFG.get('auto_backup_hours', 6)
                last = CFG.get('last_backup_time', 0)
                now = time.time()
                if now - last >= hours * 3600:
                    from control.core.backup import create_backup
                    name, sz = create_backup()
                    if name:
                        log.info(f"Backup automatico creado: {name} ({sz} bytes)")
                        CFG['last_backup_time'] = now
                        save_config(CFG)
                    else:
                        log.error(f"Error al crear backup automatico: {sz}")
        except Exception as e:
            log.error(f"Error en auto_backup_loop: {e}")
        time.sleep(60)


def _rotate_log_file(filepath, keep_days):
    if not os.path.exists(filepath):
        return
    now = time.time()
    cutoff = now - keep_days * 86400
    base = filepath
    for pattern in [base, f"{base}.1", f"{base}.2", f"{base}.3", f"{base}.4", f"{base}.5"]:
        if os.path.exists(pattern):
            try:
                if os.path.getmtime(pattern) < cutoff:
                    os.remove(pattern)
                    log.info(f"Log eliminado: {pattern}")
            except Exception as e:
                log.error(f"Error al eliminar log {pattern}: {e}")


def _rotate_logs_dir(server_dir, keep_days):
    logs_dir = os.path.join(server_dir, 'logs')
    if not os.path.exists(logs_dir):
        return
    now = time.time()
    cutoff = now - keep_days * 86400
    for f in os.listdir(logs_dir):
        fp = os.path.join(logs_dir, f)
        if os.path.isfile(fp):
            try:
                if os.path.getmtime(fp) < cutoff:
                    os.remove(fp)
                    log.info(f"Log eliminado: {fp}")
            except Exception as e:
                log.error(f"Error al eliminar log {fp}: {e}")


def auto_log_rotate():
    try:
        if CFG.get('auto_log_rotate_enabled', False):
            keep_days = CFG.get('auto_log_rotate_days', 7)
            server_dir = CFG.get('server_dir', '.')
            log_file = CFG.get('log_file', os.path.join(server_dir, 'server.log'))
            _rotate_log_file(log_file, keep_days)
            _rotate_logs_dir(server_dir, keep_days)
            log.info(f"Rotacion de logs completada (mantener {keep_days} dias)")
    except Exception as e:
        log.error(f"Error en auto_log_rotate: {e}")


def auto_log_rotate_loop():
    auto_log_rotate()
    while True:
        try:
            time.sleep(3600)
            auto_log_rotate()
        except Exception as e:
            log.error(f"Error en auto_log_rotate_loop: {e}")


def auto_backup_settings_menu():
    from control.core.shared import CFG, save_config, notify, clear, draw_header, get_key, read_text, get_size, cl, A, fmt_time
    while True:
        clear()
        cols = get_size()
        draw_header(1, "BACKUP AUTOMATICO")
        enabled = CFG.get('auto_backup_enabled', False)
        hours = CFG.get('auto_backup_hours', 6)
        status = f'{cl("g")}ACTIVADO{A["0"]}' if enabled else f'{cl("r")}DESACTIVADO{A["0"]}'
        print(f'\033[3;0H  Estado: {status}')
        print(f'\033[4;0H  Intervalo: cada {hours} horas')
        print(f'\033[6;0H  {cl("c")}[E]{A["0"]} Activar/Desactivar')
        print(f'\033[7;0H  {cl("y")}[I]{A["0"]} Cambiar intervalo')
        print(f'\033[8;0H  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k == 'e':
            CFG['auto_backup_enabled'] = not CFG.get('auto_backup_enabled', False)
            save_config(CFG)
            notify(f"Backup automatico {'activado' if CFG['auto_backup_enabled'] else 'desactivado'}", 'g')
        elif k == 'i':
            h = read_text(f"  Horas ({hours}): ", str(hours))
            if h and h.isdigit() and int(h) > 0:
                CFG['auto_backup_hours'] = int(h)
                save_config(CFG)
                notify("Intervalo actualizado", 'g')
        elif k in ('q', 'esc'):
            return


def auto_log_rotate_settings():
    from control.core.shared import CFG, save_config, notify, clear, draw_header, get_key, read_text, get_size, cl, A
    while True:
        clear()
        cols = get_size()
        draw_header(1, "LOG ROTATIVO")
        enabled = CFG.get('auto_log_rotate_enabled', False)
        days = CFG.get('auto_log_rotate_days', 7)
        status = f'{cl("g")}ACTIVADO{A["0"]}' if enabled else f'{cl("r")}DESACTIVADO{A["0"]}'
        print(f'\033[3;0H  Estado: {status}')
        print(f'\033[4;0H  Mantener: ultimos {days} dias')
        print(f'\033[6;0H  {cl("c")}[E]{A["0"]} Activar/Desactivar')
        print(f'\033[7;0H  {cl("y")}[D]{A["0"]} Cambiar dias')
        print(f'\033[8;0H  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k == 'e':
            CFG['auto_log_rotate_enabled'] = not CFG.get('auto_log_rotate_enabled', False)
            save_config(CFG)
            notify(f"Log rotativo {'activado' if CFG['auto_log_rotate_enabled'] else 'desactivado'}", 'g')
        elif k == 'd':
            d = read_text(f"  Dias ({days}): ", str(days))
            if d and d.isdigit() and int(d) > 0:
                CFG['auto_log_rotate_days'] = int(d)
                save_config(CFG)
                notify("Dias actualizados", 'g')
        elif k in ('q', 'esc'):
            return
