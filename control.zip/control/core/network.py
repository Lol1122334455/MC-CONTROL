import os, socket, subprocess
from control.core.shared import CFG, IS_WIN, cl, A, clear, draw_header, get_key, read_text, notify, toast, get_size


def get_public_ip():
    try:
        import urllib.request, ssl
        req = urllib.request.Request("https://api.ipify.org", headers={"User-Agent": "Mozilla/5.0"})
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=5, context=ctx) as r:
            return r.read().decode().strip()
    except Exception:
        try:
            import urllib.request, ssl
            req = urllib.request.Request("https://ifconfig.me", headers={"User-Agent": "Mozilla/5.0"})
            ctx = ssl._create_unverified_context()
            with urllib.request.urlopen(req, timeout=5, context=ctx) as r:
                return r.read().decode().strip()
        except Exception:
            return None


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def check_port(port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2)
        result = s.connect_ex(('127.0.0.1', port))
        s.close()
        return result == 0
    except Exception:
        return False


def firewall_instructions():
    clear()
    draw_header(1, "Instrucciones de Firewall")
    print()
    print(f" {cl('Y')}Puerto del servidor:{cl('0')} {CFG.get('server-port', 25565)}")
    print()

    if IS_WIN:
        print(f" {cl('C')}Windows Defender Firewall{cl('0')}")
        print(f" {cl('k')}---{cl('0')}")
        print(f" Abrir Puerto (PowerShell como Admin):")
        print(f"   {cl('w')}netsh advfirewall firewall add rule name=\"Minecraft\" dir=in action=allow protocol=TCP localport={CFG.get('server-port', 25565)}{cl('0')}")
        print()
        print(f" Cerrar Puerto:")
        print(f"   {cl('w')}netsh advfirewall firewall delete rule name=\"Minecraft\"{cl('0')}")
        print()
        print(f" Verificar:")
        print(f"   {cl('w')}netsh advfirewall firewall show rule name=\"Minecraft\"{cl('0')}")
    else:
        print(f" {cl('C')}Linux - ufw{cl('0')}")
        print(f" {cl('k')}---{cl('0')}")
        print(f"   {cl('w')}sudo ufw allow {CFG.get('server-port', 25565)}/tcp comment \"Minecraft\"{cl('0')}")
        print(f"   {cl('w')}sudo ufw reload{cl('0')}")
        print()
        print(f" {cl('C')}Linux - firewalld{cl('0')}")
        print(f" {cl('k')}---{cl('0')}")
        print(f"   {cl('w')}sudo firewall-cmd --permanent --add-port={CFG.get('server-port', 25565)}/tcp{cl('0')}")
        print(f"   {cl('w')}sudo firewall-cmd --reload{cl('0')}")
        print()
        print(f" {cl('C')}Linux - iptables{cl('0')}")
        print(f" {cl('k')}---{cl('0')}")
        print(f"   {cl('w')}sudo iptables -A INPUT -p tcp --dport {CFG.get('server-port', 25565)} -j ACCEPT{cl('0')}")
        print(f"   {cl('w')}sudo iptables-save > /etc/iptables/rules.v4{cl('0')}")
        print()
        print(f" {cl('Y')}Nota:{cl('0')} Revisa que tu router/red tambien reenvie el puerto (port forwarding).")

    print(f"\n{cl('k')} Presiona cualquier tecla para volver...{cl('0')}")
    get_key()


def network_config_menu():
    local_ip = get_local_ip()
    public_ip = None

    while True:
        clear()
        draw_header(1, "Configuracion de Red")
        print()

        if public_ip is None:
            print(f" {cl('c')}IP Publica:{cl('0')} {cl('k')}Obteniendo...{cl('0')}")
        else:
            print(f" {cl('c')}IP Publica:{cl('0')} {cl('w')}{public_ip}{cl('0')}")

        print(f" {cl('c')}IP Local:{cl('0')} {cl('w')}{local_ip}{cl('0')}")

        port = CFG.get('server-port', 25565)
        print(f" {cl('c')}Puerto:{cl('0')} {cl('w')}{port}{cl('0')}")

        port_open = check_port(port)
        if port_open:
            print(f" {cl('c')}Estado:{cl('0')} {cl('G')}Abierto{cl('0')}")
        else:
            print(f" {cl('c')}Estado:{cl('0')} {cl('R')}Cerrado{cl('0')}")

        print()
        print(f" {cl('G')}[T]{cl('0')} Testear puerto")
        print(f" {cl('G')}[F]{cl('0')} Instrucciones de firewall")
        print(f" {cl('G')}[P]{cl('0')} Cambiar puerto")
        print(f" {cl('G')}[R]{cl('0')} Refrescar IPs")
        print(f" {cl('R')}[Q]{cl('0')} Volver")

        key = get_key()
        if key == 'q':
            return
        elif key == 't':
            test_port(port)
        elif key == 'f':
            firewall_instructions()
        elif key == 'p':
            change_port()
        elif key == 'r':
            local_ip = get_local_ip()
            public_ip = get_public_ip()
            toast("IPs actualizadas", 'g')


def test_port(port):
    clear()
    draw_header(1, "Test de Puerto")
    print()
    print(f" {cl('c')}Puerto:{cl('0')} {port}")
    print()

    public_ip = get_public_ip()
    if public_ip:
        print(f" Tu servidor seria accesible en:")
        print(f"   {cl('w')}{public_ip}:{port}{cl('0')}")
        print()

    print(f" {cl('Y')}Verifica en tu router:{cl('0')}")
    print(f"  1. Accede a la config de tu router (192.168.1.1 o similar)")
    print(f"  2. Busca 'Port Forwarding' o 'Reenvio de puertos'")
    print(f"  3. Agrega regla: Puerto {port} -> {get_local_ip()}")
    print(f"  4. Prueba desde: {cl('w')}https://www.yougetsignal.com/tools/open-ports/{cl('0')}")
    print()
    print(f" {cl('k')} Presiona cualquier tecla para volver...{cl('0')}")
    get_key()


def change_port():
    current = CFG.get('server-port', 25565)
    print(f"\n {cl('c')}Puerto actual:{cl('0')} {current}")
    new_port = read_text(f"{cl('c')} Nuevo puerto (Enter para cancelar): {cl('0')}")
    if not new_port:
        return
    try:
        port = int(new_port)
        if port < 1 or port > 65535:
            toast("Puerto invalido (1-65565)", 'r')
            return
    except ValueError:
        toast("Debe ser un numero", 'r')
        return

    CFG['server-port'] = port

    props_file = os.path.join(CFG.get('server_dir', '.'), 'server.properties')
    if os.path.exists(props_file):
        try:
            with open(props_file, 'r') as f:
                lines = f.readlines()
            with open(props_file, 'w') as f:
                for line in lines:
                    if line.startswith('server-port='):
                        f.write(f'server-port={port}\n')
                    else:
                        f.write(line)
        except Exception:
            pass

    from control.core.shared import save_config
    save_config(CFG)
    toast(f"Puerto cambiado a {port}", 'g')
