import os, struct
from control.core.shared import CFG, cl, A, clear, draw_header, get_size, get_key, read_text, notify, toast, download_file

ICON_NAME = "server-icon.png"
ICON_SIZE = 64

def icon_path():
    return os.path.join(CFG['server_dir'], ICON_NAME)

def get_icon_info():
    fp = icon_path()
    if not os.path.exists(fp):
        return None
    try:
        with open(fp, 'rb') as f:
            sig = f.read(8)
            if sig != b'\x89PNG\r\n\x1a\n':
                return {'exists': True, 'valid': False, 'size': os.path.getsize(fp)}
            f.read(4)
            chunk = f.read(4)
            if chunk != b'IHDR':
                return {'exists': True, 'valid': False, 'size': os.path.getsize(fp)}
            data = f.read(13)
            w, h = struct.unpack('>II', data[:8])
            return {'exists': True, 'valid': True, 'width': w, 'height': h,
                    'size': os.path.getsize(fp), 'correct': (w == ICON_SIZE and h == ICON_SIZE)}
    except:
        return {'exists': True, 'valid': False, 'size': 0}

def _process_image(src, dest):
    try:
        from PIL import Image
        img = Image.open(src).convert('RGBA')
        img = img.resize((ICON_SIZE, ICON_SIZE), Image.LANCZOS)
        img.save(dest, 'PNG')
        return True, "Icono ajustado a 64x64"
    except ImportError:
        pass
    except Exception as e:
        return False, f"Error al procesar: {e}"
    try:
        with open(src, 'rb') as f:
            sig = f.read(8)
            if sig != b'\x89PNG\r\n\x1a\n':
                return False, "No es un PNG valido (instala Pillow para convertir otros formatos: pip install Pillow)"
            f.read(4)
            if f.read(4) != b'IHDR':
                return False, "PNG invalido"
            w, h = struct.unpack('>II', f.read(8)[:8])
            if w != ICON_SIZE or h != ICON_SIZE:
                return False, f"Debe ser 64x64 (tu imagen es {w}x{h}). Instala Pillow para redimensionar: pip install Pillow"
        import shutil
        shutil.copy2(src, dest)
        return True, "Icono instalado"
    except Exception as e:
        return False, f"Error: {e}"

def set_icon_from_file(path):
    path = path.strip('"').strip("'")
    if not os.path.exists(path):
        return False, "Archivo no encontrado"
    return _process_image(path, icon_path())

def set_icon_from_url(url):
    import tempfile
    tmp = os.path.join(tempfile.gettempdir(), 'server-icon-dl.png')
    try:
        if not download_file(url, tmp):
            return False, "Error al descargar"
        return _process_image(tmp, icon_path())
    finally:
        try:
            os.remove(tmp)
        except:
            pass

def remove_icon():
    fp = icon_path()
    if not os.path.exists(fp):
        return False, "No hay icono instalado"
    try:
        os.remove(fp)
        return True, "Icono eliminado"
    except Exception as e:
        return False, f"Error: {e}"

def icon_menu():
    while True:
        clear()
        cols = get_size()
        draw_header(1, "ICONO DEL SERVIDOR", "server-icon.png 64x64")
        info = get_icon_info()
        y = 3
        if not info:
            print(f'\033[{y};0H  {cl("k")}Sin icono — en la lista de servidores se vera el icono por defecto{A["0"]}')
        elif not info.get('valid'):
            print(f'\033[{y};0H  {cl("r")}El archivo existe pero no es un PNG valido{A["0"]}')
        elif info.get('correct'):
            print(f'\033[{y};0H  {cl("g")}Icono instalado: 64x64 ({info["size"]//1024} KB){A["0"]}')
        else:
            print(f'\033[{y};0H  {cl("y")}Icono instalado pero mide {info["width"]}x{info["height"]} (Minecraft pide 64x64){A["0"]}')
        y += 2
        print(f'\033[{y};0H  {cl("c")}[A]{A["0"]} Desde archivo  {cl("c")}[U]{A["0"]} Desde URL  {cl("r")}[B]{A["0"]} Borrar  {cl("k")}[Q]{A["0"]} Volver')
        print(f'\033[{y+1};0H  {cl("k")}Tip: usa una imagen cuadrada para mejor resultado{A["0"]}')
        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'a':
            p = read_text("  Ruta del PNG: ")
            if p:
                ok, msg = set_icon_from_file(p)
                toast(msg, 'g' if ok else 'r')
        elif k == 'u':
            u = read_text("  URL del PNG: ")
            if u:
                ok, msg = set_icon_from_url(u)
                toast(msg, 'g' if ok else 'r')
        elif k == 'b':
            ok, msg = remove_icon()
            toast(msg, 'g' if ok else 'r')
