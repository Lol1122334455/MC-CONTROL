import os, sys, time, subprocess
from control.core.shared import CFG, cl, A, clear, draw_header, get_size, get_key, hide_cursor, show_cursor, IS_WIN
from control.core.server import get_pid, get_server_stats, get_uptime, get_world_size
try:
    from control.core.backup import get_world_size as get_ws
except ImportError:
    get_ws = get_world_size


def get_cpu_usage():
    if IS_WIN:
        try:
            r = subprocess.run(["wmic", "cpu", "get", "LoadPercentage", "/FORMAT:CSV"],
                               capture_output=True, text=True, timeout=5)
            for line in r.stdout.strip().splitlines():
                if 'LoadPercentage' in line or ',' not in line:
                    continue
                parts = line.split(',')
                if len(parts) >= 1 and parts[0].strip():
                    return int(parts[0].strip())
        except:
            pass
        return None
    try:
        with open('/proc/stat', 'r') as f:
            line1 = f.readline()
        vals1 = [int(x) for x in line1.split()[1:]]
        idle1 = vals1[3]
        total1 = sum(vals1)
        time.sleep(1)
        with open('/proc/stat', 'r') as f:
            line2 = f.readline()
        vals2 = [int(x) for x in line2.split()[1:]]
        idle2 = vals2[3]
        total2 = sum(vals2)
        idle_d = idle2 - idle1
        total_d = total2 - total1
        if total_d == 0:
            return 0
        return max(0, min(100, int((1 - idle_d / total_d) * 100)))
    except:
        return None


def _bar_color(pct):
    if pct < 50:
        return 'g'
    if pct <= 80:
        return 'y'
    return 'r'


def performance_monitor():
    clear()
    hide_cursor()
    try:
        _monitor_loop()
    except KeyboardInterrupt:
        pass
    finally:
        show_cursor()
        clear()
        print(f"{cl('c')}Monitor cerrado.{A['0']}")


def _monitor_loop():
    cols = get_size()
    w = cols.columns
    h = cols.lines
    while True:
        cols = get_size()
        w = cols.columns
        h = cols.lines
        clear()
        draw_header(1, "MONITOR DE RENDIMIENTO", "Ctrl+C o Q para salir")

        stats = get_server_stats()
        uptime = get_uptime()
        world = get_world_size()
        players = []
        try:
            players = _get_online_players()
        except:
            pass
        cpu = get_cpu_usage()

        y = 5
        ram_used = stats['ram'] if stats and stats.get('ram') else 0
        threads = stats['threads'] if stats and stats.get('threads') else 0
        max_ram = 8192
        for arg in sys.argv:
            pass
        for opt in ['-Xmx']:
            pass
        mx_val = CFG.get('max_ram', '')
        if not mx_val:
            try:
                jar = CFG.get('jar_path', '')
                if jar and os.path.exists(os.path.dirname(jar)):
                    props = os.path.join(CFG['server_dir'], 'server.properties')
                    if os.path.exists(props):
                        with open(props, 'r') as f:
                            for ln in f:
                                if ln.strip().startswith('max-tick-time'):
                                    pass
            except:
                pass
        mx_str = CFG.get('java_args', '')
        if '-Xmx' in str(mx_str):
            try:
                idx = str(mx_str).index('-Xmx')
                sub = str(mx_str)[idx+4:]
                num = ''
                for ch in sub:
                    if ch.isdigit():
                        num += ch
                    else:
                        break
                if num:
                    max_ram = int(num)
            except:
                pass
        if hasattr(os, 'getenv'):
            env_mx = os.environ.get('JAVA_MAX_RAM', '')
            if env_mx and env_mx.isdigit():
                max_ram = int(env_mx)

        ram_pct = min(100, int(ram_used * 100 / max_ram)) if max_ram > 0 else 0
        ram_color = _bar_color(ram_pct)
        bar_w = min(40, w - 30)
        filled = int(bar_w * ram_pct / 100)
        bar = f'{cl(ram_color)}{"█" * filled}{cl("k")}{"░" * (bar_w - filled)}{A["0"]}'

        print(f'\033[{y};2H{cl("c")}RAM:{A["0"]}  {bar}  {cl(ram_color)}{ram_pct}%{A["0"]}  {cl("k")}({ram_used}/{max_ram} MB){A["0"]}')
        y += 2

        thread_color = 'g' if threads < 50 else ('y' if threads < 100 else 'r')
        print(f'\033[{y};2H{cl("c")}Hilos:{A["0"]}  {cl(thread_color)}{threads}{A["0"]}')
        y += 2

        uptime_str = "Offline" if uptime is None else _fmt_uptime(uptime)
        u_color = 'r' if uptime is None else 'g'
        print(f'\033[{y};2H{cl("c")}Uptime:{A["0"]}  {cl(u_color)}{uptime_str}{A["0"]}')
        y += 2

        if world is not None:
            if world >= 1073741824:
                ws = f"{world / 1073741824:.2f} GB"
            elif world >= 1048576:
                ws = f"{world / 1048576:.1f} MB"
            elif world >= 1024:
                ws = f"{world / 1024:.1f} KB"
            else:
                ws = f"{world} B"
        else:
            ws = "N/A"
        print(f'\033[{y};2H{cl("c")}Mundo:{A["0"]}  {cl("w")}{ws}{A["0"]}')
        y += 2

        if cpu is not None:
            cpu_color = _bar_color(cpu)
            cpu_bar_w = min(30, w - 35)
            cpu_filled = int(cpu_bar_w * cpu / 100)
            cpu_bar = f'{cl(cpu_color)}{"█" * cpu_filled}{cl("k")}{"░" * (cpu_bar_w - cpu_filled)}{A["0"]}'
            print(f'\033[{y};2H{cl("c")}CPU:{A["0"]}   {cpu_bar}  {cl(cpu_color)}{cpu}%{A["0"]}')
        else:
            print(f'\033[{y};2H{cl("c")}CPU:{A["0"]}   {cl("k")}N/A{A["0"]}')
        y += 2

        pcount = len(players)
        p_color = 'g' if pcount > 0 else 'k'
        print(f'\033[{y};2H{cl("c")}Jugadores:{A["0"]}  {cl(p_color)}{pcount} en linea{A["0"]}')
        y += 1
        if players:
            names = ", ".join(players)
            max_names_w = w - 6
            if len(names) > max_names_w:
                names = names[:max_names_w - 3] + "..."
            print(f'\033[{y};4H{cl("w")}{names}{A["0"]}')
        y += 2

        bar_y = h - 3
        print(f'\033[{bar_y};0H{cl("k")}{"─" * w}{A["0"]}')
        print(f'\033[{bar_y+1};0H {cl("k")}Presiona {cl("w")}Q{cl("k")} para salir  {cl("k")}│  Actualizando cada 2s{A["0"]}')

        sys.stdout.flush()

        for _ in range(20):
            key = get_key()
            if key in ('q', 'ctrl-c'):
                return
            time.sleep(0.1)


def _fmt_uptime(secs):
    if secs is None:
        return "Offline"
    d = secs // 86400
    h = (secs % 86400) // 3600
    m = (secs % 3600) // 60
    parts = []
    if d:
        parts.append(f"{d}d")
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    return " ".join(parts) if parts else "<1m"


def _get_online_players():
    from control.core.server import get_players
    return get_players()
