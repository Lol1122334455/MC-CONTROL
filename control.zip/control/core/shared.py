import os, sys, subprocess, signal, shutil, time, datetime, re, json, threading

IS_WIN = os.name == 'nt'
if IS_WIN:
    import msvcrt
else:
    import tty, termios, select

VERSION = "1.0.0"

if getattr(sys, 'frozen', False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
CFG_FILE = os.path.join(BASE_DIR, "control_config.json")

DEFAULTS = {
    "server_dir": BASE_DIR,
    "java_path": "",
    "jar_path": "",
    "jar_name": "server",
    "log_file": "",
    "server_name": "Minecraft Server",
    "server_description": "",
    "server_version": "",
    "rcon_host": "127.0.0.1",
    "rcon_port": 25575,
    "rcon_password": "minecraft",
    "theme": "default",
    "backup_keep_days": 30,
    "auto_restart_crash": False,
    "curseforge_api_key": "",
    "mod_loader": "auto",
    "first_run": True
}

A = {
    'r': '\033[91m', 'g': '\033[92m', 'y': '\033[93m', 'b': '\033[94m',
    'p': '\033[95m', 'c': '\033[96m', 'w': '\033[97m', 'k': '\033[90m',
    'R': '\033[91;1m', 'G': '\033[92;1m', 'Y': '\033[93;1m', 'B': '\033[94;1m',
    'P': '\033[95;1m', 'C': '\033[96;1m', 'W': '\033[97m',
    '0': '\033[0m', '_': '\033[7m', 'I': '\033[3m',
    'Kb': '\033[48;5;236m', 'Rb': '\033[48;5;88m', 'Gb': '\033[48;5;22m',
    'Yb': '\033[48;5;58m', 'Bb': '\033[48;5;24m', 'Pb': '\033[48;5;54m',
    'Cb': '\033[48;5;23m', 'Wb': '\033[48;5;237m',
}

THEMES = {
    "default": {
        "title": ("C", "Kb"), "sel": ("G", "Kb"), "normal": ("w", "Kb"),
        "header": ("c", "Kb"), "sep": ("k", "Kb"), "status_on": ("G", "Kb"),
        "status_off": ("R", "Kb"), "accent": ("y", "Kb"), "box": ("k", "Kb"),
        "bg": "Kb", "label": "Por Defecto"
    },
    "ocean": {
        "title": ("C", "Kb"), "sel": ("c", "Kb"), "normal": ("w", "Kb"),
        "header": ("C", "Kb"), "sep": ("k", "Kb"), "status_on": ("c", "Kb"),
        "status_off": ("r", "Kb"), "accent": ("b", "Kb"), "box": ("k", "Kb"),
        "bg": "Kb", "label": "Oceano"
    },
    "lava": {
        "title": ("R", "Kb"), "sel": ("y", "Kb"), "normal": ("w", "Kb"),
        "header": ("R", "Kb"), "sep": ("k", "Kb"), "status_on": ("y", "Kb"),
        "status_off": ("r", "Kb"), "accent": ("R", "Kb"), "box": ("k", "Kb"),
        "bg": "Kb", "label": "Lava"
    },
    "forest": {
        "title": ("G", "Kb"), "sel": ("g", "Kb"), "normal": ("w", "Kb"),
        "header": ("G", "Kb"), "sep": ("k", "Kb"), "status_on": ("g", "Kb"),
        "status_off": ("r", "Kb"), "accent": ("y", "Kb"), "box": ("k", "Kb"),
        "bg": "Kb", "label": "Bosque"
    },
    "night": {
        "title": ("p", "Kb"), "sel": ("P", "Kb"), "normal": ("k", "Kb"),
        "header": ("p", "Kb"), "sep": ("k", "Kb"), "status_on": ("g", "Kb"),
        "status_off": ("r", "Kb"), "accent": ("b", "Kb"), "box": ("k", "Kb"),
        "bg": "Kb", "label": "Noche"
    },
}

CRASH_EVENT = threading.Event()
SERVER_PROC = None

def cl(c):
    return A.get(c, A['0'])

def ts(c, bg=""):
    return (A.get(c, '') + A.get(bg, ''))

def clear():
    print('\033[2J\033[H', end='', flush=True)

def hide_cursor():
    print('\033[?25l', end='', flush=True)

def show_cursor():
    print('\033[?25h', end='', flush=True)

def goto(y, x=0):
    print(f'\033[{y};{x+1}H', end='', flush=True)

def cwrite(y, x, text, color='w', bg=''):
    print(f'\033[{y};{x+1}H{ts(color,bg)}{text}{A["0"]}', end='', flush=True)

def draw_box(y, x, h, w, col='k'):
    c = cl(col)
    r = A['0']
    top = f'{c}┌{"─"*(w-2)}┐{r}'
    mid = f'{c}│{" "*(w-2)}│{r}'
    bot = f'{c}└{"─"*(w-2)}┘{r}'
    print(f'\033[{y};{x+1}H{top}')
    for i in range(1, h-1):
        print(f'\033[{y+i};{x+1}H{mid}')
    print(f'\033[{y+h-1};{x+1}H{bot}')

def draw_progress_bar(y, x, w, pct, col='c'):
    fw = max(w - 2, 2)
    filled = int(fw * min(pct, 100) / 100)
    bar = f'{cl(col)}{"█"*filled}{cl("k")}{"░"*(fw-filled)}{A["0"]}'
    print(f'\033[{y};{x+1}H{bar}')

def get_size():
    try:
        return shutil.get_terminal_size()
    except:
        return os.terminal_size((80, 24))

def _get_key_raw():
    if IS_WIN:
        ch = msvcrt.getch()
        if ch == b'\xe0':
            ch2 = msvcrt.getch()
            return {'H': 'up', 'P': 'down', 'M': 'right', 'K': 'left', 'G': 'home', 'O': 'end'}.get(ch2.decode(), 'esc')
        ch = ch.decode()
        if ch == '\r': return 'enter'
        if ch == '\x7f' or ch == '\b': return 'backspace'
        if ch == '\x03': return 'ctrl-c'
        if ch == '\x1b': return 'esc'
        return ch.lower()
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = os.read(fd, 1)
        if not ch:
            return ''
        ch = ch.decode()
        if ch == '\x1b':
            r, _, _ = select.select([fd], [], [], 0.1)
            if r:
                seq = os.read(fd, 2).decode()
                if seq == '[A': return 'up'
                if seq == '[B': return 'down'
                if seq == '[C': return 'right'
                if seq == '[D': return 'left'
                if seq == '[H': return 'home'
                if seq == '[F': return 'end'
            return 'esc'
        if ch == '\r' or ch == '\n': return 'enter'
        if ch == '\x7f' or ch == '\b': return 'backspace'
        if ch == '\x03': return 'ctrl-c'
        if ch == '\t': return 'tab'
        return ch.lower()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

def get_key():
    k = _get_key_raw()
    if k == ' ': return 'space'
    return k

def read_text(prompt="", default=""):
    if IS_WIN:
        try:
            val = input(prompt)
            return val if val.strip() else default
        except (KeyboardInterrupt, EOFError):
            return None
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
    try:
        val = input(prompt)
        return val if val.strip() else default
    except (KeyboardInterrupt, EOFError):
        return None

def confirm(prompt):
    if IS_WIN:
        try:
            return input(prompt).strip().lower() in ('s', 'si', 'y', 'yes')
        except:
            return False
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    termios.tcsetattr(fd, termios.TCSADRAIN, old)
    try:
        return input(prompt).strip().lower() in ('s', 'si', 'y', 'yes')
    except:
        return False

def auto_detect_java(sd):
    if sd:
        for root, dirs, files in os.walk(sd):
            if 'java' in files:
                jp = os.path.join(root, 'java')
                if os.access(jp, os.X_OK):
                    return jp
            for d in dirs:
                if d.startswith('jdk') or d.startswith('java'):
                    jp = os.path.join(root, d, 'bin', 'java')
                    if os.path.exists(jp) and os.access(jp, os.X_OK):
                        return jp
                    break
    j = shutil.which('java')
    if j:
        return j
    return "java"

def load_config():
    if os.path.exists(CFG_FILE):
        try:
            with open(CFG_FILE, 'r') as f:
                cfg = json.load(f)
            for k in DEFAULTS:
                if k not in cfg:
                    cfg[k] = DEFAULTS[k]
            for k in list(cfg.keys()):
                if k not in DEFAULTS:
                    del cfg[k]
            if not cfg.get('java_path') or not os.path.exists(cfg.get('java_path', '')):
                cfg['java_path'] = auto_detect_java(cfg.get('server_dir'))
            if not cfg.get('log_file'):
                cfg['log_file'] = os.path.join(cfg.get('server_dir', '.'), 'server.log')
            if not cfg.get('jar_name') and cfg.get('jar_path'):
                cfg['jar_name'] = os.path.basename(cfg['jar_path']).replace('.jar', '')
            return cfg
        except:
            return dict(DEFAULTS)
    cfg = dict(DEFAULTS)
    cfg['java_path'] = auto_detect_java(cfg.get('server_dir'))
    cfg['log_file'] = os.path.join(cfg.get('server_dir', '.'), 'server.log')
    return cfg

def save_config(cfg):
    os.makedirs(os.path.dirname(CFG_FILE) or '.', exist_ok=True)
    with open(CFG_FILE, 'w') as f:
        json.dump(cfg, f, indent=2)

CFG = load_config()

def get_t(k, default='w'):
    t = THEMES.get(CFG.get('theme', 'default'), THEMES['default'])
    val = t.get(k, ('w',''))
    if isinstance(val, str):
        return (val, '')
    return val

def tc(key):
    c, bg = get_t(key)
    return ts(c, bg)

def get_bg():
    t = THEMES.get(CFG.get('theme', 'default'), THEMES['default'])
    bg_key = t.get('bg', 'Kb')
    if isinstance(bg_key, str):
        return A.get(bg_key, '')
    return A.get(bg_key[1], '')

def bg_set():
    bg = get_bg()
    return f'{bg}\033[2J' if bg else '\033[2J'

def draw_header(y, title, subtitle=""):
    cols = get_size()
    w = cols.columns
    tl = tc('title')
    bo = tc('box')
    bgs = bg_set()
    print(f'\033[{y};0H{bgs}{bo}┌{"─"*(w-2)}┐{A["0"]}')
    y += 1
    hdr = f' {title} '
    if subtitle:
        hdr += f'{cl("k")}│{A["0"]} {subtitle}'
    pad = w - 4 - len(hdr)
    lp = pad // 2
    rp = pad - lp
    print(f'\033[{y};0H{bo}│{A["0"]}{" "*lp}{tl}{hdr}{A["0"]}{" "*rp}{bo}│{A["0"]}')
    y += 1
    print(f'\033[{y};0H{bo}└{"─"*(w-2)}┘{A["0"]}')

def draw_footer(y, text="[Q] Salir  [Enter] Seleccionar"):
    cols = get_size()
    w = cols.columns
    bo = tc('box')
    print(f'\033[{y};0H{bo}┌{"─"*(w-2)}┐{A["0"]}')
    y += 1
    inner = f' {cl("k")}{text}{A["0"]} '
    pad = w - 4 - len(inner)
    print(f'\033[{y};0H{bo}│{A["0"]}{inner}{" "*pad}{bo}│{A["0"]}')
    y += 1
    print(f'\033[{y};0H{bo}└{"─"*(w-2)}┘{A["0"]}')

def notify(msg, color='y'):
    cols = get_size()
    w = cols.columns
    bgs = bg_set()
    print(f'{bgs}')
    print(f'\033[{cols.lines//2};{(w-len(msg))//2}H{cl(color)}{msg}{A["0"]}')
    time.sleep(1.5)

def notify_long(msg, color='y'):
    cols = get_size()
    w = cols.columns
    bgs = bg_set()
    print(f'{bgs}')
    lines = [l for l in msg.split('\n') if l]
    sy = cols.lines // 2 - len(lines) // 2
    for i, l in enumerate(lines):
        print(f'\033[{sy+i};{(w-len(l))//2}H{cl(color)}{l}{A["0"]}')
    print(f'\033[{sy+len(lines)+1};0H  Presiona cualquier tecla...')
    _get_key_raw()

def fmt_size(b):
    for u in ['B','KB','MB','GB','TB']:
        if b < 1024:
            return f"{b:.1f}{u}"
        b /= 1024
    return f"{b:.1f}PB"

def fmt_time(secs):
    if secs is None:
        return "N/A"
    d = secs // 86400
    h = (secs % 86400) // 3600
    m = (secs % 3600) // 60
    s = secs % 60
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s and not d: parts.append(f"{s}s")
    return " ".join(parts) or "0s"

def detect_mod_loader(jar_name=""):
    name = jar_name.lower()
    if 'forge' in name: return 'forge'
    if 'fabric' in name: return 'fabric'
    if 'quilt' in name: return 'quilt'
    if 'neoforge' in name: return 'neoforge'
    if 'paper' in name: return 'paper'
    if 'purpur' in name: return 'purpur'
    if 'spigot' in name: return 'spigot'
    if 'bukkit' in name: return 'bukkit'
    if 'mohist' in name: return 'mohist'
    if 'catserver' in name: return 'catserver'
    if 'pufferfish' in name: return 'pufferfish'
    if 'tuinity' in name: return 'tuinity'
    if 'spongevanilla' in name or 'sponge' in name: return 'spongevanilla'
    if 'spongeforge' in name: return 'spongeforge'
    if 'cardboard' in name: return 'cardboard'
    if 'banner' in name: return 'banner'
    if 'legacyfabric' in name or 'legacy-fabric' in name: return 'legacyfabric'
    return 'vanilla'

def is_empty_server_dir(path):
    if not os.path.exists(path):
        return True
    for f in os.listdir(path):
        if f.endswith('.jar'):
            return False
    return True

def get_log_tail(n=10):
    try:
        if IS_WIN:
            with open(CFG['log_file'], 'r') as f:
                lines = f.readlines()
            return lines[-n:]
        r = subprocess.run(["tail", "-n", str(n), CFG['log_file']], capture_output=True, text=True, timeout=5)
        return r.stdout.splitlines()
    except:
        return []

def download_file(url, dest_path):
    import urllib.request, ssl
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        ctx = ssl._create_unverified_context()
        with urllib.request.urlopen(req, timeout=600, context=ctx) as r:
            total = int(r.headers.get('Content-Length', 0))
            dl = 0
            with open(dest_path, 'wb') as f:
                while True:
                    data = r.read(65536)
                    if not data:
                        break
                    f.write(data)
                    dl += len(data)
                    if total:
                        pct = int(dl * 100 / total)
                        bar = '█' * (pct // 5) + '░' * (20 - pct // 5)
                        sys.stdout.write(f'\033[K  {cl("c")}{pct}%{cl("0")} [{bar}] {dl/1024/1024:.1f}/{total/1024/1024:.1f} MB\r')
                    else:
                        sys.stdout.write(f'\033[K  {cl("c")}Descargando...{cl("0")} {dl/1024/1024:.1f} MB\r')
                    sys.stdout.flush()
        sys.stdout.write('\033[K')
        sys.stdout.flush()
        return True
    except:
        sys.stdout.write('\033[K')
        sys.stdout.flush()
        return False

_icon_cache = {}

def show_icon(url, max_w=16, max_h=6):
    if len(_icon_cache) > 50:
        _icon_cache.clear()
    if not url:
        return []
    if url in _icon_cache:
        return _icon_cache[url]
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=5) as r:
            data = r.read()
        p = subprocess.run(["chafa", "--format=symbols", "--symbols=block",
                           f"--size={max_w}x{max_h}", "-"], input=data,
                          capture_output=True, timeout=10)
        if p.returncode == 0:
            lines = p.stdout.decode('utf-8', errors='replace').splitlines()
            _icon_cache[url] = lines
            return lines
    except:
        pass
    return []

def get_profiles_dir():
    return os.path.join(CFG['server_dir'], "profiles")

def get_worlds_dir():
    return os.path.join(CFG['server_dir'], "worlds")