import os, re
from control.core.shared import CFG, cl, A, clear, draw_header, get_size, get_key, read_text, notify, show_cursor, IS_WIN, _get_key_raw

PROPS_FILE = os.path.join(CFG['server_dir'], 'server.properties')

COMMON_PROPS = [
    ('server-port', 'Puerto del servidor'),
    ('max-players', 'Maximo de jugadores'),
    ('motd', 'Descripcion del servidor (MOTD)'),
    ('level-name', 'Nombre del mundo'),
    ('difficulty', 'Dificultad'),
    ('gamemode', 'Modo de juego'),
    ('pvp', 'PVP'),
    ('online-mode', 'Modo online'),
    ('view-distance', 'Distancia de vision'),
    ('simulation-distance', 'Distancia de simulacion'),
    ('spawn-protection', 'Proteccion del spawn'),
    ('enable-command-block', 'Bloque de comandos'),
    ('white-list', 'Lista blanca'),
    ('level-seed', 'Semilla del mundo'),
    ('level-type', 'Tipo de mundo'),
    ('generator-settings', 'Configuracion del generador'),
    ('server-ip', 'IP del servidor'),
    ('network-compression-threshold', 'Umbral de compresion'),
    ('rate-limit', 'Limite de velocidad'),
    ('text-filtering-config', 'Filtro de texto'),
    ('require-resource-pack', 'Requiere resource pack'),
    ('resource-pack', 'URL del resource pack'),
    ('resource-pack-sha1', 'SHA1 del resource pack'),
    ('player-idle-timeout', 'Tiempo de inactividad'),
    ('max-tick-time', 'Maximo tick time'),
    ('max-world-size', 'Tamano maximo del mundo'),
    ('spawn-monsters', 'Generar monstruos'),
    ('spawn-animals', 'Generar animales'),
    ('spawn-npcs', 'Generar NPCs'),
    ('allow-flight', 'Permitir vuelo'),
    ('force-gamemode', 'Forzar modo de juego'),
    ('hardcore', 'Hardcore'),
    ('enable-status', 'Mostrar en lista'),
    ('hide-online-players', 'Ocultar jugadores online'),
    ('enforce-secure-profile', 'Perfiles seguros'),
    ('function-permission-level', 'Nivel de permisos de funciones'),
]

BOOLEAN_PROPS = {
    'pvp', 'online-mode', 'enable-command-block', 'white-list',
    'require-resource-pack', 'spawn-monsters', 'spawn-animals',
    'spawn-npcs', 'allow-flight', 'force-gamemode', 'hardcore',
    'enable-status', 'hide-online-players', 'enforce-secure-profile'
}

INTEGER_PROPS = {
    'server-port', 'max-players', 'view-distance', 'simulation-distance',
    'spawn-protection', 'network-compression-threshold', 'rate-limit',
    'player-idle-timeout', 'max-tick-time', 'max-world-size',
    'function-permission-level'
}


def load_properties():
    if not os.path.exists(PROPS_FILE):
        return {}
    props = {}
    try:
        with open(PROPS_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    props[k] = v
    except Exception:
        pass
    return props


def save_properties(props):
    try:
        with open(PROPS_FILE, 'w') as f:
            for k, v in props.items():
                f.write(f"{k}={v}\n")
        return True
    except Exception:
        return False


def get_prop_label(key):
    for k, label in COMMON_PROPS:
        if k == key:
            return label
    return key


def properties_editor_menu():
    props = load_properties()
    if not props:
        notify("No se pudo leer server.properties", 'r')
        return

    common_keys = [k for k, _ in COMMON_PROPS if k in props]
    other_keys = [k for k in props if k not in common_keys]
    all_keys = common_keys + other_keys

    sel = 0
    scroll = 0

    while True:
        cols = get_size()
        w, h = cols.columns, cols.lines
        clear()
        draw_header(1, "SERVER.PROPERTIES", f"{len(all_keys)} propiedades")

        max_vis = h - 7
        if sel < scroll:
            scroll = sel
        if sel >= scroll + max_vis:
            scroll = sel - max_vis + 1

        y = 3
        for i in range(max_vis):
            idx = scroll + i
            if idx >= len(all_keys):
                break
            key = all_keys[idx]
            val = props.get(key, '')
            label = get_prop_label(key)
            marker = "▸" if sel == idx else " "

            if idx < len(common_keys):
                col = 'c'
            else:
                col = 'k'

            val_str = val[:30] + '..' if len(val) > 32 else val
            print(f'\033[{y+i};0H  {marker} {cl(col)}{label}:{A["0"]} {cl("y")}{val_str}{A["0"]}')

        footer_y = h - 3
        print(f'\033[{footer_y};0H  {cl("k")}[W/S] Navegar [Enter] Editar [Q] Volver{A["0"]}')
        pag = f'[{scroll+1}-{min(scroll+max_vis, len(all_keys))}/{len(all_keys)}]'
        print(f'\033[{footer_y+1};0H  {cl("k")}{pag}{A["0"]}')

        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'up' and sel > 0:
            sel -= 1
        elif k == 'down' and sel < len(all_keys) - 1:
            sel += 1
        elif k == 'enter':
            key = all_keys[sel]
            current = props.get(key, '')
            label = get_prop_label(key)

            if key in BOOLEAN_PROPS:
                new_val = edit_boolean(key, current, label)
            elif key in INTEGER_PROPS:
                new_val = edit_integer(key, current, label)
            else:
                new_val = edit_text(key, current, label)

            if new_val is not None and new_val != current:
                props[key] = new_val
                if save_properties(props):
                    notify(f"Guardado: {key}={new_val}", 'g')
                    from control.core.server import get_pid
                    if get_pid():
                        if confirm_restart():
                            from control.core.server import stop, start
                            stop()
                            start()
                            notify("Servidor reiniciado", 'g')
                else:
                    notify("Error al guardar", 'r')


def edit_boolean(key, current, label):
    current_lower = current.lower()
    is_true = current_lower in ('true', 'yes', '1', 'on')

    while True:
        cols = get_size()
        w, h = cols.columns, cols.lines
        clear()
        draw_header(1, f"EDITAR: {label}")

        y = 3
        print(f'\033[{y};0H  {cl("c")}Propiedad:{A["0"]} {key}')
        print(f'\033[{y+1};0H  {cl("c")}Valor actual:{A["0"]} {cl("y")}{current}{A["0"]}')
        print(f'\033[{y+3};0H  {cl("g")}[1]{A["0"]} true  (Activado)')
        print(f'\033[{y+4};0H  {cl("r")}[2]{A["0"]} false (Desactivado)')

        k = get_key()
        if k == '1':
            return 'true'
        elif k == '2':
            return 'false'
        elif k in ('q', 'esc'):
            return None


def edit_integer(key, current, label):
    while True:
        cols = get_size()
        w, h = cols.columns, cols.lines
        clear()
        draw_header(1, f"EDITAR: {label}")

        y = 3
        print(f'\033[{y};0H  {cl("c")}Propiedad:{A["0"]} {key}')
        print(f'\033[{y+1};0H  {cl("c")}Valor actual:{A["0"]} {cl("y")}{current}{A["0"]}')
        print(f'\033[{y+2};0H  {cl("k")}Ingresa un numero entero{A["0"]}')

        val = read_text(f'\033[{y+4};0H  {cl("g")}►{A["0"]} ')
        if val is None:
            return None
        val = val.strip()
        if val == '':
            return None
        try:
            int(val)
            return val
        except ValueError:
            notify("Ingresa un numero valido", 'r')


def edit_text(key, current, label):
    cols = get_size()
    w, h = cols.columns, cols.lines
    clear()
    draw_header(1, f"EDITAR: {label}")

    y = 3
    print(f'\033[{y};0H  {cl("c")}Propiedad:{A["0"]} {key}')
    print(f'\033[{y+1};0H  {cl("c")}Valor actual:{A["0"]} {cl("y")}{current}{A["0"]}')

    val = read_text(f'\033[{y+3};0H  {cl("g")}►{A["0"]} ')
    if val is None:
        return None
    return val


def confirm_restart():
    cols = get_size()
    w, h = cols.columns, cols.lines
    clear()
    draw_header(1, "REINICIAR SERVIDOR")
    y = 3
    print(f'\033[{y};0H  {cl("y")}Los cambios requieren reiniciar el servidor.{A["0"]}')
    print(f'\033[{y+1};0H  {cl("y")}Reiniciar ahora?{A["0"]}')
    print(f'\033[{y+3};0H  {cl("g")}[S]{A["0"]} Si, reiniciar')
    print(f'\033[{y+4};0H  {cl("r")}[N]{A["0"]} No, reiniciar despues')

    while True:
        k = get_key()
        if k == 's':
            return True
        elif k == 'n':
            return False
        elif k in ('q', 'esc'):
            return False


def motd_editor():
    from control.core.servericon import get_icon_info, icon_menu
    props = load_properties()
    current_motd = props.get('motd', '')

    while True:
        cols = get_size()
        w, h = cols.columns, cols.lines
        clear()
        draw_header(1, "MOTD E ICONO", "Descripcion y logo del servidor")

        y = 3
        print(f'\033[{y};0H  {cl("c")}MOTD actual:{A["0"]}')
        print(f'\033[{y+1};0H  {cl("y")}{current_motd}{A["0"]}')
        print(f'\033[{y+2};0H')
        print(f'\033[{y+3};0H  {cl("c")}Vista previa con colores:{A["0"]}')
        print(f'\033[{y+4};0H  {render_motd(current_motd)}{A["0"]}')
        info = get_icon_info()
        if not info:
            print(f'\033[{y+5};0H  {cl("k")}Icono: sin icono (se vera el predeterminado){A["0"]}')
        elif info.get('correct'):
            print(f'\033[{y+5};0H  {cl("g")}Icono: 64x64 instalado{A["0"]}')
        else:
            print(f'\033[{y+5};0H  {cl("y")}Icono: instalado pero no es 64x64{A["0"]}')
        print(f'\033[{y+6};0H  {cl("k")}Codigos de formato:{A["0"]}')
        print(f'\033[{y+7};0H  {cl("g")}§a{A["0"]} Verde  {cl("c")}§b{A["0"]} Aqua  {cl("r")}§c{A["0"]} Rojo  {cl("p")}§d{A["0"]} Rosa')
        print(f'\033[{y+8};0H  {cl("y")}§e{A["0"]} Amarillo  §f§mf{A["0"]} Blanco  §0§m0{A["0"]} Negro  {cl("b")}§9{A["0"]} Azul')
        print(f'\033[{y+9};0H  {cl("k")}§l{A["0"]} Negrita  {cl("k")}§o{A["0"]} Italica  {cl("k")}§n{A["0"]} Subrayado  {cl("k")}§m{A["0"]} Tachado')
        print(f'\033[{y+10};0H  {cl("k")}§k{A["0"]} Obfuscado  {cl("k")}§r{A["0"]} Reset')

        footer_y = h - 3
        print(f'\033[{footer_y};0H  {cl("g")}[E]{A["0"]} Editar  {cl("y")}[P]{A["0"]} Previsualizar  {cl("c")}[I]{A["0"]} Icono  {cl("k")}[Q]{A["0"]} Volver')

        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'e':
            new_motd = read_text(f'\033[{y+12};0H  {cl("g")}Nuevo MOTD:{A["0"]} ')
            if new_motd is not None:
                current_motd = new_motd
                props['motd'] = current_motd
                if save_properties(props):
                    notify("MOTD guardado", 'g')
                else:
                    notify("Error al guardar", 'r')
        elif k == 'p':
            preview_motd(current_motd)
        elif k == 'i':
            icon_menu()


def render_motd(text):
    mc_to_ansi = {
        '§0': '\033[30m', '§1': '\033[34m', '§2': '\033[32m', '§3': '\033[36m',
        '§4': '\033[31m', '§5': '\033[35m', '§6': '\033[33m', '§7': '\033[37m',
        '§8': '\033[90m', '§9': '\033[94m', '§a': '\033[92m', '§b': '\033[96m',
        '§c': '\033[91m', '§d': '\033[95m', '§e': '\033[93m', '§f': '\033[97m',
        '§k': '', '§l': '\033[1m', '§m': '', '§n': '\033[4m',
        '§o': '\033[3m', '§r': '\033[0m',
    }

    result = ''
    i = 0
    while i < len(text):
        if i + 1 < len(text) and text[i] == '§':
            code = text[i:i+2]
            if code in mc_to_ansi:
                result += mc_to_ansi[code]
                i += 2
            else:
                result += text[i]
                i += 1
        else:
            result += text[i]
            i += 1

    result += '\033[0m'
    return result


def preview_motd(text):
    cols = get_size()
    w, h = cols.columns, cols.lines
    clear()
    draw_header(1, "VISTA PREVIA MOTD")

    y = 3
    print(f'\033[{y};0H  {cl("k")}En Minecraft se veria asi:{A["0"]}')
    print(f'\033[{y+2};0H  {render_motd(text)}{A["0"]}')
    print(f'\033[{y+4};0H  {cl("k")}Texto original:{A["0"]}')
    print(f'\033[{y+5};0H  {text}{A["0"]}')

    print(f'\033[{h-2};0H  {cl("k")}[Qualquier tecla] Volver{A["0"]}')
    _get_key_raw()



