import os, sys, json, urllib.request, zipfile, io, tempfile, shutil, subprocess, time
from control.core.shared import VERSION, BASE_DIR, IS_WIN, notify, confirm, clear, draw_header, cl, A, get_key, get_size

RAW_URL = "https://raw.githubusercontent.com/Lol1122334455/MC-CONTROL/main/actualizacion.json"
ZIP_URL = "https://raw.githubusercontent.com/Lol1122334455/MC-CONTROL/main/control.zip"
PY_URL = "https://raw.githubusercontent.com/Lol1122334455/MC-CONTROL/main/control.py"
EXE_URL = "https://raw.githubusercontent.com/Lol1122334455/MC-CONTROL/main/control.exe"

API_URL = "https://api.github.com/repos/Lol1122334455/MC-CONTROL/contents/actualizacion.json"

def _ua():
    return {"User-Agent": "MC-CONTROL-updater/1.0"}

def _is_newer(latest):
    try:
        cur_parts = [int(x) for x in VERSION.split('.')]
        lat_parts = [int(x) for x in latest.split('.')]
        return lat_parts > cur_parts
    except:
        return True

def _fetch_raw():
    req = urllib.request.Request(RAW_URL, headers=_ua())
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

def _fetch_api():
    import base64
    req = urllib.request.Request(API_URL, headers=_ua())
    with urllib.request.urlopen(req, timeout=15) as r:
        data = json.loads(r.read())
    return json.loads(base64.b64decode(data['content']).decode())

def check_update():
    remote = None
    try:
        remote = _fetch_raw()
    except:
        remote = None
    latest = (remote or {}).get('version', '').lstrip('v') if remote else ''
    if not latest or not _is_newer(latest):
        try:
            remote = _fetch_api()
        except:
            return None
        latest = (remote or {}).get('version', '').lstrip('v') if remote else ''
        if not latest or not _is_newer(latest):
            return None
    return {'version': latest, 'notes': (remote or {}).get('notes', '')}

def _restart_self():
    python = sys.executable
    if getattr(sys, 'frozen', False):
        script = os.path.join(BASE_DIR, '_updater.bat') if IS_WIN else os.path.join(BASE_DIR, '_updater.sh')
        if IS_WIN:
            with open(script, 'w') as f:
                f.write('@echo off\n')
                f.write('timeout /t 2 /nobreak > nul\n')
                f.write(f'start "" "{python}"\n')
                f.write('del "%~f0"\n')
        else:
            with open(script, 'w') as f:
                f.write('#!/bin/sh\n')
                f.write('sleep 2\n')
                f.write(f'exec "{python}" "$@"\n')
                f.write('rm -f "$0"\n')
            os.chmod(script, 0o755)
        os._exit(0)
    else:
        os.execv(python, [python] + sys.argv[:])

def do_update():
    info = check_update()
    if not info:
        notify("Ya tienes la version mas reciente", 'g')
        return False
    clear()
    cols = get_size()
    draw_header(1, "ACTUALIZACION DISPONIBLE", f"v{VERSION} -> v{info['version']}")
    y = 3
    print(f'\033[{y};0H  {cl("c")}Nueva version: v{info["version"]}{A["0"]}')
    y += 2
    if info['notes']:
        for line in info['notes'].split('\n'):
            print(f'\033[{y};0H  {cl("y")}{line}{A["0"]}')
            y += 1
    y += 1
    print(f'\033[{y};0H  {cl("g")}[S]{A["0"]} Actualizar  {cl("k")}[N]{A["0"]} Cancelar')
    k = get_key()
    if k not in ('s', 'S'):
        return False
    clear()
    draw_header(1, "ACTUALIZANDO", f"v{info['version']}")
    print(f'\033[{3};0H  {cl("y")}Descargando actualizacion...{A["0"]}')
    sys.stdout.flush()
    is_frozen = getattr(sys, 'frozen', False)
    tmp = os.path.join(tempfile.gettempdir(), 'control_update.zip')

    def _dl(url, dest):
        req = urllib.request.Request(url, headers=_ua())
        with urllib.request.urlopen(req, timeout=300) as r:
            with open(dest, 'wb') as f:
                while True:
                    data = r.read(65536)
                    if not data:
                        break
                    f.write(data)

    try:
        if is_frozen:
            exe_path = sys.executable
            tmp_exe = os.path.join(tempfile.gettempdir(), 'control_new.exe')
            _dl(EXE_URL, tmp_exe)
            if IS_WIN:
                script = os.path.join(BASE_DIR, '_updater.bat')
                with open(script, 'w') as f:
                    f.write('@echo off\n')
                    f.write('timeout /t 2 /nobreak > nul\n')
                    f.write(f'copy /y "{tmp_exe}" "{exe_path}" > nul\n')
                    f.write(f'start "" "{exe_path}"\n')
                    f.write('del "%~f0"\n')
            else:
                script = os.path.join(BASE_DIR, '_updater.sh')
                with open(script, 'w') as f:
                    f.write('#!/bin/sh\n')
                    f.write('sleep 2\n')
                    f.write(f'cp "{tmp_exe}" "{exe_path}"\n')
                    f.write(f'chmod +x "{exe_path}"\n')
                    f.write(f'exec "{exe_path}"\n')
                    f.write('rm -f "$0"\n')
                os.chmod(script, 0o755)
            print(f'\033[{4};0H  {cl("g")}Reiniciando...{A["0"]}')
            sys.stdout.flush()
            time.sleep(1)
            os._exit(0)
        else:
            _dl(ZIP_URL, tmp)
            _dl(PY_URL, os.path.join(BASE_DIR, 'control.py'))
            control_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            bak = control_dir + '_bak'
            if os.path.exists(bak):
                shutil.rmtree(bak)
            try:
                shutil.copytree(control_dir, bak)
            except:
                pass
            with zipfile.ZipFile(tmp, 'r') as z:
                z.extractall(control_dir)
            try:
                os.remove(tmp)
            except:
                pass
            print(f'\033[{4};0H  {cl("g")}Actualizacion completada (backup en {bak}){A["0"]}')
            sys.stdout.flush()
            time.sleep(2)
            notify("Reinicia el programa para usar la nueva version", 'g')
            return True
    except Exception as e:
        notify(f"Error: {e}", 'r')
        return False