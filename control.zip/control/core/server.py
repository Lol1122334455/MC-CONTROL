import os, sys, subprocess, signal, time, re, threading, datetime
from control.core.shared import SERVER_PROC, CFG, A, cl, notify, get_key, get_size, bg_set, IS_WIN

def get_pid():
    global SERVER_PROC
    if SERVER_PROC and SERVER_PROC.poll() is None:
        return SERVER_PROC.pid
    jar_target = os.path.basename(CFG.get('jar_path', '')).replace('.jar', '') or CFG.get('jar_name', 'server')
    if IS_WIN:
        try:
            r = subprocess.run(["wmic", "process", "where", "name like '%java%'", "get", "ProcessId,CommandLine", "/FORMAT:CSV"],
                              capture_output=True, text=True, timeout=5)
            for line in r.stdout.strip().splitlines():
                if ',' not in line:
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    pid_str, cmd = parts[0].strip(), parts[1].strip() if len(parts) > 1 else ''
                    if cmd and 'java' in cmd.lower() and jar_target in cmd:
                        try:
                            return int(pid_str)
                        except:
                            pass
        except:
            pass
        return None
    try:
        r = subprocess.run(["pgrep", "-f", "java"], capture_output=True, text=True, timeout=3)
        if r.stdout.strip():
            for pid_str in r.stdout.strip().splitlines():
                pid = int(pid_str.strip())
                try:
                    with open(f'/proc/{pid}/cmdline', 'rb') as f:
                        raw = f.read()
                    cmd = raw.replace(b'\x00', b' ').decode('utf-8', errors='replace')
                    if 'java' in cmd and jar_target in cmd:
                        return pid
                except:
                    pass
    except:
        pass
    try:
        for entry in os.listdir('/proc'):
            if entry.isdigit():
                try:
                    with open(f'/proc/{entry}/cmdline', 'rb') as f:
                        raw = f.read()
                    cmd = raw.replace(b'\x00', b' ').decode('utf-8', errors='replace')
                    if 'java' in cmd and jar_target in cmd:
                        return int(entry)
                except:
                    pass
    except:
        pass
    return None

def get_uptime():
    pid = get_pid()
    if not pid:
        return None
    if IS_WIN:
        try:
            r = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "CreationDate", "/FORMAT:CSV"],
                              capture_output=True, text=True, timeout=5)
            for line in r.stdout.strip().splitlines():
                if 'CreationDate' in line or ',' not in line:
                    continue
                parts = line.split(',')
                if len(parts) >= 1 and parts[0].strip():
                    cdate = parts[0].strip()
                    epoch = datetime.datetime(1970, 1, 1)
                    created = datetime.datetime.strptime(cdate.split('.')[0], '%Y%m%d%H%M%S')
                    return int((created - epoch).total_seconds())
        except:
            pass
        return None
    try:
        with open(f'/proc/{pid}/stat', 'r') as f:
            parts = f.read().split()
        bt = time.time() - os.path.getmtime(f'/proc/{pid}/stat')
        return int(bt)
    except:
        return None

def get_server_stats():
    pid = get_pid()
    if not pid:
        return None
    if IS_WIN:
        try:
            r = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "WorkingSetSize,ThreadCount", "/FORMAT:CSV"],
                              capture_output=True, text=True, timeout=5)
            for line in r.stdout.strip().splitlines():
                if 'WorkingSetSize' in line or ',' not in line:
                    continue
                parts = line.split(',')
                if len(parts) >= 2:
                    ram_bytes = parts[0].strip()
                    threads = parts[1].strip()
                    ram_mb = int(ram_bytes) // (1024 * 1024) if ram_bytes else None
                    th = int(threads) if threads else None
                    return {'ram': ram_mb, 'threads': th}
        except:
            pass
        return None
    try:
        with open(f'/proc/{pid}/status', 'r') as f:
            ram = None
            threads = None
            for line in f:
                if line.startswith('VmRSS:'):
                    ram = int(line.split()[1]) // 1024
                if line.startswith('Threads:'):
                    threads = int(line.split()[1])
            return {'ram': ram, 'threads': threads}
    except:
        return None

def get_world_size():
    wd = os.path.join(CFG['server_dir'], 'world')
    if not os.path.exists(wd):
        return None
    total = 0
    try:
        for dirpath, dirnames, filenames in os.walk(wd):
            for f in filenames:
                try:
                    total += os.path.getsize(os.path.join(dirpath, f))
                except:
                    pass
    except:
        pass
    return total

def rcon_connect():
    try:
        from mcrcon import MCRcon
        return MCRcon(CFG['rcon_host'], CFG['rcon_password'], port=CFG['rcon_port'])
    except ImportError:
        try:
            py_ver = f"python{sys.version_info.major}.{sys.version_info.minor}"
            pip_path = os.path.expanduser(f"~/.local/lib/{py_ver}/site-packages")
            sys.path.insert(0, pip_path)
            from mcrcon import MCRcon
            return MCRcon(CFG['rcon_host'], CFG['rcon_password'], port=CFG['rcon_port'])
        except ImportError:
            pass
    return None

def send_rcon(cmd):
    try:
        m = rcon_connect()
        if m:
            with m:
                resp = m.command(cmd)
                return resp
    except:
        pass
    return None

def write_stdin(text):
    global SERVER_PROC
    if SERVER_PROC and SERVER_PROC.poll() is None and SERVER_PROC.stdin:
        try:
            SERVER_PROC.stdin.write(text + "\n")
            SERVER_PROC.stdin.flush()
            return True
        except:
            pass
    return False

def send_cmd(cmd):
    r = send_rcon(cmd)
    if r is not None:
        return True
    return write_stdin(cmd)

def start():
    global SERVER_PROC
    if get_pid():
        return False, "Ya esta corriendo"
    jp = CFG['java_path']
    if not jp or not os.path.exists(jp):
        return False, f"Java no encontrado en {jp}. Reinstala el servidor."
    try:
        popen_kwargs = {
            'stdout': open(CFG['log_file'], "w"),
            'stderr': subprocess.STDOUT,
            'stdin': subprocess.PIPE,
            'cwd': CFG['server_dir'],
        }
        if not IS_WIN:
            popen_kwargs['start_new_session'] = True
        proc = subprocess.Popen(
            [jp, "-jar", CFG['jar_path'], "nogui"],
            **popen_kwargs
        )
        SERVER_PROC = proc
        auto_confirm_fml()
        time.sleep(1)
        if not get_pid():
            errors = ""
            try:
                with open(CFG['log_file'], 'r') as f:
                    lines = f.readlines()[-5:]
                    errors = ''.join(lines)
            except:
                pass
            return False, f"El servidor no arranco. Log:\n{errors[-300:]}"
        return True, "Iniciando servidor..."
    except Exception as e:
        return False, f"Error: {e}"

def auto_confirm_fml():
    def monitor():
        time.sleep(5)
        for _ in range(30):
            try:
                with open(CFG['log_file'], 'r') as f:
                    content = f.read()
                if "Run the command /fml confirm" in content:
                    write_stdin("fml confirm")
                    return
            except:
                pass
            time.sleep(2)
    if 'forge' in CFG['jar_name'].lower() or 'fml' in CFG['jar_name'].lower():
        threading.Thread(target=monitor, daemon=True).start()

def stop():
    pid = get_pid()
    if not pid:
        return False, "No esta corriendo"
    send_cmd("stop")
    time.sleep(3)
    for _ in range(10):
        if not get_pid():
            return True, "Servidor detenido"
        time.sleep(1)
    try:
        if IS_WIN:
            subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, timeout=5)
        else:
            os.kill(pid, signal.SIGTERM)
        time.sleep(2)
    except:
        pass
    if not get_pid():
        return True, "Servidor detenido"
    if IS_WIN:
        try:
            subprocess.run(["taskkill", "/F", "/PID", str(pid)], capture_output=True, timeout=5)
            time.sleep(1)
        except:
            pass
        if not get_pid():
            return True, "Servidor detenido"
    return False, "No se pudo detener"

def crash_monitor():
    if IS_WIN:
        return
    while True:
        time.sleep(5)
        if CFG.get('auto_restart_crash'):
            pid = get_pid()
            if pid:
                try:
                    pid2, st = os.waitpid(pid, os.WNOHANG)
                    if pid2:
                        notify("Servidor caido! Reiniciando...", 'r')
                        time.sleep(3)
                        start()
                except:
                    pass

def get_players():
    if not get_pid():
        return []
    players = []
    seen = set()
    try:
        m = rcon_connect()
        if m:
            with m:
                resp = m.command("list")
            if resp:
                m2 = re.findall(r'(?<=: )[A-Za-z0-9_]{1,16}(?:, [A-Za-z0-9_]{1,16})*', resp)
                if m2:
                    names = [n.strip() for n in m2[0].split(',')]
                    for n in names:
                        if n and n not in seen:
                            seen.add(n)
                            players.append(n)
                if players:
                    return players
    except:
        pass
    send_cmd("list")
    time.sleep(1)
    try:
        with open(CFG['log_file'], 'r') as f:
            lines = f.readlines()
        for line in lines[-100:]:
            if "players online:" in line.lower():
                parts = line.split(':')
                if len(parts) >= 2:
                    rest = parts[-1]
                    for n in re.findall(r'[A-Za-z0-9_]{1,16}', rest):
                        if n and len(n) > 1 and n not in seen:
                            seen.add(n)
                            players.append(n)
                break
    except:
        pass
    return players