import os, time, datetime
from control.core.shared import CFG
from control.core.server import get_pid, send_cmd

def load_scheduled_msgs():
    try:
        with open(os.path.join(CFG['server_dir'], "scheduled_msgs.txt"), "r") as f:
            return [{"time": p[0], "msg": p[1], "enabled": p[2] == "1"}
                    for l in f if len((p := l.strip().split("|"))) == 3]
    except:
        return []

def save_scheduled_msgs(msgs):
    with open(os.path.join(CFG['server_dir'], "scheduled_msgs.txt"), "w") as f:
        for m in msgs:
            f.write(f"{m['time']}|{m['msg']}|{'1' if m['enabled'] else '0'}\n")

def load_scheduled_tasks():
    try:
        with open(os.path.join(CFG['server_dir'], "scheduled_tasks.txt"), "r") as f:
            return [{"time": p[0], "action": p[1], "enabled": p[2] == "1", "desc": p[3]}
                    for l in f if len((p := l.strip().split("|"))) == 4]
    except:
        return []

def save_scheduled_tasks(tasks):
    with open(os.path.join(CFG['server_dir'], "scheduled_tasks.txt"), "w") as f:
        for t in tasks:
            f.write(f"{t['time']}|{t['action']}|{'1' if t['enabled'] else '0'}|{t['desc']}\n")

def msg_scheduler_loop():
    last = {}
    while True:
        try:
            if get_pid():
                now = datetime.datetime.now()
                ct = now.strftime("%I:%M%p").lower()
                fp = os.path.join(CFG['server_dir'], "scheduled_msgs.txt")
                if os.path.exists(fp):
                    with open(fp, "r") as f:
                        for line in f:
                            parts = line.strip().split("|")
                            if len(parts) == 3 and parts[0].strip().lower() == ct and parts[2] == "1":
                                k = parts[0] + parts[1]
                                mk = now.strftime("%Y%m%d%H%M")
                                if k not in last or last[k] != mk:
                                    send_cmd(f'tellraw @a {{"text":"[SERVER] {parts[1]}","color":"yellow"}}')
                                    last[k] = mk
        except:
            pass
        time.sleep(30)

def task_scheduler_loop():
    while True:
        try:
            now = datetime.datetime.now()
            ct = now.strftime("%I:%M%p").lower()
            for t in load_scheduled_tasks():
                if t['enabled'] and t['time'].lower() == ct:
                    if t['action'] == 'start':
                        from control.core.server import start
                        start()
                    elif t['action'] == 'stop':
                        from control.core.server import stop
                        stop()
                    elif t['action'] == 'restart':
                        from control.core.server import stop, start
                        stop()
                        time.sleep(3)
                        start()
        except:
            pass
        time.sleep(30)