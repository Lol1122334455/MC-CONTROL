import os, json, time, re, threading, shutil
from control.core.shared import CFG, cl, A, clear, draw_header, get_size, get_key, read_text, notify, confirm, IS_WIN, BASE_DIR, download_file
from control.core.mods import get_mods, mr_versions, cf_files, spigot_versions, mr_install, cf_install, spigot_install, is_plugin_server, mr_search, cf_search, spigot_search, spigot_resource, cf_request, CF_API_BASE
from control.core.server import get_pid

UPDATES_FILE = os.path.join(BASE_DIR, "mod_updates.json")
CHECK_INTERVAL = 86400
_update_results = []
_stop_check = False

def get_jar_version(filename):
    base = filename.replace('.jar', '')
    patterns = [
        r'[-_](\d+\.\d+(?:\.\d+)*(?:[-.]?(?:pre|rc|alpha|beta|dev|snap)[.-]?\d*)?)',
        r'[-_v](\d+\.\d+\.\d+)',
    ]
    for pat in patterns:
        m = re.search(pat, base, re.IGNORECASE)
        if m:
            ver = m.group(1)
            if len(ver) > 2 and ver[0].isdigit():
                return ver
    return "unknown"

def get_mod_name_from_filename(filename):
    base = filename.replace('.jar', '')
    name = re.split(r'[-_](?:\d+\.\d+|v\d)', base, maxsplit=1)[0]
    name = re.sub(r'[-_]?(?:forge|fabric|quilt|neoforge|paper|spigot|purpur|bukkit|all|universal|client|server)$', '', name, flags=re.IGNORECASE)
    return name.strip('-_ ') or base

def get_installed_mod_info():
    mods_dir = os.path.join(CFG.get('server_dir', '.'), 'mods')
    if not os.path.exists(mods_dir):
        return []
    results = []
    for f in os.listdir(mods_dir):
        if not f.endswith('.jar'):
            continue
        name = get_mod_name_from_filename(f)
        version = get_jar_version(f)
        source = 'unknown'
        fname_lower = f.lower()
        if any(x in fname_lower for x in ['modrinth', '_mr_']):
            source = 'modrinth'
        elif any(x in fname_lower for x in ['curseforge', '_cf_', 'curse']):
            source = 'curseforge'
        elif any(x in fname_lower for x in ['spigot', 'spiget', '_spt_']):
            source = 'spigot'
        results.append({'filename': f, 'name': name, 'version': version, 'source': source})
    return results

def _compare_versions(current, latest):
    def parse(v):
        parts = re.split(r'[^0-9]+', v.strip().lstrip('vV'))
        return tuple(int(p) for p in parts if p.isdigit())
    try:
        cur = parse(current)
        lat = parse(latest)
        return lat > cur
    except:
        return False

def check_mod_updates():
    global _update_results, _stop_check
    _stop_check = False
    mods = get_installed_mod_info()
    if not mods:
        return []
    results = []
    total = len(mods)
    for i, mod in enumerate(mods):
        if _stop_check:
            break
        print(f'\033[1;0H\033[2K  {cl("y")}Verificando mod {i+1}/{total}: {cl("w")}{mod["name"][:40]}{A["0"]}', end='', flush=True)
        try:
            if mod['source'] == 'modrinth':
                hits = mr_search(mod['name'], limit=5)
                if hits:
                    proj = hits[0]
                    versions = mr_versions(proj['slug'])
                    if versions:
                        latest = versions[0]
                        new_ver = latest.get('version_number', '')
                        if new_ver and _compare_versions(mod['version'], new_ver):
                            dl_url = ''
                            for fi in latest.get('files', []):
                                if fi.get('url'):
                                    dl_url = fi['url']
                                    break
                            results.append({
                                'name': mod['name'],
                                'filename': mod['filename'],
                                'current_version': mod['version'],
                                'new_version': new_ver,
                                'source': 'modrinth',
                                'project_id': proj.get('slug', ''),
                                'version_id': latest.get('id', ''),
                                'download_url': dl_url
                            })
            elif mod['source'] == 'curseforge':
                hits = cf_search(mod['name'], limit=5)
                if hits:
                    cf_mod = hits[0]
                    cf_mod_id = cf_mod.get('id')
                    files = cf_files(cf_mod_id)
                    if files:
                        latest = files[0]
                        new_ver = latest.get('displayName', '') or latest.get('version', '')
                        if new_ver and _compare_versions(mod['version'], new_ver):
                            results.append({
                                'name': mod['name'],
                                'filename': mod['filename'],
                                'current_version': mod['version'],
                                'new_version': new_ver,
                                'source': 'curseforge',
                                'mod_id': cf_mod_id,
                                'file_id': latest.get('id'),
                                'filename_new': latest.get('fileName', '')
                            })
            elif mod['source'] == 'spigot':
                hits = spigot_search(mod['name'], limit=5)
                if hits:
                    resource = hits[0]
                    rid = resource.get('id')
                    versions = spigot_versions(rid)
                    if versions:
                        latest = versions[0]
                        new_ver = latest.get('name', '')
                        if new_ver and _compare_versions(mod['version'], new_ver):
                            results.append({
                                'name': mod['name'],
                                'filename': mod['filename'],
                                'current_version': mod['version'],
                                'new_version': new_ver,
                                'source': 'spigot',
                                'resource_id': rid,
                                'version_name': new_ver
                            })
        except:
            pass
        time.sleep(0.2)
    _update_results = results
    try:
        with open(UPDATES_FILE, 'w') as f:
            json.dump({'last_check': time.time(), 'updates': results}, f, indent=2)
    except:
        pass
    return results

def _save_update_cache(updates):
    try:
        data = {'last_check': time.time(), 'updates': updates}
        with open(UPDATES_FILE, 'w') as f:
            json.dump(data, f, indent=2)
    except:
        pass

def _load_update_cache():
    try:
        if os.path.exists(UPDATES_FILE):
            with open(UPDATES_FILE, 'r') as f:
                data = json.load(f)
            if time.time() - data.get('last_check', 0) < CHECK_INTERVAL:
                return data.get('updates', [])
    except:
        pass
    return None

def auto_check_mod_updates_loop():
    global _update_results, _stop_check
    while True:
        time.sleep(30)
        if not get_pid():
            continue
        if is_plugin_server():
            continue
        cached = _load_update_cache()
        if cached is not None:
            _update_results = cached
            continue
        _stop_check = False
        mods = get_installed_mod_info()
        results = []
        for mod in mods:
            if _stop_check:
                break
            try:
                if mod['source'] == 'modrinth':
                    hits = mr_search(mod['name'], limit=3)
                    if hits:
                        versions = mr_versions(hits[0]['slug'])
                        if versions:
                            latest_ver = versions[0].get('version_number', '')
                            if latest_ver and _compare_versions(mod['version'], latest_ver):
                                results.append({
                                    'name': mod['name'], 'filename': mod['filename'],
                                    'current_version': mod['version'], 'new_version': latest_ver,
                                    'source': 'modrinth', 'project_id': hits[0]['slug'],
                                    'version_id': versions[0].get('id', ''),
                                    'download_url': next((fi['url'] for fi in versions[0].get('files', []) if fi.get('url')), '')
                                })
                elif mod['source'] == 'curseforge':
                    hits = cf_search(mod['name'], limit=3)
                    if hits:
                        files = cf_files(hits[0].get('id'))
                        if files:
                            latest_ver = files[0].get('displayName', '') or files[0].get('version', '')
                            if latest_ver and _compare_versions(mod['version'], latest_ver):
                                results.append({
                                    'name': mod['name'], 'filename': mod['filename'],
                                    'current_version': mod['version'], 'new_version': latest_ver,
                                    'source': 'curseforge', 'mod_id': hits[0]['id'],
                                    'file_id': files[0].get('id'), 'filename_new': files[0].get('fileName', '')
                                })
                elif mod['source'] == 'spigot':
                    hits = spigot_search(mod['name'], limit=3)
                    if hits:
                        versions = spigot_versions(hits[0].get('id'))
                        if versions:
                            latest_ver = versions[0].get('name', '')
                            if latest_ver and _compare_versions(mod['version'], latest_ver):
                                results.append({
                                    'name': mod['name'], 'filename': mod['filename'],
                                    'current_version': mod['version'], 'new_version': latest_ver,
                                    'source': 'spigot', 'resource_id': hits[0]['id'],
                                    'version_name': latest_ver
                                })
            except:
                pass
            time.sleep(0.5)
        _update_results = results
        _save_update_cache(results)
        if results:
            notify(f"Hay {len(results)} mods con actualizaciones disponibles", 'y')
        time.sleep(CHECK_INTERVAL)

def update_single_mod(mod_info):
    mods_dir = os.path.join(CFG.get('server_dir', '.'), 'mods')
    backup_dir = os.path.join(mods_dir, 'backup')
    old_path = os.path.join(mods_dir, mod_info['filename'])
    if not os.path.exists(old_path):
        return False, "Archivo no encontrado"
    try:
        os.makedirs(backup_dir, exist_ok=True)
        shutil.move(old_path, os.path.join(backup_dir, mod_info['filename']))
    except Exception as e:
        return False, f"Error backup: {e}"
    source = mod_info.get('source', 'unknown')
    try:
        if source == 'modrinth' and mod_info.get('project_id'):
            url = mod_info.get('download_url', '')
            if not url:
                return False, "Sin URL de descarga"
            new_fn = f"{mod_info['name']}-{mod_info['new_version']}.jar"
            new_path = os.path.join(mods_dir, new_fn)
            if download_file(url, new_path):
                return True, new_fn
            return False, "Error de descarga"
        elif source == 'curseforge' and mod_info.get('mod_id'):
            mod_id = mod_info['mod_id']
            file_id = mod_info['file_id']
            fn = mod_info.get('filename_new', f"cf_{mod_id}.jar")
            dl_url = f"{CF_API_BASE}/mods/{mod_id}/files/{file_id}/download-url"
            try:
                from control.core.mods import cf_download_url
                dl_url = cf_download_url(mod_id, file_id)
            except:
                pass
            if not dl_url:
                return False, "Sin URL de descarga"
            new_path = os.path.join(mods_dir, fn)
            if download_file(dl_url, new_path):
                return True, fn
            return False, "Error de descarga"
        elif source == 'spigot' and mod_info.get('resource_id'):
            rid = mod_info['resource_id']
            ver_name = mod_info.get('version_name', '')
            import urllib.request, re as _re
            url = f"https://api.spiget.org/v2/resources/{rid}/download"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                cd = r.headers.get('Content-Disposition', '')
                m = _re.search(r'filename="?([^"]+)"?', cd)
                new_fn = m.group(1) if m else f"plugin_{rid}.jar"
            new_path = os.path.join(mods_dir, new_fn)
            if download_file(url, new_path):
                return True, new_fn
            return False, "Error de descarga"
        else:
            return False, "Fuente desconocida o datos incompletos"
    except Exception as e:
        return False, str(e)

def update_all_mods():
    global _update_results
    if not _update_results:
        return 0, 0
    total = len(_update_results)
    ok = 0
    fail = 0
    for i, mod in enumerate(_update_results):
        print(f'\033[1;0H\033[2K  {cl("y")}Actualizando {i+1}/{total}: {cl("w")}{mod["name"][:40]}{A["0"]}', end='', flush=True)
        success, msg = update_single_mod(mod)
        if success:
            ok += 1
            print(f'\033[1;0H\033[2K  {cl("g")}✓ {mod["name"][:40]} actualizado a {mod["new_version"]}{A["0"]}', end='', flush=True)
        else:
            fail += 1
            print(f'\033[1;0H\033[2K  {cl("r")}✗ {mod["name"][:40]} error: {msg[:50]}{A["0"]}', end='', flush=True)
        time.sleep(0.5)
    _update_results = []
    return ok, fail

def mod_update_menu():
    global _update_results, _stop_check
    while True:
        clear()
        cols = get_size()
        draw_header(1, "ACTUALIZADOR DE MODS", f"Mods instalados: {len(get_installed_mod_info())}")
        y = 3
        cached = _load_update_cache()
        updates = cached if cached is not None else _update_results
        if updates:
            print(f'\033[{y};0H  {cl("y")}Actualizaciones disponibles: {len(updates)}{A["0"]}')
            y += 1
            for u in updates[:8]:
                print(f'\033[{y};0H  {cl("c")}{u["name"][:35]:<36}{cl("k")}{u["current_version"][:15]:<16}{cl("g")}→ {u["new_version"][:15]}{A["0"]}')
                y += 1
        else:
            print(f'\033[{y};0H  {cl("g")}Todos los mods estan actualizados{A["0"]}')
            y += 1
        y += 1
        print(f'\033[{y};0H  {cl("c")}[V]{A["0"]} Verificar actualizaciones  {cl("c")}[U]{A["0"]} Actualizar todos')
        y += 1
        print(f'\033[{y};0H  {cl("c")}[S]{A["0"]} Actualizar seleccionado    {cl("c")}[Q]{A["0"]} Volver')
        k = get_key()
        if k == 'q':
            _stop_check = True
            return
        elif k == 'v':
            clear()
            draw_header(1, "VERIFICANDO ACTUALIZACIONES", "")
            print(f'\033[{3};0H  {cl("y")}Buscando actualizaciones...{A["0"]}', end='', flush=True)
            _update_results = check_mod_updates()
            _save_update_cache(_update_results)
            if _update_results:
                notify(f"Se encontraron {_update_results.__len__()} actualizaciones", 'g')
            else:
                notify("Todos los mods estan actualizados", 'g')
        elif k == 'u':
            updates = _load_update_cache() or _update_results
            if not updates:
                notify("No hay actualizaciones disponibles", 'y')
                continue
            if confirm(f"\n  {cl('y')}Actualizar {len(updates)} mods? (s/n): {A['0']}"):
                clear()
                draw_header(1, "ACTUALIZANDO MODS", f"0/{len(updates)}")
                ok, fail = update_all_mods()
                time.sleep(1)
                notify(f"Actualizados: {ok} | Errores: {fail}", 'g' if fail == 0 else 'y')
        elif k == 's':
            updates = _load_update_cache() or _update_results
            if not updates:
                notify("No hay actualizaciones disponibles", 'y')
                continue
            clear()
            draw_header(1, "SELECCIONAR MOD", "")
            for i, u in enumerate(updates):
                print(f'\033[{3+i};0H  {cl("c")}[{i+1}]{A["0"]} {u["name"][:35]:<36}{cl("k")}{u["current_version"][:15]:<16}{cl("g")}→ {u["new_version"][:15]}{A["0"]}')
            print(f'\033[{3+len(updates)+1};0H  {cl("k")}Ingresa el numero del mod o [Q] para cancelar{A["0"]}')
            choice = read_text("  > ", "")
            if choice and choice.lower() == 'q':
                continue
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(updates):
                    if confirm(f"\n  {cl('y')}Actualizar {updates[idx]['name']}? (s/n): {A['0']}"):
                        clear()
                        draw_header(1, "ACTUALIZANDO MOD", updates[idx]['name'])
                        success, msg = update_single_mod(updates[idx])
                        if success:
                            notify(f"Mod actualizado a {updates[idx]['new_version']}", 'g')
                            _update_results = [u for u in _update_results if u['filename'] != updates[idx]['filename']]
                            _save_update_cache(_update_results)
                        else:
                            notify(f"Error: {msg}", 'r')
            except (ValueError, IndexError):
                pass
