import os, sys, json, shutil, threading, gc, time
from control.core.shared import CFG, DEFAULTS, SERVER_PROC, notify, hide_cursor, show_cursor, clear, \
    save_config, load_config, is_empty_server_dir, A, cl, draw_header
from control.core.server import get_pid, start, stop, crash_monitor, send_cmd
from control.core.scheduler import msg_scheduler_loop, task_scheduler_loop
from control.scripts.installer import server_installer_wizard, first_time_setup
from control.scripts.menus import draw_main_menu, console_full, logs_full, \
    theme_menu, config_menu, edit_properties, list_mods_menu, \
    players_menu_full, auto_broadcast_menu, scheduled_tasks_menu, whitelist_menu, explorer, \
    profile_save_menu, profile_load_menu, profile_delete_menu, profile_new_menu, \
    world_switch_menu, world_download_menu
from control.core.backup import list_backups, create_backup, restore_backup_by_name, delete_backup_by_name
from control.core.profiles import get_profiles, save_profile_core, load_profile_core
from control.core.mods import get_mods
from control.core.shared import get_key, confirm, read_text, fmt_size, fmt_time, get_size, notify_long, get_log_tail
from control.core.server import get_server_stats, get_uptime, get_world_size
from control.core.updater import check_update, do_update

def main():
    global CFG
    threading.stack_size(262144)
    sd = CFG.get('server_dir', DEFAULTS['server_dir'])
    first_run = CFG.get('first_run', True)

    if first_run and is_empty_server_dir(sd):
        server_installer_wizard()
        CFG = load_config()
        if CFG.get('first_run', True):
            return
    elif first_run:
        first_time_setup()
        CFG = load_config()

    if not os.path.exists(CFG.get('java_path', '')):
        notify(f"Java no encontrado en: {CFG['java_path']}\nUsa la configuracion para cambiarlo", 'r')
    if not os.path.exists(CFG.get('jar_path', '')):
        notify(f"JAR no encontrado en: {CFG['jar_path']}\nUsa la configuracion para cambiarlo", 'r')
    if not os.path.exists(CFG.get('server_dir', '')):
        notify(f"Directorio no existe: {CFG['server_dir']}", 'r')

    threading.Thread(target=msg_scheduler_loop, daemon=True).start()
    threading.Thread(target=task_scheduler_loop, daemon=True).start()

    if CFG.get('auto_restart_crash'):
        threading.Thread(target=crash_monitor, daemon=True).start()

    try:
        from control.core.updater import check_update
        up_info = check_update()
        if up_info:
            notify(f"Actualizacion disponible: v{up_info['version']} (Menu > Actualizar)", 'c')
    except:
        pass

    sel = 0
    loop_count = 0
    menu_len = 41
    header_indices = {0, 10, 16, 19, 24, 27, 32, 40}
    try:
        while True:
            loop_count += 1
            if loop_count % 100 == 0:
                gc.collect()
            draw_main_menu(sel)
            k = get_key()

            if k == 'up':
                while sel > 0:
                    sel -= 1
                    if sel not in header_indices:
                        break
            elif k == 'down':
                while sel < menu_len - 1:
                    sel += 1
                    if sel not in header_indices:
                        break
            elif k == 'enter':
                if sel in header_indices:
                    pass
                elif sel == 1:
                    ok, msg = start()
                    notify(msg, 'g' if ok else 'r')
                elif sel == 2:
                    ok, msg = stop()
                    notify(msg, 'g' if ok else 'r')
                elif sel == 3:
                    ok, msg = stop()
                    notify("Reiniciando..." if ok else msg, 'g' if ok else 'r')
                    if ok:
                        time.sleep(2)
                        start()
                        notify("Servidor reiniciado", 'g')
                elif sel == 4:
                    console_full()
                elif sel == 5:
                    logs_full()
                elif sel == 6:
                    name, sz = create_backup()
                    if name:
                        notify(f"Backup creado: {name} ({fmt_size(sz)})", 'g')
                    else:
                        notify(f"Error: {sz}", 'r')
                elif sel == 7:
                    backups = list_backups()
                    if not backups:
                        notify("No hay backups", 'y')
                    else:
                        while True:
                            clear()
                            draw_header(1, "RESTAURAR BACKUP")
                            y = 3
                            for i, b in enumerate(backups[:10]):
                                print(f'\033[{y+i};0H  {i+1}. {b["name"]} ({fmt_size(b["size"])})')
                            print(f'\033[{y+12};0H  Numero: ')
                            idx_s = read_text("  Numero: ")
                            if idx_s and idx_s.isdigit():
                                idx = int(idx_s) - 1
                                if 0 <= idx < len(backups):
                                    ok, msg = restore_backup_by_name(backups[idx]['name'])
                                    notify(msg, 'g' if ok else 'r')
                                    break
                            elif idx_s in ('q', ''):
                                break
                elif sel == 8:
                    backups = list_backups()
                    if backups:
                        lines = [f'{cl("c")}Backups ({len(backups)}):{A["0"]}']
                        for b in backups[:15]:
                            lines.append(f'  {cl("y")}{b["name"]}{A["0"]} ({fmt_size(b["size"])})')
                        notify_long('\n'.join(lines), 'c')
                    else:
                        notify("No hay backups", 'k')
                elif sel == 9:
                    backups = list_backups()
                    if not backups:
                        notify("No hay backups", 'y')
                    else:
                        clear()
                        draw_header(1, "BORRAR BACKUP")
                        y = 3
                        for i, b in enumerate(backups[:10]):
                            print(f'\033[{y+i};0H  {i+1}. {b["name"]}')
                        idx_s = read_text("  Numero: ")
                        if idx_s and idx_s.isdigit():
                            idx = int(idx_s) - 1
                            if 0 <= idx < len(backups):
                                ok, msg = delete_backup_by_name(backups[idx]['name'])
                                notify(msg, 'g' if ok else 'r')
                elif sel == 11:
                    profile_save_menu()
                elif sel == 12:
                    profile_load_menu()
                elif sel == 13:
                    profiles = get_profiles()
                    if profiles:
                        lines = [f'{cl("c")}Perfiles ({len(profiles)}):{A["0"]}']
                        for p in profiles:
                            mc = len([f for f in os.listdir(os.path.join(os.path.join(CFG['server_dir'], 'profiles'), p, 'mods')) if f.endswith('.jar')]) if os.path.exists(os.path.join(CFG['server_dir'], 'profiles', p, 'mods')) else 0
                            lines.append(f'  {cl("g")}{p}{A["0"]} ({mc} mods)')
                        notify_long('\n'.join(lines), 'c')
                    else:
                        notify("No hay perfiles", 'k')
                elif sel == 14:
                    profile_delete_menu()
                elif sel == 15:
                    profile_new_menu()
                elif sel == 17:
                    world_switch_menu()
                elif sel == 18:
                    world_download_menu()
                elif sel == 20:
                    players_menu_full()
                elif sel == 21:
                    msg = read_text("  Mensaje para todos: ")
                    if msg:
                        send_cmd(f'tellraw @a {{"text":"[SERVER] {msg}","color":"yellow"}}')
                        notify("Enviado", 'g')
                elif sel == 22:
                    whitelist_menu()
                elif sel == 23:
                    ops_file = os.path.join(CFG['server_dir'], "ops.json")
                    if os.path.exists(ops_file):
                        try:
                            with open(ops_file, 'r') as f:
                                ops = json.load(f)
                            if ops:
                                lines = [f'{cl("y")}Admins ({len(ops)}):{A["0"]}']
                                for op in ops:
                                    name = op.get('name', op.get('uuid', '?'))
                                    level = op.get('level', '?')
                                    lines.append(f'  {name} (nivel {level})')
                                notify_long('\n'.join(lines), 'c')
                            else:
                                notify("No hay admins", 'k')
                        except:
                            notify("Error al leer ops", 'r')
                    else:
                        notify("No hay ops.json", 'k')
                elif sel == 25:
                    auto_broadcast_menu()
                elif sel == 26:
                    scheduled_tasks_menu()
                elif sel == 28:
                    if get_pid():
                        clear()
                        cols = get_size()
                        draw_header(1, "DIFICULTAD")
                        y = 3
                        opts = [("1", "Peaceful", 'g'), ("2", "Easy", 'g'), ("3", "Normal", 'y'), ("4", "Hard", 'r')]
                        for i, (k, lbl, c) in enumerate(opts):
                            print(f'\033[{y+i};0H  {cl(c)}[{k}]{A["0"]} {lbl}')
                        print(f'\033[{y+5};0H  {cl("k")}[1-4] Seleccionar [Q] Volver{A["0"]}')
                        d_map = {'1': 'peaceful', '2': 'easy', '3': 'normal', '4': 'hard'}
                        k2 = get_key()
                        if k2 in d_map:
                            send_cmd(f"difficulty {d_map[k2]}")
                            notify("Dificultad cambiada", 'g')
                    else:
                        notify("Servidor no corriendo", 'r')
                elif sel == 29:
                    if get_pid():
                        p = read_text("  Jugador: ")
                        if p:
                            clear()
                            cols = get_size()
                            draw_header(1, "MODO DE JUEGO", f"Jugador: {p}")
                            y = 3
                            opts = [("1", "Survival", 'g'), ("2", "Creative", 'b'), ("3", "Adventure", 'p'), ("4", "Spectator", 'c')]
                            for i, (k, lbl, c) in enumerate(opts):
                                print(f'\033[{y+i};0H  {cl(c)}[{k}]{A["0"]} {lbl}')
                            print(f'\033[{y+5};0H  {cl("k")}[1-4] Seleccionar [Q] Volver{A["0"]}')
                            gm_map = {'1': 'survival', '2': 'creative', '3': 'adventure', '4': 'spectator'}
                            k2 = get_key()
                            if k2 in gm_map:
                                send_cmd(f"gamemode {gm_map[k2]} {p}")
                                notify(f"Modo cambiado a {gm_map[k2]}", 'g')
                    else:
                        notify("Servidor no corriendo", 'r')
                elif sel == 30:
                    if get_pid():
                        stats = get_server_stats()
                        up = get_uptime()
                        ws = get_world_size()
                        lines = [
                            f'{cl("c")}RENDIMIENTO:{A["0"]}',
                            f'  RAM: {stats.get("ram","N/A")} MB' if stats else '  RAM: N/A',
                            f'  Threads: {stats.get("threads","N/A")}' if stats else '',
                            f'  Uptime: {fmt_time(up)}' if up else '',
                            f'  Mundo: {fmt_size(ws)}' if ws else '',
                        ]
                        notify_long('\n'.join(filter(None, lines)), 'c')
                    else:
                        notify("Servidor no corriendo", 'r')
                elif sel == 31:
                    count = 0
                    ld = os.path.join(CFG['server_dir'], 'logs')
                    if os.path.exists(ld):
                        for f in os.listdir(ld):
                            if f.endswith('.log.gz') or f.endswith('.txt'):
                                try:
                                    os.remove(os.path.join(ld, f))
                                    count += 1
                                except:
                                    pass
                    notify(f"Limpiados {count} archivos", 'g')
                elif sel == 33:
                    ml = CFG.get('mod_loader', 'auto')
                    plugin_types = ('paper', 'purpur', 'pufferfish', 'tuinity', 'spigot', 'bukkit', 'spongevanilla', 'spongeforge', 'cardboard', 'banner', 'mohist', 'catserver')
                    if ml == 'vanilla':
                        notify("Servidor vanilla — no hay soporte de mods/plugins", 'r')
                    elif ml in plugin_types:
                        list_mods_menu()
                    else:
                        list_mods_menu()
                elif sel == 34:
                    ml = CFG.get('mod_loader', 'auto')
                    plugin_types = ('paper', 'purpur', 'pufferfish', 'tuinity', 'spigot', 'bukkit', 'spongevanilla', 'spongeforge', 'cardboard', 'banner', 'mohist', 'catserver')
                    if ml == 'vanilla':
                        notify("Servidor vanilla — no hay soporte de mods/plugins", 'r')
                    else:
                        path = read_text("  Ruta del .jar: ")
                        if path:
                            path = path.strip('"').strip("'")
                            if os.path.exists(path):
                                md = os.path.join(CFG['server_dir'], 'mods')
                                os.makedirs(md, exist_ok=True)
                                fn = os.path.basename(path)
                                shutil.copy2(path, os.path.join(md, fn))
                                notify(f"{'Plugin' if ml in plugin_types else 'Mod'} instalado: {fn}", 'g')
                            else:
                                notify("Archivo no encontrado", 'r')
                elif sel == 35:
                    theme_menu()
                elif sel == 36:
                    config_menu()
                elif sel == 37:
                    edit_properties()
                elif sel == 38:
                    explorer()
                elif sel == 39:
                    do_update()
            elif k == 'q':
                show_cursor()
                clear()
                if get_pid():
                    stop()
                print(f'\n  {cl("Y")}Adios!{cl("0")}\n')
                break
            elif k == 'ctrl-c':
                show_cursor()
                clear()
                print(f'\n  {cl("Y")}Adios!{cl("0")}\n')
                break
    except (KeyboardInterrupt, EOFError):
        show_cursor()
        clear()
        print(f'\n  {cl("Y")}Adios!{cl("0")}\n')

if __name__ == "__main__":
    main()