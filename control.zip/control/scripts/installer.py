import os, sys, subprocess, json, time, re, shutil, glob, urllib.request
from control.core.shared import CFG, DEFAULTS, BASE_DIR, A, cl, ts, notify, notify_long, get_key, get_size, \
    get_t, tc, get_bg, bg_set, draw_header, clear, read_text, confirm, hide_cursor, \
    show_cursor, download_file, save_config, load_config, auto_detect_java, fmt_size, _get_key_raw

def find_java(major):
    home = os.path.expanduser("~")
    candidates = [
        f"/usr/lib/jvm/java-{major}-openjdk/bin/java",
        f"/usr/lib/jvm/jdk-{major}/bin/java",
        f"/usr/lib/jvm/java-{major}-openjdk-*/bin/java",
        f"/usr/lib/jvm/jre-{major}-openjdk/bin/java",
    ]
    for pat in candidates:
        for p in glob.glob(pat):
            if os.path.exists(p):
                return p
    for root, dirs, files in os.walk("/usr/lib/jvm"):
        for d in dirs:
            if re.search(rf'\b{major}\b', d) and ('java' in d.lower() or 'jdk' in d.lower() or 'jre' in d.lower()):
                jp = os.path.join(root, d, "bin", "java")
                if os.path.exists(jp):
                    return jp
        break
    for root, dirs, files in os.walk(os.path.join(home, "Downloads")):
        for d in dirs:
            if 'jdk' in d.lower() and str(major) in d:
                jp = os.path.join(root, d, "bin", "java")
                if os.path.exists(jp):
                    return jp
        break
    for d in glob.glob(os.path.join(home, "*", f"java{major}", "*", "bin", "java")):
        if os.path.exists(d):
            return d
    for d in glob.glob(os.path.join(home, "*", "*", f"java{major}", "*", "bin", "java")):
        if os.path.exists(d):
            return d
    return None

def download_java(major, dest):
    import urllib.request, json, tarfile
    urls = [
        f"https://api.adoptium.net/v3/assets/feature_releases/{major}/ga?architecture=x64&image_type=jdk&os=linux&project=jdk&vendor=eclipse&page_size=1",
        f"https://api.adoptium.net/v3/binary_repositories/latest_release/{major}/ga?architecture=x64&image_type=jdk&os=linux&project=jdk&vendor=eclipse&page_size=1",
    ]
    for attempt, url in enumerate(urls):
        print(f'\033[{4};0H  {cl("k")}Consultando API de Adoptium (intento {attempt+1})...{cl("0")}')
        sys.stdout.flush()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as r:
                data = json.loads(r.read())
            if data:
                link = data[0].get('binaries', [{}])[0].get('package', {}).get('link', '')
                if link:
                    break
        except Exception as e:
            if attempt == len(urls) - 1:
                notify(f"Error API: {e}", 'r')
                return None
            continue
    else:
        notify("No se pudo obtener enlace de descarga", 'r')
        return None
    fname = link.split('/')[-1]
    tgt = os.path.join(dest, fname)
    print(f'\033[{4};0H  {cl("c")}Descargando: {fname}{cl("0")}')
    sys.stdout.flush()
    ok = download_file(link, tgt)
    if not ok:
        notify("Error durante la descarga del JDK", 'r')
        return None
    java_dir = os.path.join(dest, f"java{major}")
    os.makedirs(java_dir, exist_ok=True)
    print(f'\033[{4};0H  {cl("y")}Extrayendo JDK...{cl("0")}')
    sys.stdout.flush()
    try:
        with tarfile.open(tgt, 'r:gz') as tar:
            tar.extractall(path=java_dir)
    except Exception as e:
        notify(f"Error al extraer: {e}", 'r')
        return None
    os.remove(tgt)
    for root, dirs, files in os.walk(java_dir):
        for f in files:
            if f == 'java' and 'bin' in root:
                return os.path.join(root, f)
    notify("No se encontro bin/java despues de extraer", 'r')
    return None

def get_java_version(jp=None):
    try:
        r = subprocess.run([jp or 'java', '-version'], capture_output=True, text=True, timeout=5)
        out = r.stderr or r.stdout
        for line in out.splitlines():
            if 'version' in line:
                m = re.search(r'"(.*?)"', line)
                if m:
                    ver_str = m.group(1)
                    parts = ver_str.split('.')
                    if parts[0] == '1':
                        return int(parts[1]), line.strip()
                    else:
                        return int(parts[0]), line.strip()
    except:
        pass
    return 0, ''

def required_java(mc_ver):
    try:
        parts = mc_ver.split('.')
        major = int(parts[1]) if len(parts) > 1 else 0
    except:
        return 8
    if major <= 12: return 8
    elif major <= 16: return 11
    elif major == 17: return 16
    elif major <= 20: return 17
    else: return 21

def resolve_java(mc_ver, prefer=None):
    need = required_java(mc_ver)
    if prefer and os.path.exists(prefer):
        ver, _ = get_java_version(prefer)
        if ver >= need:
            return prefer
    j = find_java(need)
    if j:
        return j
    for v in [need, 21, 17, 11, 8]:
        if v >= need:
            j = find_java(v)
            if j:
                return j
    return None

def fetch_versions(tipo):
    try:
        if tipo == 'vanilla':
            url = "https://launchermeta.mojang.com/mc/game/version_manifest.json"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            return [v['id'] for v in data.get('versions', []) if v['type'] == 'release']
        elif tipo == 'forge':
            url = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            vers = set()
            for k, v in data.get('promos', {}).items():
                mc = k.split('-')[0]
                if mc.count('.') >= 1 and not mc.startswith('26.'):
                    vers.add(mc)
            return sorted(vers, key=lambda x: [int(p) for p in x.split('.')], reverse=True)
        elif tipo == 'fabric':
            url = "https://meta.fabricmc.net/v2/versions/game"
            with urllib.request.urlopen(url, timeout=10) as r:
                data = json.loads(r.read())
            return [v['version'] for v in data if v['stable']]
        elif tipo == 'quilt':
            url = "https://meta.quiltmc.org/v3/versions/game"
            with urllib.request.urlopen(url, timeout=10) as r:
                data = json.loads(r.read())
            return [v['version'] for v in data if v.get('stable')]
        elif tipo in ('paper', 'purpur'):
            if tipo == 'paper':
                url = "https://fill.papermc.io/v3/projects/paper"
            else:
                url = "https://api.purpurmc.org/v2/purpur"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                data = json.loads(r.read())
            if tipo == 'paper':
                vers = set()
                for group, items in data.get('versions', {}).items():
                    for v in items:
                        if 'rc' not in v and 'pre' not in v and 'beta' not in v and 'alpha' not in v:
                            vers.add(v)
                return sorted(vers, key=lambda x: [int(p) for p in x.split('.')], reverse=True)
            else:
                return [v for v in data.get('versions', [])][::-1]
        elif tipo == 'neoforge':
            import xml.etree.ElementTree as ET
            url = "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                root = ET.fromstring(r.read())
            vers = set()
            for v in root.findall('.//version'):
                txt = v.text or ''
                if 'beta' in txt or 'alpha' in txt:
                    continue
                parts = txt.split('.')
                if len(parts) >= 2:
                    try:
                        major = int(parts[0])
                        minor = int(parts[1])
                    except ValueError:
                        continue
                    if major > 25:
                        continue
                    if minor == 0:
                        vers.add(f'1.{major}')
                    else:
                        vers.add(f'1.{major}.{minor}')
            return sorted(vers, key=lambda x: [int(p) for p in x.split('.')], reverse=True)
        elif tipo == 'spongevanilla':
            import xml.etree.ElementTree as ET
            url = "https://repo.spongepowered.org/repository/maven-releases/org/spongepowered/spongevanilla/maven-metadata.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=10) as r:
                root = ET.fromstring(r.read())
            return [v.text for v in root.findall('.//version') if v.text][::-1]
    except:
        pass
    return []

def get_forge_build(mc_ver):
    import urllib.request, json, xml.etree.ElementTree as ET
    try:
        url = "https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        key = f"{mc_ver}-recommended"
        build = data.get('promos', {}).get(key, '')
        if not build:
            key = f"{mc_ver}-latest"
            build = data.get('promos', {}).get(key, '')
        if build:
            fmt_ver = f"{mc_ver}-{build}"
            test_url = f"https://maven.minecraftforge.net/net/minecraftforge/forge/{fmt_ver}/forge-{fmt_ver}-installer.jar"
            req2 = urllib.request.Request(test_url, headers={"User-Agent": "Mozilla/5.0"}, method='HEAD')
            try:
                with urllib.request.urlopen(req2, timeout=5) as r:
                    if r.status == 200:
                        return fmt_ver
            except:
                pass
        meta_url = "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml"
        req3 = urllib.request.Request(meta_url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req3, timeout=10) as r:
            root = ET.fromstring(r.read())
        vers = [v.text for v in root.findall('.//version') if v.text]
        best = ''
        for v in vers:
            if v.startswith(f"{mc_ver}-") and 'pre' not in v and 'beta' not in v and 'alpha' not in v:
                if v > best:
                    best = v
        return best
    except:
        return ""

def get_fabric_loader(mc_ver):
    try:
        url = f"https://meta.fabricmc.net/v2/versions/loader/{mc_ver}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        return data[0]['loader']['version'] if data else ""
    except:
        return ""

def get_quilt_loader(mc_ver):
    try:
        url = f"https://meta.quiltmc.org/v3/versions/loader/{mc_ver}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        return data[0]['loader']['version'] if data else ""
    except:
        return ""

def get_paper_build(mc_ver):
    try:
        url = f"https://fill.papermc.io/v3/projects/paper/versions/{mc_ver}/builds/latest"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        return data
    except:
        pass
    return None

def get_purpur_build(mc_ver):
    try:
        url = f"https://api.purpurmc.org/v2/purpur/{mc_ver}"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        return data.get('builds', {}).get('latest', '')
    except:
        return ""

def get_neoforge_build(mc_ver):
    import xml.etree.ElementTree as ET
    try:
        url = "https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml"
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            root = ET.fromstring(r.read())
        parts = mc_ver.split('.')
        if len(parts) == 2:
            prefix = f'{parts[1]}.0.'
        else:
            prefix = f'{parts[1]}.{parts[2]}.'
        best = ''
        for v in root.findall('.//version'):
            txt = v.text or ''
            if 'beta' in txt or 'alpha' in txt:
                continue
            if txt.startswith(prefix):
                if txt > best:
                    best = txt
        return best
    except:
        return ""

def download_server(tipo, mc_ver, dest, java_path="java"):
    import urllib.request, urllib.parse
    os.makedirs(dest, exist_ok=True)
    jar_path = ""
    try:
        if tipo == 'vanilla':
            import ssl
            jar_url = ""
            for attempt in range(3):
                try:
                    url = "https://piston-meta.mojang.com/mc/game/version_manifest.json"
                    ctx = ssl._create_unverified_context()
                    req = urllib.request.Request(url)
                    with urllib.request.urlopen(req, timeout=30, context=ctx) as r:
                        manifest = json.loads(r.read())
                    for v in manifest.get('versions', []):
                        if v['id'] == mc_ver:
                            req2 = urllib.request.Request(v['url'])
                            with urllib.request.urlopen(req2, timeout=30, context=ctx) as r2:
                                vdata = json.loads(r2.read())
                            jar_url = vdata.get('downloads', {}).get('server', {}).get('url', '')
                            break
                    if jar_url:
                        break
                except Exception as e:
                    if attempt == 2:
                        return False, f"Error al conectar con Mojang: {e}"
            if not jar_url:
                return False, "No se encontro URL de descarga"
            jar_path = os.path.join(dest, "server.jar")
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar"
        elif tipo == 'forge':
            fmt_ver = get_forge_build(mc_ver)
            if not fmt_ver:
                return False, f"No se encontro build recomendado para {mc_ver}"
            installer_url = f"https://maven.minecraftforge.net/net/minecraftforge/forge/{fmt_ver}/forge-{fmt_ver}-installer.jar"
            installer_path = os.path.join(dest, f"forge-{fmt_ver}-installer.jar")
            ok = download_file(installer_url, installer_path)
            if not ok:
                return False, "Error al descargar instalador Forge"
            print(f'\033[{5};0H  {cl("y")}Ejecutando instalador... (puede tardar varios minutos){cl("0")}')
            sys.stdout.flush()
            p = subprocess.run([java_path, "-jar", installer_path, "--installServer"],
                              cwd=dest, capture_output=True, text=True, timeout=600)
            if p.returncode != 0:
                return False, f"Instalador Forge fallo: {p.stderr[-200:]}"
            for f in os.listdir(dest):
                if f.startswith("forge-") and f.endswith(".jar") and "installer" not in f:
                    jar_path = os.path.join(dest, f)
                    break
            if not jar_path:
                jar_path = os.path.join(dest, f"forge-{fmt_ver}.jar")
            os.remove(installer_path)
        elif tipo == 'fabric':
            loader = get_fabric_loader(mc_ver)
            if not loader:
                return False, f"No se encontro Fabric loader para {mc_ver}"
            jar_url = f"https://meta.fabricmc.net/v2/versions/loader/{mc_ver}/{loader}/server/jar"
            jar_name = f"fabric-server-mc.{mc_ver}-loader.{loader}.jar"
            jar_path = os.path.join(dest, jar_name)
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar Fabric"
        elif tipo == 'quilt':
            loader = get_quilt_loader(mc_ver)
            if not loader:
                return False, f"No se encontro Quilt loader para {mc_ver}"
            jar_url = f"https://meta.quiltmc.org/v3/versions/loader/{mc_ver}/{loader}/server/jar"
            jar_name = f"quilt-server-mc.{mc_ver}-loader.{loader}.jar"
            jar_path = os.path.join(dest, jar_name)
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar Quilt"
        elif tipo == 'paper':
            build_data = get_paper_build(mc_ver)
            if not build_data:
                return False, f"No se encontro build para Paper {mc_ver}"
            jar_url = build_data.get('downloads', {}).get('server:default', {}).get('url', '')
            if not jar_url:
                return False, "No se encontro URL de descarga para Paper"
            build_num = build_data.get('id', 'latest')
            jar_name = f"paper-{mc_ver}-{build_num}.jar"
            jar_path = os.path.join(dest, jar_name)
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar Paper"
        elif tipo == 'purpur':
            build = get_purpur_build(mc_ver)
            if not build:
                return False, f"No se encontro build para Purpur {mc_ver}"
            jar_url = f"https://api.purpurmc.org/v2/purpur/{mc_ver}/{build}/download"
            jar_name = f"purpur-{mc_ver}-{build}.jar"
            jar_path = os.path.join(dest, jar_name)
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar Purpur"
        elif tipo == 'neoforge':
            build = get_neoforge_build(mc_ver)
            if not build:
                return False, f"No se encontro build NeoForge para {mc_ver}"
            installer_url = f"https://maven.neoforged.net/releases/net/neoforged/neoforge/{build}/neoforge-{build}-installer.jar"
            installer_path = os.path.join(dest, f"neoforge-{build}-installer.jar")
            ok = download_file(installer_url, installer_path)
            if not ok:
                return False, "Error al descargar instalador NeoForge"
            print(f'\033[{5};0H  {cl("y")}Ejecutando instalador... (puede tardar varios minutos){cl("0")}')
            sys.stdout.flush()
            p = subprocess.run([java_path, "-jar", installer_path, "--installServer"],
                              cwd=dest, capture_output=True, text=True, timeout=600)
            if p.returncode != 0:
                return False, f"Instalador NeoForge fallo: {p.stderr[-200:]}"
            for f in os.listdir(dest):
                if f.startswith("neoforge-") and f.endswith(".jar") and "installer" not in f:
                    jar_path = os.path.join(dest, f)
                    break
            if not jar_path:
                jar_path = os.path.join(dest, f"neoforge-{build}.jar")
            os.remove(installer_path)
        elif tipo == 'spongevanilla':
            jar_url = f"https://repo.spongepowered.org/repository/maven-releases/org/spongepowered/spongevanilla/{mc_ver}/spongevanilla-{mc_ver}.jar"
            jar_name = f"spongevanilla-{mc_ver}.jar"
            jar_path = os.path.join(dest, jar_name)
            ok = download_file(jar_url, jar_path)
            if not ok:
                return False, "Error al descargar SpongeVanilla"
        else:
            return False, f"Tipo desconocido: {tipo}"
        if not jar_path or not os.path.exists(jar_path):
            return False, "No se genero el JAR del servidor"
        eula_path = os.path.join(dest, "eula.txt")
        with open(eula_path, 'w') as f:
            f.write("eula=true\n")
        return True, os.path.basename(jar_path)
    except subprocess.TimeoutExpired:
        return False, "Tiempo de instalacion agotado"
    except Exception as e:
        return False, str(e)

def auto_configure(tipo, dest):
    os.makedirs(dest, exist_ok=True)
    props_file = os.path.join(dest, "server.properties")
    if os.path.exists(props_file):
        with open(props_file, 'r') as f:
            content = f.read()
        changed = False
        for key, val in [("enable-rcon", "true"), ("rcon.port", "25575"), ("rcon.password", "minecraft")]:
            if f"{key}=" not in content:
                content += f"{key}={val}\n"
                changed = True
        if changed:
            with open(props_file, 'w') as f:
                f.write(content)
    else:
        with open(props_file, 'w') as f:
            f.write("motd=Minecraft Server\n")
            f.write("server-port=25565\n")
            f.write("online-mode=true\n")
            f.write("difficulty=easy\n")
            f.write("max-players=20\n")
            f.write("spawn-protection=16\n")
            f.write("pvp=true\n")
            f.write("level-type=default\n")
            f.write("gamemode=survival\n")
            f.write("enable-command-block=false\n")
            f.write("enable-rcon=true\n")
            f.write("rcon.port=25575\n")
            f.write("rcon.password=minecraft\n")
            f.write("broadcast-rcon-to-ops=false\n")

def server_installer_wizard():
    global CFG
    cols = get_size()
    w = cols.columns
    tipo_names = {
        'vanilla': 'Vanilla', 'forge': 'Forge', 'fabric': 'Fabric',
        'quilt': 'Quilt', 'neoforge': 'NeoForge',
        'paper': 'Paper (plugins)', 'purpur': 'Purpur (plugins)',
        'spongevanilla': 'SpongeVanilla (plugins)'
    }
    tipo_list = ['vanilla', 'forge', 'fabric', 'neoforge', 'quilt', 'paper', 'purpur', 'spongevanilla']
    sel = 0
    while True:
        clear()
        draw_header(1, "INSTALADOR DE SERVIDOR", "No se detecto un servidor existente")
        y = 4
        print(f'\033[{y};0H  {cl("c")}El directorio del servidor esta vacio.{cl("0")}')
        y += 2
        print(f'\033[{y};0H  {cl("c")}Elige el tipo de servidor a instalar:{cl("0")}')
        y += 1
        for i, t in enumerate(tipo_list):
            label = tipo_names.get(t, t)
            mark = "▸" if sel == i else " "
            print(f'\033[{y+i};0H  {mark} {label}')
        y += len(tipo_list) + 2
        print(f'\033[{y};0H  {cl("k")}[W/S] Navegar  [Enter] Seleccionar  [M] Config manual  [Q] Salir{cl("0")}')
        k = get_key()
        if k == 'up' and sel > 0: sel -= 1
        elif k == 'down' and sel < len(tipo_list) - 1: sel += 1
        elif k == 'enter':
            tipo = tipo_list[sel]
            clear()
            draw_header(1, f"VERSION: {tipo_names.get(tipo, tipo)}", "Cargando versiones...")
            vers = fetch_versions(tipo)
            if not vers:
                notify(f"No se pudieron cargar versiones para {tipo}", 'r')
                continue
            sel_v = 0
            while True:
                clear()
                draw_header(1, f"VERSION: {tipo_names.get(tipo, tipo)}", f"{len(vers)} disponibles")
                y2 = 3
                max_vis = cols.lines - 6
                sc = max(0, min(sel_v - max_vis + 2, len(vers) - max_vis)) if sel_v >= max_vis else 0
                visible = vers[sc:sc+max_vis]
                for i, v in enumerate(visible):
                    idx = sc + i
                    marker = "▸" if idx == sel_v else " "
                    print(f'\033[{y2+i};0H  {marker} {v}')
                y2 += len(visible) + 2
                print(f'\033[{y2};0H  {cl("k")}[W/S] Navegar  [Enter] Seleccionar  [Q] Volver{cl("0")}')
                k = get_key()
                if k == 'up' and sel_v > 0: sel_v -= 1
                elif k == 'down' and sel_v < len(vers) - 1: sel_v += 1
                elif k == 'enter':
                    mc_ver = vers[sel_v]
                    break
                elif k in ('q', 'esc'):
                    vers = None
                    break
            if vers is None:
                continue
            break
        elif k == 'm':
            first_time_setup()
            return
        elif k in ('q', 'esc'):
            show_cursor()
            clear()
            sys.exit(0)
    need = required_java(mc_ver)
    sd = CFG.get('server_dir', BASE_DIR)
    java_path = ""
    while True:
        clear()
        draw_header(1, "JAVA", f"Java {need} para {mc_ver}")
        print(f'\033[{3};0H  {cl("c")}Se necesita Java {need} para este servidor.{cl("0")}')
        print(f'\033[{4};0H  {cl("y")}Deseas descargar Java {need} automaticamente?{cl("0")}')
        print(f'\033[{5};0H  {cl("k")}[D] Descargar  [N] Buscar existente  [R] Ruta manual  [Q] Salir{cl("0")}')
        k = get_key()
        if k in ('d', 'D'):
            clear()
            draw_header(1, "DESCARGANDO JAVA", f"Java {need} para {mc_ver}")
            print(f'\033[{3};0H  {cl("y")}Descargando Java {need}... (puede tardar){cl("0")}')
            sys.stdout.flush()
            java_path = download_java(need, sd)
            if java_path:
                break
            notify_long(f"Error al descargar Java {need}.\nIntenta con otra opcion o revisa tu conexion.", 'r')
        elif k in ('n', 'N'):
            j8 = find_java(need)
            if j8:
                ver, v_str = get_java_version(j8)
                clear()
                draw_header(1, "JAVA ENCONTRADO", f"Java {need}")
                print(f'\033[{3};0H  {cl("c")}Java {ver} encontrado:{cl("0")} {j8}')
                print(f'\033[{4};0H  {cl("y")}Usar este Java?{cl("0")}  [S] Si  [N] No, ruta manual')
                k = get_key()
                if k in ('s', 'S'):
                    java_path = j8
                    break
            else:
                notify("No se encontro Java existente", 'r')
            if not java_path:
                clear()
                draw_header(1, "JAVA MANUAL", f"Ingresa la ruta de Java {need}")
                print(f'\033[{3};0H  {cl("k")}Ejemplo: /usr/lib/jvm/java-{need}-openjdk/bin/java{cl("0")}')
                jp = read_text(f'\033[{5};0H  {cl("y")}Ruta de Java:{cl("0")} ')
                if jp and os.path.exists(jp):
                    java_path = jp
                    break
                else:
                    notify("Ruta invalida", 'r')
        elif k in ('r', 'R'):
            clear()
            draw_header(1, "JAVA MANUAL", f"Ingresa la ruta de Java {need}")
            print(f'\033[{3};0H  {cl("k")}Ejemplo: /usr/lib/jvm/java-{need}-openjdk/bin/java{cl("0")}')
            jp = read_text(f'\033[{5};0H  {cl("y")}Ruta de Java:{cl("0")} ')
            if jp and os.path.exists(jp):
                java_path = jp
                break
            else:
                notify("Ruta invalida", 'r')
        elif k in ('q', 'esc'):
            show_cursor()
            clear()
            sys.exit(0)
    notify(f"Java listo! Descargando servidor...", 'g')
    sd = CFG.get('server_dir', BASE_DIR)
    print(f'\033[{3};0H  {cl("y")}Descargando servidor...{cl("0")}')
    print(f'\033[{4};0H  {cl("k")}Esto puede tomar varios minutos{cl("0")}')
    sys.stdout.flush()
    ok, msg = download_server(tipo, mc_ver, sd, java_path)
    if not ok:
        notify(f"Error: {msg}", 'r')
        return
    auto_configure(tipo, sd)
    ml = tipo
    if ml in ('paper', 'purpur', 'pufferfish', 'tuinity', 'spongevanilla', 'spongeforge', 'cardboard', 'banner'):
        ml = 'paper'
    CFG['server_dir'] = sd
    CFG['log_file'] = os.path.join(sd, "server.log")
    CFG['jar_path'] = os.path.join(sd, msg)
    CFG['jar_name'] = msg.replace('.jar', '')
    CFG['java_path'] = java_path
    CFG['server_version'] = mc_ver
    CFG['server_name'] = f"Minecraft {tipo_names.get(tipo, tipo)}"
    CFG['mod_loader'] = ml
    CFG['first_run'] = False
    clear()
    draw_header(1, "CONFIGURACION", "Casi listo!")
    nm = read_text(f'\033[{3};0H  {cl("y")}Nombre del servidor:{cl("0")} [{CFG["server_name"]}]: ', CFG['server_name'])
    if nm: CFG['server_name'] = nm
    desc = read_text(f'\033[{4};0H  {cl("y")}Descripcion (opcional):{cl("0")} ')
    if desc: CFG['server_description'] = desc
    save_config(CFG)
    clear()
    draw_header(1, "INSTALACION COMPLETA", f"{tipo_names.get(tipo, tipo)} {mc_ver}")
    print(f'\033[{3};0H  {cl("g")}Servidor instalado y configurado!{cl("0")}')
    print(f'\033[{4};0H  {cl("y")}Deseas iniciar el servidor ahora?{cl("0")}')
    print(f'\033[{5};0H  {cl("k")}[S] Si  [N] No{cl("0")}')
    k = get_key()
    if k in ('s', 'S'):
        clear()
        draw_header(1, "INICIANDO SERVIDOR", f"{CFG['server_name']}")
        print(f'\033[{3};0H  {cl("y")}Iniciando servidor, espera...{cl("0")}')
        sys.stdout.flush()
        from control.core.server import start
        ok, msg = start()
        if ok:
            print(f'\033[{4};0H  {cl("g")}Servidor iniciado!{cl("0")}')
        else:
            print(f'\033[{4};0H  {cl("r")}{msg}{cl("0")}')
        print(f'\033[{6};0H  {cl("k")}Presiona cualquier tecla para continuar...{cl("0")}')
        _get_key_raw()
    else:
        notify("Puedes iniciarlo desde el menu principal", 'c')

def first_time_setup():
    global CFG
    clear()
    cols = get_size()
    w = cols.columns
    y = 3
    print(f'\033[2J\033[H')
    draw_header(1, "CONFIGURACION INICIAL", "Bienvenido al Panel de Control")
    print(f'\033[{y};0H')
    print(f"  {cl('c')}Vamos a configurar tu servidor de Minecraft{cl('0')}")
    y += 2
    cfg = dict(CFG)
    sd = read_text(f"\033[{y};0H  {cl('y')}Directorio del servidor{cl('0')} [{cfg['server_dir']}]: ", cfg['server_dir'])
    if sd is None: sd = cfg['server_dir']
    cfg['server_dir'] = sd
    cfg['log_file'] = os.path.join(sd, "server.log")
    y += 2
    jp = read_text(f"\033[{y};0H  {cl('y')}Ruta de Java{cl('0')} [{cfg['java_path']}]: ", cfg['java_path'])
    if jp is None: jp = cfg['java_path']
    cfg['java_path'] = jp
    y += 2
    jar = read_text(f"\033[{y};0H  {cl('y')}Ruta del JAR del servidor{cl('0')} [{cfg['jar_path']}]: ", cfg['jar_path'])
    if jar is None: jar = cfg['jar_path']
    cfg['jar_path'] = jar
    cfg['jar_name'] = os.path.basename(jar).replace('.jar', '')
    y += 2
    sn = read_text(f"\033[{y};0H  {cl('y')}Nombre del servidor{cl('0')} (opcional) [{cfg['server_name']}]: ", cfg['server_name'])
    if sn is None: sn = cfg['server_name']
    cfg['server_name'] = sn
    y += 2
    sd2 = read_text(f"\033[{y};0H  {cl('y')}Descripcion{cl('0')} (opcional): ", cfg.get('server_description', ''))
    if sd2 is not None:
        cfg['server_description'] = sd2
    y += 2
    sv = read_text(f"\033[{y};0H  {cl('y')}Version de Minecraft{cl('0')} (opcional) [{cfg['server_version']}]: ", cfg['server_version'])
    if sv is None: sv = cfg['server_version']
    cfg['server_version'] = sv
    y += 2
    jn = os.path.basename(cfg.get('jar_path', ''))
    from control.core.shared import detect_mod_loader
    detected = detect_mod_loader(jn)
    cur_ml = cfg.get('mod_loader', 'auto')
    if cur_ml == 'auto' and detected:
        cur_ml = detected
    print(f"\033[{y};0H  {cl('y')}Cargador de mods:{cl('0')}")
    y += 1
    loaders = [('vanilla', 'Vanilla (sin mods)'), ('forge', 'Forge'), ('fabric', 'Fabric'),
               ('quilt', 'Quilt'), ('neoforge', 'NeoForge'), ('paper', 'Paper'),
               ('auto', 'Auto-detectar')]
    for i, (k, lbl) in enumerate(loaders):
        sel_mark = " ◉" if k == cur_ml else " ○"
        print(f"\033[{y+i};0H   {i+1}.{sel_mark} {lbl}")
    ml_idx_s = read_text(f"\033[{y+len(loaders)+1};0H  {cl('g')}Selecciona (1-{len(loaders)}):{A['0']} ")
    if ml_idx_s and ml_idx_s.isdigit():
        ml_idx = int(ml_idx_s) - 1
        if 0 <= ml_idx < len(loaders):
            chosen = loaders[ml_idx][0]
            if chosen == 'auto' and detected:
                chosen = detected
            cfg['mod_loader'] = chosen
    else:
        cfg['mod_loader'] = cur_ml
    cfg['first_run'] = False
    save_config(cfg)
    CFG = cfg
    notify("Configuracion guardada!", 'g')