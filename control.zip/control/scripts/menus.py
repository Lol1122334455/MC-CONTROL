import os, sys, time, shutil, re, json, select, subprocess

if os.name == 'nt':
    import msvcrt
from control.core.shared import CFG, VERSION, A, cl, ts, tc, get_t, get_bg, bg_set, \
    clear, hide_cursor, show_cursor, get_size, get_key, read_text, confirm, _get_key_raw, \
    draw_header, draw_footer, notify, notify_long, fmt_size, fmt_time, get_log_tail, \
    show_icon, get_profiles_dir, get_worlds_dir
from control.core.server import get_pid, get_uptime, get_server_stats, get_world_size, get_players, \
    send_cmd, start, stop
from control.core.backup import list_backups, create_backup, restore_backup_by_name, delete_backup_by_name
from control.core.profiles import get_profiles, save_profile_core, load_profile_core
from control.core.worlds import get_saved_worlds, save_current_world, switch_to_world, download_world_from_url
from control.core.mods import get_mods, mr_search, mr_versions, mr_install, mr_project, \
    cf_search, cf_files, cf_install, \
    spigot_search, spigot_resource, spigot_versions, spigot_install, clean_spiget_desc, is_plugin_server
from control.core.scheduler import load_scheduled_msgs, save_scheduled_msgs, \
    load_scheduled_tasks, save_scheduled_tasks

def draw_main_menu(sel):
    hide_cursor()
    cols = get_size()
    w, h = cols.columns, cols.lines
    pid = get_pid()
    stats = get_server_stats()
    uptime = get_uptime()
    players = get_players() if pid else []
    ws = get_world_size()
    bo = tc('box')
    no = tc('normal')
    hl = tc('header')
    ac = tc('accent')
    R = A['0']
    bg = get_bg()

    out_lines = []
    if bg:
        out_lines.append(f'{bg}\033[2J')

    out_lines.append(f'\033[H{bo}┌{"─"*(w-2)}┐{R}')
    title = f' {CFG["server_name"]} '
    sub = f'Panel de Control v{VERSION}'
    ver_tag = f'{cl("k")}v{CFG["server_version"]}{R}' if CFG.get('server_version') else ''
    out_lines.append(f'{bo}│{R}{" "*((w-2-len(title))//2-1)}{ac}{title}{R}{" "*((w-2-len(title))//2-1)}{bo}│{R}')
    out_lines.append(f'{bo}│{R}{" "*((w-2-len(sub))//2-1)}{hl}{sub}{R}{" "*(w-4-len(sub)-len(ver_tag))}{ver_tag}{bo}│{R}')

    stcol = 'G' if pid else 'R'
    stxt = "ONLINE" if pid else "OFFLINE"
    parts = [f' {cl(stcol)}●{R} {stxt}']
    if pid:
        if stats:
            parts.append(f'{cl("k")}│{R} RAM {cl("y")}{stats.get("ram","?")}MB{R}')
            parts.append(f'{cl("k")}│{R} Players {cl("c")}{len(players)}{R}')
        if uptime:
            parts.append(f'{cl("k")}│{R} Up {cl("k")}{fmt_time(uptime)}{R}')
        if ws:
            parts.append(f'{cl("k")}│{R} World {cl("k")}{fmt_size(ws)}{R}')
    stat_line = "".join(parts)
    out_lines.append(f'{bo}│{R}{stat_line}{" "*(w-4-len(stat_line))}{bo}│{R}')

    if CFG.get('server_description'):
        desc = CFG['server_description']
        out_lines.append(f'{bo}│{R} {cl("k")}{desc:<{w-5}}{R} {bo}│{R}')

    header_rows = 5 if CFG.get('server_description') else 4
    menu_top = header_rows + 1

    ml = CFG.get('mod_loader', 'auto')
    plugin_types = ('paper', 'purpur', 'pufferfish', 'tuinity', 'spigot', 'bukkit', 'spongevanilla', 'spongeforge', 'cardboard', 'banner', 'mohist', 'catserver')
    is_plugin = ml in plugin_types
    is_vanilla = ml == 'vanilla'
    if is_vanilla:
        mod_label = "Mods (S/Vanilla)"
        install_label = "Instalar Mod"
    elif is_plugin:
        mod_label = "Plugins"
        install_label = "Instalar Plugin"
    else:
        mod_label = "Mods"
        install_label = "Instalar Mod"

    if w < 55:
        sections = [
            ("SERVIDOR", [
                ("1", "Iniciar"), ("2", "Detener"), ("3", "Reiniciar"),
                ("4", "Consola"), ("5", "Logs"),
                ("6", "Backup"), ("7", "Restaurar"), ("8", "Ver"), ("9", "Borrar"),
            ]),
            ("PERFILES", [
                ("J", "Guardar"), ("K", "Cargar"), ("L", "Ver"), ("M", "Borrar"), ("N", "Nuevo"),
            ]),
            ("MUNDOS", [
                ("U", "Cambiar"), ("Y", "Descargar"),
            ]),
            ("JUGADORES", [
                ("A", "Gestionar"), ("B", "Broadcast"), ("C", "Whitelist"), ("D", "Admins"),
            ]),
            ("AUTOMAT.", [
                ("O", "Mensajes"), ("P", "Tareas"),
            ]),
            ("AJUSTES", [
                ("F", "Dificultad"), ("G", "Gamemode"), ("H", "Rendimiento"),
                ("E", "Limpiar Logs"),
            ]),
            ("EXTRAS", [
                ("M", mod_label), ("I", install_label),
                ("T", "Temas"), ("C", "Config"), ("S", "Props"), ("R", "Explorador"),
                ("U", "Actualizar"),
            ]),
        ]
    else:
        sections = [
            ("SERVIDOR", [
                ("1", "Iniciar"), ("2", "Detener"), ("3", "Reiniciar"),
                ("4", "Consola"), ("5", "Logs"),
                ("6", "Backup"), ("7", "Restaurar"), ("8", "Ver"), ("9", "Borrar"),
            ]),
            ("PERFILES", [
                ("J", "Guardar"), ("K", "Cargar"), ("L", "Ver"), ("M", "Borrar"), ("N", "Nuevo"),
            ]),
            ("MUNDOS", [
                ("U", "Cambiar Mundo"), ("Y", "Descargar Mundo"),
            ]),
            ("JUGADORES", [
                ("A", "Gestionar"), ("B", "Broadcast"), ("C", "Whitelist"), ("D", "Admins"),
            ]),
            ("AUTOMATIZACION", [
                ("O", "Mensajes"), ("P", "Tareas"),
            ]),
            ("AJUSTES", [
                ("F", "Dificultad"), ("G", "Gamemode"), ("H", "Rendimiento"),
                ("E", "Limpiar Logs"),
            ]),
            ("MODS / EXTRAS", [
                ("M", mod_label), ("I", install_label),
                ("T", "Temas"), ("C", "Config"), ("S", "Server Props"), ("R", "Explorador"),
                ("U", "Actualizar"),
            ]),
        ]

    flat_items = []
    for sec_name, items in sections:
        flat_items.append((None, sec_name, True))
        for k, lbl in items:
            flat_items.append((k, lbl, False))
    flat_items.append((None, "", True))

    total_items = len(flat_items)
    max_vis = h - menu_top - 5
    if max_vis < 4:
        max_vis = 4

    scroll_offset = 0
    if sel >= scroll_offset + max_vis:
        scroll_offset = sel - max_vis + 1
    if sel < scroll_offset:
        scroll_offset = sel

    out_lines.append(f'{bo}├{"─"*(w-2)}┤{R}')
    visible = flat_items[scroll_offset:scroll_offset + max_vis]
    actual_idx = scroll_offset

    for i, (key, label, is_header) in enumerate(visible):
        row = menu_top + i
        if row >= h - 5:
            break
        if is_header and label:
            pad = w - 6 - len(label)
            out_lines.append(f'{bo}│{R}  {cl("k")}▸{cl("k")}{label}{"─"*max(1,pad)}{R}  {bo}│{R}')
        elif is_header and not label:
            out_lines.append(f'{bo}│{R}{" "*(w-2)}{bo}│{R}')
        else:
            if actual_idx == sel:
                sel_fg, sel_bg = get_t("sel")
                out_lines.append(f'{bo}│{R}{ts(sel_fg, sel_bg)}  ● {key}. {label:<{w-11}}{R}{bo}│{R}')
            else:
                out_lines.append(f'{bo}│{R}    {cl("k")}{key}.{R} {no}{label}{R}{" "*(max(0,w-11-len(label)))}{bo}│{R}')
        actual_idx += 1

    if menu_top + max_vis < h - 5:
        out_lines.append(f'{bo}└{"─"*(w-2)}┘{R}')

    pag = f'[{scroll_offset+1}-{scroll_offset+len(visible)}/{total_items}]' if total_items > max_vis else ''
    out_lines.append(f'{bo}│{R}  {cl("k")}[W/S] Navegar  [Enter] Ok  [Q] Salir  {pag}{R}  {bo}│{R}')
    if menu_top + max_vis + 1 < h - 4:
        out_lines.append(f'{bo}└{"─"*(w-2)}┘{R}')

    sys.stdout.write('\n'.join(out_lines) + '\n')
    sys.stdout.write(f'{A["0"]}\033[J')
    sys.stdout.flush()

def edit_properties():
    props_file = os.path.join(CFG['server_dir'], "server.properties")
    if not os.path.exists(props_file):
        notify("No existe server.properties", 'r')
        return
    props = {}
    with open(props_file, 'r') as f:
        for txt in f:
            txt = txt.strip()
            if txt and not txt.startswith('#') and '=' in txt:
                k, v = txt.split('=', 1)
                props[k] = v
    while True:
        clear()
        cols = get_size()
        draw_header(1, "CONFIG SERVIDOR", "server.properties")
        y = 3
        keys_display = ['server-port', 'max-players', 'motd', 'view-distance', 'difficulty', 'gamemode',
                        'pvp', 'online-mode', 'enable-command-block', 'spawn-protection']
        for i, k in enumerate(keys_display):
            val = props.get(k, '?')
            print(f'\033[{y+i};0H  {i+1}. {cl("c")}{k}{A["0"]} = {cl("y")}{val}{A["0"]}')
        print(f'\033[{y+len(keys_display)+1};0H  {cl("g")}[1-10]{A["0"]} Editar  {cl("c")}[V]{A["0"]} Ver todo  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k in ('q', 'esc'):
            return
        if k == 'v':
            notify_long(open(props_file).read(), 'k')
            continue
        if k.isdigit():
            idx = int(k) - 1
            if 0 <= idx < len(keys_display):
                key = keys_display[idx]
                current = props.get(key, '')
                val = read_text(f'  {key} [{current}]: ', current)
                if val is not None:
                    props[key] = val
                    with open(props_file, 'w') as f:
                        for pk, pv in props.items():
                            f.write(f"{pk}={pv}\n")
                    notify("Guardado. Reinicia el servidor para aplicar.", 'g')
                    return

def list_mods_menu():
    ml = CFG.get('mod_loader', 'auto')
    plugin_types = ('paper', 'purpur', 'pufferfish', 'tuinity', 'spigot', 'bukkit', 'spongevanilla', 'spongeforge', 'cardboard', 'banner', 'mohist', 'catserver')
    is_plugin = ml in plugin_types
    label = "PLUGINS" if is_plugin else "MODS"
    inst_label = "Plugin" if is_plugin else "Mod"
    while True:
        mods = get_mods()
        clear()
        cols = get_size()
        draw_header(1, label, f"{len(mods)} instalados")
        y = 3
        if mods:
            for i, m in enumerate(mods[:30]):
                print(f'\033[{y+i};0H  {i+1}. {cl("g")}{m}{A["0"]}')
        else:
            print(f'\033[{y};0H  {cl("k")}No hay {label.lower()} instalados{A["0"]}')
            y += 1
        y += max(len(mods) + 2, 4)
        print(f'\033[{y};0H  {cl("c")}[I]{A["0"]} Instalar  {cl("p")}[M]{A["0"]} Modrinth  {cl("b")}[C]{A["0"]} CurseForge  {cl("y")}[P]{A["0"]} Spigot  {cl("r")}[D]{A["0"]} Borrar  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k in ('q', 'esc'):
            return
        if k == 'i':
            path = read_text("  Ruta del .jar: ")
            if path:
                path = path.strip('"').strip("'")
                if os.path.exists(path):
                    md = os.path.join(CFG['server_dir'], 'mods')
                    os.makedirs(md, exist_ok=True)
                    fn = os.path.basename(path)
                    shutil.copy2(path, os.path.join(md, fn))
                    notify(f"{inst_label} instalado: {fn}", 'g')
                else:
                    notify("Archivo no encontrado", 'r')
        if k == 'm':
            modrinth_browser()
        if k == 'c':
            curseforge_browser()
        if k == 'p':
            spigot_browser()
        if k == 'd' and mods:
            idx_s = read_text("  Numero: ")
            if idx_s and idx_s.isdigit():
                idx = int(idx_s) - 1
                if 0 <= idx < len(mods):
                    if confirm(f"  Borrar '{mods[idx]}'? (s/n): "):
                        os.remove(os.path.join(CFG['server_dir'], 'mods', mods[idx]))
                        notify("Borrado", 'g')

def full_screen_view(title, content_lines, footer_text=""):
    cols = get_size()
    w, h = cols.columns, cols.lines
    clear()
    draw_header(1, title)
    max_lines = min(len(content_lines), h - 6)
    for i, line in enumerate(content_lines[:max_lines]):
        print(f'\033[{3+i};0H  {line}')
    if len(content_lines) > max_lines:
        print(f'\033[{3+max_lines};0H  {cl("k")}... y {len(content_lines)-max_lines} mas{A["0"]}')
    dt = footer_text or "[Q] Volver"
    print(f'\033[{h-2};0H  {cl("k")}{dt}{A["0"]}')
    while True:
        k = get_key()
        if k in ('q', 'esc', 'enter', 'space'):
            break

def theme_menu():
    global CFG
    from control.core.shared import THEMES, save_config
    themes = list(THEMES.keys())
    sel = 0
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "TEMAS", "Personaliza los colores del panel")
        y = 3
        current = CFG.get('theme', 'default')
        for i, t in enumerate(themes):
            info = THEMES[t]
            label = info.get('label', t)
            mark = "◉" if t == current else "○"
            print(f'\033[{y+i};0H  {"▸" if sel==i else " "} {mark} {cl(info["title"][0])}{label}{A["0"]}')
        y += len(themes) + 2
        print(f'\033[{y};0H  {cl("k")}[W/S] Navegar [Enter] Seleccionar [Q] Volver{A["0"]}')
        k = get_key()
        if k == 'up' and sel > 0: sel -= 1
        elif k == 'down' and sel < len(themes)-1: sel += 1
        elif k == 'enter':
            CFG['theme'] = themes[sel]
            save_config(CFG)
            notify(f"Tema: {THEMES[themes[sel]]['label']}", 'g')
            return
        elif k in ('q', 'esc'):
            return

def config_menu():
    global CFG
    from control.core.shared import save_config, DEFAULTS
    fields = [
        ("server_name", "Nombre del servidor"),
        ("server_version", "Version"),
        ("server_description", "Descripcion"),
        ("server_dir", "Directorio del servidor"),
        ("java_path", "Ruta de Java"),
        ("jar_path", "Ruta del JAR"),
        ("rcon_port", "Puerto RCON"),
        ("rcon_password", "Password RCON"),
        ("backup_keep_days", "Dias a conservar backups"),
        ("curseforge_api_key", "API key CurseForge"),
        ("mod_loader", "Cargador de mods"),
    ]
    sel = 0
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "CONFIGURACION", "Ajustes del servidor")
        y = 3
        for i, (key, label) in enumerate(fields):
            val = CFG.get(key, '')
            marker = "▸" if sel == i else " "
            print(f'\033[{y+i};0H  {marker} {cl("c")}{label}:{A["0"]} {cl("y")}{val}{A["0"]}')
        y += len(fields) + 2
        print(f'\033[{y};0H  {cl("k")}[W/S] Navegar [Enter] Editar [R] Resetear config [Q] Volver{A["0"]}')
        k = get_key()
        if k == 'up' and sel > 0: sel -= 1
        elif k == 'down' and sel < len(fields)-1: sel += 1
        elif k == 'enter':
            key, label = fields[sel]
            current = str(CFG.get(key, ''))
            val = read_text(f'  {label} [{current}]: ', current)
            if val is not None:
                if key in ('rcon_port', 'backup_keep_days'):
                    try:
                        CFG[key] = int(val)
                    except:
                        CFG[key] = val
                else:
                    CFG[key] = val
                if key == 'jar_path':
                    CFG['jar_name'] = os.path.basename(val).replace('.jar', '')
                if key == 'server_dir':
                    CFG['log_file'] = os.path.join(val, 'server.log')
                save_config(CFG)
                notify("Guardado", 'g')
        elif k == 'r':
            if confirm("  Resetear a valores por defecto? (s/n): "):
                CFG = dict(DEFAULTS)
                save_config(CFG)
                notify("Config reseteada", 'y')
        elif k in ('q', 'esc'):
            return

def players_menu_full():
    if not get_pid():
        notify("Servidor no corriendo", 'r')
        return
    last_refresh = 0
    players = []
    while True:
        if time.time() - last_refresh > 3:
            players = get_players()
            last_refresh = time.time()
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "JUGADORES", f"{len(players)} conectados (auto-actualiza cada 3s)")
        y = 3
        if not players:
            print(f'\033[{y};0H  {cl("k")}No hay jugadores conectados{A["0"]}')
            y += 2
        else:
            for i, name in enumerate(players):
                print(f'\033[{y+i};0H  {cl("g")}{i+1}.{A["0"]} {name}')
            y += len(players) + 1
        print(f'\033[{y};0H  {cl("g")}[1-{len(players)}]{A["0"]} Seleccionar  {cl("c")}[B]{A["0"]} Broadcast  {cl("p")}[I]{A["0"]} Info  {cl("k")}[Q]{A["0"]} Volver')
        y += 2
        k = get_key()
        if k in ('q', 'esc'):
            return
        if k == 'b':
            msg = read_text("  Mensaje: ")
            if msg:
                send_cmd(f'tellraw @a {{"text":"[SERVER] {msg}","color":"yellow"}}')
                notify("Enviado", 'g')
        elif k == 'i':
            if players:
                msg = f"Conectados: {', '.join(players)}"
                notify_long(msg, 'c')
        elif k.isdigit() and players:
            idx = int(k) - 1
            if 0 <= idx < len(players):
                player = players[idx]
                while True:
                    clear()
                    draw_header(1, f"ACCIONES: {player}")
                    y = 3
                    actions = [
                        ("1", "Dar Admin (op)"), ("2", "Quitar Admin (deop)"),
                        ("3", "Echar (kick)"), ("4", "Banear"),
                        ("5", "Banear IP"), ("6", "TP a ti"),
                        ("7", "TP aqui"), ("8", "Matar"),
                        ("9", "Curar"), ("0", "Volver"),
                    ]
                    for i, (k2, label) in enumerate(actions):
                        print(f'\033[{y+i};0H  {k2}. {label}')
                    k2 = get_key()
                    cmds = {
                        '1': f'op {player}', '2': f'deop {player}', '3': f'kick {player}',
                        '4': f'ban {player}', '5': f'ban-ip {player}', '6': f'tp @p {player}',
                        '7': f'tp {player} @p', '8': f'kill {player}', '9': f'effect give {player} minecraft:instant_health 1 255',
                    }
                    if k2 in cmds:
                        send_cmd(cmds[k2])
                        notify("Accion realizada", 'g')
                        players = get_players()
                        last_refresh = time.time()
                        break
                    elif k2 in ('0', 'q', 'esc'):
                        break

def console_full():
    if not get_pid():
        notify("Servidor no corriendo", 'r')
        return
    cols = get_size()
    w, h = cols.columns, cols.lines
    clear()
    draw_header(1, "CONSOLA", "Escribe comandos para el servidor")
    log_h = h - 8
    log_lines = get_log_tail(log_h)
    for i, line in enumerate(log_lines[:log_h]):
        print(f'\033[{3+i};0H {line[:w-4]}')
    print(f'\033[{h-3};0H  {cl("c")}Comando (Enter para enviar, Q salir):{A["0"]}')
    cmd = read_text(f'\033[{h-2};0H  {cl("g")}►{A["0"]} ')
    if cmd:
        send_cmd(cmd)
        notify("Comando enviado", 'g')

def logs_full():
    if not get_pid():
        notify("Servidor no corriendo", 'r')
        return
    clear()
    cols = get_size()
    w, h = cols.columns, cols.lines
    draw_header(1, "LOGS EN VIVO", "Ctrl+C para salir")
    print(f'\033[{h-2};0H  {cl("k")}[Q] Volver{A["0"]}')
    log_file = CFG['log_file']
    if not os.path.exists(log_file):
        notify("Archivo de log no encontrado", 'r')
        return
    is_win = os.name == 'nt'
    if is_win:
        last_size = os.path.getsize(log_file)
        try:
            while True:
                if msvcrt.kbhit():
                    k = get_key()
                    if k in ('q', 'esc'):
                        return
                if os.path.exists(log_file):
                    sz = os.path.getsize(log_file)
                    if sz > last_size:
                        with open(log_file, 'r') as f:
                            f.seek(last_size)
                            for line in f:
                                line = line.rstrip()
                                if line:
                                    print(line[:w-2])
                        last_size = sz
                time.sleep(0.5)
        except:
            pass
        return
    proc = None
    try:
        proc = subprocess.Popen(["tail", "-f", log_file], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        while True:
            r, _, _ = select.select([proc.stdout, sys.stdin], [], [], 0.5)
            if proc.stdout in r:
                line = proc.stdout.readline()
                if line:
                    print(line.decode().rstrip()[:w-2])
            if sys.stdin in r:
                k = get_key()
                if k in ('q', 'esc'):
                    proc.terminate()
                    return
    except:
        pass
    finally:
        if proc:
            try:
                proc.terminate()
            except:
                pass

def auto_broadcast_menu():
    while True:
        msgs = load_scheduled_msgs()
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "MENSAJES PROGRAMADOS")
        y = 3
        if msgs:
            for i, m in enumerate(msgs):
                st = f'{cl("g")}ACTIVO{A["0"]}' if m['enabled'] else f'{cl("r")}INACTIVO{A["0"]}'
                print(f'\033[{y+i};0H  {i+1}. {cl("y")}{m["time"]}{A["0"]} {st} {m["msg"][:40]}')
            y += len(msgs) + 1
        else:
            print(f'\033[{y};0H  {cl("k")}No hay mensajes{A["0"]}')
            y += 2
        print(f'\033[{y};0H  {cl("g")}[A]{A["0"]} Agregar  {cl("r")}[D]{A["0"]} Eliminar  {cl("y")}[T]{A["0"]} Activar/Desactivar  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'a':
            t = read_text("  Hora (ej: 12:30pm): ")
            if t and re.match(r"^\d{1,2}:\d{2}(am|pm)$", t.replace(" ","").lower()):
                msg = read_text("  Mensaje: ")
                if msg:
                    msgs.append({"time": t.replace(" ","").lower(), "msg": msg, "enabled": True})
                    save_scheduled_msgs(msgs)
                    notify("Mensaje agregado", 'g')
        elif k == 'd':
            if msgs:
                idx_s = read_text("  Numero: ")
                if idx_s and idx_s.isdigit():
                    idx = int(idx_s) - 1
                    if 0 <= idx < len(msgs):
                        del msgs[idx]
                        save_scheduled_msgs(msgs)
                        notify("Eliminado", 'g')
        elif k == 't':
            if msgs:
                idx_s = read_text("  Numero: ")
                if idx_s and idx_s.isdigit():
                    idx = int(idx_s) - 1
                    if 0 <= idx < len(msgs):
                        msgs[idx]['enabled'] = not msgs[idx]['enabled']
                        save_scheduled_msgs(msgs)
                        notify("Cambiado", 'g')

def scheduled_tasks_menu():
    while True:
        tasks = load_scheduled_tasks()
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "TAREAS PROGRAMADAS")
        y = 3
        if tasks:
            for i, t in enumerate(tasks):
                st = f'{cl("g")}ACTIVO{A["0"]}' if t['enabled'] else f'{cl("r")}INACTIVO{A["0"]}'
                print(f'\033[{y+i};0H  {i+1}. {cl("y")}{t["time"]}{A["0"]} {cl("c")}{t["action"].upper()}{A["0"]} {st} {t["desc"]}')
            y += len(tasks) + 1
        else:
            print(f'\033[{y};0H  {cl("k")}No hay tareas{A["0"]}')
            y += 2
        print(f'\033[{y};0H  {cl("g")}[A]{A["0"]} Agregar  {cl("r")}[D]{A["0"]} Eliminar  {cl("y")}[T]{A["0"]} Activar/Desactivar  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'a':
            t = read_text("  Hora (ej: 10:00pm): ")
            if t and re.match(r"^\d{1,2}:\d{2}(am|pm)$", t.replace(" ","").lower()):
                act = read_text("  Accion (start/stop/restart): ")
                if act in ('start','stop','restart'):
                    desc = read_text("  Descripcion: ")
                    tasks.append({"time": t.replace(" ","").lower(), "action": act, "enabled": True, "desc": desc or ""})
                    save_scheduled_tasks(tasks)
                    notify("Tarea agregada", 'g')
        elif k == 'd':
            if tasks:
                idx_s = read_text("  Numero: ")
                if idx_s and idx_s.isdigit():
                    idx = int(idx_s) - 1
                    if 0 <= idx < len(tasks):
                        del tasks[idx]
                        save_scheduled_tasks(tasks)
                        notify("Eliminada", 'g')
        elif k == 't':
            if tasks:
                idx_s = read_text("  Numero: ")
                if idx_s and idx_s.isdigit():
                    idx = int(idx_s) - 1
                    if 0 <= idx < len(tasks):
                        tasks[idx]['enabled'] = not tasks[idx]['enabled']
                        save_scheduled_tasks(tasks)
                        notify("Cambiado", 'g')

def whitelist_menu():
    if not get_pid():
        notify("Servidor no corriendo", 'r')
        return
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "WHITELIST")
        y = 3
        print(f'\033[{y};0H  {cl("g")}[1]{A["0"]} Activar whitelist')
        print(f'\033[{y+1};0H  {cl("r")}[2]{A["0"]} Desactivar whitelist')
        print(f'\033[{y+2};0H  {cl("y")}[3]{A["0"]} Ver whitelist')
        print(f'\033[{y+3};0H  {cl("g")}[4]{A["0"]} Agregar jugador')
        print(f'\033[{y+4};0H  {cl("r")}[5]{A["0"]} Quitar jugador')
        print(f'\033[{y+5};0H  {cl("k")}[0]{A["0"]} Volver')
        k = get_key()
        if k == '1':
            send_cmd("whitelist on"); notify("Whitelist activada", 'g')
        elif k == '2':
            send_cmd("whitelist off"); notify("Whitelist desactivada", 'y')
        elif k == '3':
            send_cmd("whitelist list"); time.sleep(0.5)
            lines = get_log_tail(20)
            for line in lines:
                if 'whitelist' in line.lower():
                    notify_long(line, 'c')
                    break
            else:
                notify("Sin jugadores en whitelist", 'k')
        elif k == '4':
            p = read_text("  Jugador: ")
            if p and send_cmd(f"whitelist add {p}"):
                notify(f"{p} agregado", 'g')
        elif k == '5':
            p = read_text("  Jugador: ")
            if p and send_cmd(f"whitelist remove {p}"):
                notify(f"{p} removido", 'y')
        elif k in ('0', 'q', 'esc'):
            return

def explorer():
    cur = CFG['server_dir']
    sel = 0
    scroll = 0
    while True:
        cols = get_size()
        w, h = cols.columns, cols.lines
        clear()
        rel = cur.replace(CFG['server_dir'], '~') if cur.startswith(CFG['server_dir']) else cur
        draw_header(1, "EXPLORADOR", rel)
        items = []
        try:
            entries = sorted(os.listdir(cur), key=lambda x: (not os.path.isdir(os.path.join(cur, x)), x.lower()))
            for e in entries:
                full = os.path.join(cur, e)
                items.append(('dir', e) if os.path.isdir(full) else ('file', e))
        except:
            pass
        max_vis = h - 7
        if cur != CFG['server_dir']:
            max_vis -= 1
        if sel < scroll:
            scroll = sel
        if sel >= scroll + max_vis:
            scroll = sel - max_vis + 1
        visible = items[scroll:scroll + max_vis] if max_vis > 0 else []
        y = 3
        if cur != CFG['server_dir']:
            print(f'\033[{y};0H  {"▸" if sel==0 and scroll==0 else " "} 0. {cl("c")}[..]{A["0"]}')
            y += 1
            actual_idx = 1
        else:
            actual_idx = 0
        for i, (t, name) in enumerate(visible):
            if y >= h - 3:
                break
            s = ""
            if t == 'file':
                try:
                    s = fmt_size(os.path.getsize(os.path.join(cur, name)))
                except:
                    s = "?"
            icon = f'{cl("c")}DIR {A["0"]}' if t == 'dir' else f'{cl("k")}FILE{A["0"]}'
            item_idx = i + (1 if cur != CFG['server_dir'] else 0)
            idx_num = i + scroll + (1 if cur != CFG['server_dir'] else 0)
            marker = "▸" if sel == idx_num else " "
            print(f'\033[{y};0H  {marker} {idx_num}. {name:<35} {icon} {s}')
            y += 1
        print(f'\033[{h-2};0H  {cl("k")}[W/S] Navegar [Enter] Abrir [V] Ver [D] Borrar [Q] Salir{A["0"]}')
        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 'up' and sel > 0:
            sel -= 1
        elif k == 'down' and sel < len(items) + (1 if cur != CFG['server_dir'] else 0) - 1:
            sel += 1
        elif k == 'enter' or k == 'space':
            if cur != CFG['server_dir'] and sel == 0:
                cur = os.path.dirname(cur)
                sel = 0
                scroll = 0
            else:
                idx = sel - (1 if cur != CFG['server_dir'] else 0)
                if 0 <= idx < len(items):
                    t, name = items[idx]
                    if t == 'dir':
                        cur = os.path.join(cur, name)
                        sel = 0
                        scroll = 0
        elif k == 'v':
            idx = sel - (1 if cur != CFG['server_dir'] else 0)
            if 0 <= idx < len(items) and items[idx][0] == 'file':
                fn = items[idx][1]
                try:
                    with open(os.path.join(cur, fn), 'r') as f:
                        content = f.read()
                    clear()
                    draw_header(1, f"ARCHIVO: {fn}")
                    for j, line in enumerate(content.split('\n')[:h-6]):
                        print(f'\033[{3+j};0H  {line[:w-4]}')
                    print(f'\033[{h-2};0H  {cl("k")}[Qualquier tecla] Volver{A["0"]}')
                    _get_key_raw()
                except:
                    notify("No se puede leer", 'r')
        elif k == 'd':
            idx = sel - (1 if cur != CFG['server_dir'] else 0)
            if 0 <= idx < len(items):
                name = items[idx][1]
                if confirm(f"  Borrar '{name}'? (s/n): "):
                    try:
                        full = os.path.join(cur, name)
                        if os.path.isdir(full):
                            shutil.rmtree(full)
                        else:
                            os.remove(full)
                        notify("Borrado", 'g')
                        sel = max(0, sel - 1)
                    except Exception as e:
                        notify(f"Error: {e}", 'r')

def profile_save_menu():
    name = read_text("  Nombre del perfil: ")
    if name:
        ok, msg = save_profile_core(name)
        notify(msg, 'g' if ok else 'r')

def profile_load_menu():
    profiles = get_profiles()
    if not profiles:
        notify("No hay perfiles", 'k')
        return
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "CARGAR PERFIL")
        y = 3
        for i, p in enumerate(profiles):
            mc = len([f for f in os.listdir(os.path.join(get_profiles_dir(), p, 'mods')) if f.endswith('.jar')]) if os.path.exists(os.path.join(get_profiles_dir(), p, 'mods')) else 0
            print(f'\033[{y+i};0H  {i+1}. {cl("g")}{p}{A["0"]} ({mc} mods)')
        print(f'\033[{y+len(profiles)+1};0H  {cl("k")}[1-{len(profiles)}] Cargar [Q] Volver{A["0"]}')
        k = get_key()
        if k in ('q', 'esc'):
            return
        if k.isdigit():
            idx = int(k) - 1
            if 0 <= idx < len(profiles):
                ok, msg = load_profile_core(profiles[idx])
                notify(msg, 'g' if ok else 'r')
                return

def profile_delete_menu():
    profiles = get_profiles()
    if not profiles:
        notify("No hay perfiles", 'k')
        return
    while True:
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "BORRAR PERFIL")
        y = 3
        for i, p in enumerate(profiles):
            print(f'\033[{y+i};0H  {i+1}. {p}')
        print(f'\033[{y+len(profiles)+1};0H  {cl("k")}[1-{len(profiles)}] Borrar [Q] Volver{A["0"]}')
        k = get_key()
        if k in ('q', 'esc'):
            return
        if k.isdigit():
            idx = int(k) - 1
            if 0 <= idx < len(profiles):
                if confirm(f"  Borrar perfil '{profiles[idx]}'? (s/n): "):
                    try:
                        shutil.rmtree(os.path.join(get_profiles_dir(), profiles[idx]))
                        notify("Borrado", 'g')
                    except Exception as e:
                        notify(f"Error: {e}", 'r')
                return

def profile_new_menu():
    if get_pid():
        notify("Deten el servidor primero", 'r')
        return
    if confirm("  Guardar perfil actual? (s/n): "):
        name = read_text("  Nombre del perfil: ")
        if name:
            save_profile_core(name)
    sd = CFG['server_dir']
    count = 0
    try:
        for d in ['world', 'mods', 'config', 'DIM-1', 'DIM1']:
            dp = os.path.join(sd, d)
            if os.path.exists(dp):
                shutil.rmtree(dp)
                count += 1
        notify(f"Nuevo mundo creado (borradas {count} carpetas)", 'g')
    except Exception as e:
        notify(f"Error: {e}", 'r')

def world_switch_menu():
    wdir = get_worlds_dir()
    while True:
        worlds = get_saved_worlds()
        clear()
        cols = get_size()
        w = cols.columns
        draw_header(1, "MUNDOS GUARDADOS", f"{len(worlds)} mundos")
        y = 3
        if worlds:
            for i, name in enumerate(worlds):
                wp = os.path.join(wdir, name)
                sz = 0
                for dp, _, fn in os.walk(wp):
                    for f in fn:
                        try:
                            sz += os.path.getsize(os.path.join(dp, f))
                        except:
                            pass
                print(f'\033[{y+i};0H  {i+1}. {cl("g")}{name}{A["0"]} ({fmt_size(sz)})')
            y += len(worlds) + 1
        else:
            print(f'\033[{y};0H  {cl("k")}No hay mundos guardados. Guarda el mundo actual primero.{A["0"]}')
            y += 2
        print(f'\033[{y};0H  {cl("c")}[1-{len(worlds)}]{A["0"]} Cargar  {cl("g")}[S]{A["0"]} Guardar actual  {cl("y")}[D]{A["0"]} Duplicar  {cl("r")}[X]{A["0"]} Borrar  {cl("k")}[Q]{A["0"]} Volver')
        k = get_key()
        if k in ('q', 'esc'):
            return
        elif k == 's':
            name = read_text("  Nombre para guardar el mundo actual: ")
            if name:
                ok, msg = save_current_world(name)
                notify(msg, 'g' if ok else 'r')
        elif k == 'd' and worlds:
            src_name = read_text("  Mundo a duplicar (nombre): ")
            if src_name and src_name in worlds:
                new_name = read_text("  Nuevo nombre: ")
                if new_name:
                    try:
                        shutil.copytree(os.path.join(wdir, src_name), os.path.join(wdir, new_name))
                        notify(f"Mundo duplicado: {new_name}", 'g')
                    except Exception as e:
                        notify(f"Error: {e}", 'r')
        elif k == 'x' and worlds:
            name = read_text("  Nombre del mundo a borrar: ")
            if name and name in worlds:
                if confirm(f"  Borrar '{name}'? (s/n): "):
                    try:
                        shutil.rmtree(os.path.join(wdir, name))
                        notify("Borrado", 'g')
                    except Exception as e:
                        notify(f"Error: {e}", 'r')
        elif k.isdigit() and worlds:
            idx = int(k) - 1
            if 0 <= idx < len(worlds):
                name = worlds[idx]
                if confirm(f"  Cargar mundo '{name}'? Se detendra el servidor. (s/n): "):
                    ok, msg = switch_to_world(name)
                    notify(msg, 'g' if ok else 'r')
                    return

def world_download_menu():
    wdir = get_worlds_dir()
    clear()
    cols = get_size()
    draw_header(1, "DESCARGAR MUNDO", "Desde URL")
    print(f'\033[{3};0H  {cl("c")}Descarga un mundo desde una URL y lo importa.{A["0"]}')
    print(f'\033[{4};0H  {cl("k")}Soporta: .zip, .tar.gz, .tar{cl("0")}')
    url = read_text(f'\033[{6};0H  {cl("y")}URL del mundo:{A["0"]} ')
    if not url:
        return
    name = read_text(f'\033[{7};0H  {cl("y")}Nombre para el mundo:{A["0"]} ', "imported_world")
    if not name:
        name = "imported_world"
    ok, msg = download_world_from_url(url, name)
    notify(msg, 'g' if ok else 'r')
    if ok and confirm(f"  Cargar este mundo ahora? (s/n): "):
        ok2, msg2 = switch_to_world(name)
        notify(msg2, 'g' if ok2 else 'r')

def curseforge_browser():
    cols = get_size()
    while True:
        clear()
        draw_header(1, "CURSEFORGE", "Busca e instala mods")
        print(f'\033[{3};0H  {cl("c")}Buscar mods en CurseForge{cl("0")}')
        print(f'\033[{4};0H  {cl("k")}Escribe tu busqueda (o Q para volver):{A["0"]}')
        q = read_text(f'\033[{5};0H  {cl("g")}►{A["0"]} ')
        if not q or q.lower() == 'q':
            return
        results = cf_search(q)
        if not results:
            notify("Sin resultados o error de conexion (posiblemente necesite API key)", 'r')
            continue
        lw = int(cols.columns * 0.68)
        rw = cols.columns - lw - 3
        sx = lw + 2
        sel = 0
        filter_mc = ""
        filter_loader = "all"
        while True:
            fresults = results
            if filter_mc or filter_loader != "all":
                fresults = []
                for r in results:
                    lfs = r.get('latestFiles', [])
                    mc_ok = True
                    ld_ok = True
                    if filter_mc:
                        mc_ok = any(filter_mc in (gv if isinstance(gv, str) else gv.get('gameVersion','')) for v in lfs for gv in v.get('gameVersions', []))
                    if filter_loader != "all":
                        ld_ok = any(filter_loader in v.get('gameVersions', []) for v in lfs)
                    if mc_ok and ld_ok:
                        fresults.append(r)
            if not fresults:
                notify("Sin coincidencias con filtros", 'r')
                filter_mc = ""
                filter_loader = "all"
                continue
            sel = min(sel, len(fresults)-1)
            clear()
            draw_header(1, f"RESULTADOS CF: {q}", f"{len(fresults)} mods")
            for yy in range(3, cols.lines - 1):
                print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
            max_vis = (cols.lines - 5) // 2
            sc = max(0, min(sel - max_vis + 2, len(fresults) - max_vis)) if sel >= max_vis else 0
            visible = fresults[sc:sc+max_vis]
            for i, m in enumerate(visible):
                idx = sc + i
                name = m.get('name', m.get('slug', '?'))
                authors = m.get('authors', [])
                author = authors[0].get('name', '?') if authors else '?'
                downloads = m.get('downloadCount', 0)
                dl_str = f"{downloads//1000}k" if downloads > 999 else str(downloads)
                y = 3 + i * 2
                if y + 1 >= cols.lines - 1:
                    break
                if idx == sel:
                    print(f'\033[{y};0H  \033[7m {cl("c")}{name:<{lw-7}}{A["0"]}\033[7m {cl("k")}{dl_str:>6}{A["0"]}\033[7m {A["0"]}')
                    print(f'\033[{y+1};0H  \033[7m {cl("k")}by {author:<{lw-10}}{A["0"]}\033[7m {A["0"]}')
                else:
                    print(f'\033[{y};0H  {cl("b")}{name:<{lw-12}}{A["0"]} {cl("k")}{dl_str:>6}{A["0"]}')
                    print(f'\033[{y+1};0H    {cl("k")}by {author}{A["0"]}')
            fx = sx + 2
            fy = 3
            print(f'\033[{fy};{fx}H{cl("c")}{" FILTROS ":^{rw-2}}{A["0"]}')
            fy += 2
            mc_label = filter_mc or "Todas"
            print(f'\033[{fy};{fx}H{cl("y")}MC:{A["0"]} {cl("k")}[{mc_label:<{rw-8}}]{A["0"]}')
            fy += 1
            ld_label = filter_loader if filter_loader != "all" else "Cualquiera"
            print(f'\033[{fy};{fx}H{cl("y")}Loader:{A["0"]} {cl("k")}[{ld_label:<{rw-10}}]{A["0"]}')
            fy += 1
            all_loaders = set()
            for r in fresults:
                for lf in r.get('latestFiles', []):
                    for gv in lf.get('gameVersions', []):
                        if gv.lower() in ('forge','fabric','neoforge','quilt','bukkit','spigot','paper'):
                            all_loaders.add(gv.lower())
            if all_loaders:
                lstr = ", ".join(sorted(all_loaders))
                for line in [lstr[j:j+rw-4] for j in range(0, len(lstr), rw-4)][:2]:
                    if fy >= cols.lines - 8:
                        break
                    print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                    fy += 1
            fy += 1
            if sel < len(fresults):
                m = fresults[sel]
                print(f'\033[{fy};{fx}H{cl("c")}{" INFO ":^{rw-2}}{A["0"]}')
                fy += 1
                icon_url = m.get('logo', {}).get('thumbnailUrl', '')
                if icon_url:
                    ilines = show_icon(icon_url, min(rw-4, 20), 5)
                    for line in ilines[:5]:
                        if fy >= cols.lines - 3:
                            break
                        print(f'\033[{fy};{fx}H{line:<{rw-2}}{A["0"]}')
                        fy += 1
                print(f'\033[{fy};{fx}H {cl("y")}Autor:{A["0"]} {cl("k")}{m.get("authors",[{}])[0].get("name","?"):<{rw-10}}{A["0"]}')
                fy += 1
                desc = m.get('summary', '')
                if desc:
                    for line in [desc[j:j+rw-4] for j in range(0, len(desc), rw-4)][:4]:
                        if fy >= cols.lines - 2:
                            break
                        print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                        fy += 1
            by = cols.lines - 1
            print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Versiones [Q] Volver [/] Buscar [F] Filtros{A["0"]}')
            k = get_key()
            if k == 'up' and sel > 0:
                sel -= 1
            elif k == 'down' and sel < len(fresults) - 1:
                sel += 1
            elif k == '/':
                clear()
                draw_header(1, "CURSEFORGE", "Nueva busqueda")
                q2 = read_text(f'\033[{4};0H  {cl("g")}►{A["0"]} ')
                if q2 and q2.lower() != 'q':
                    q = q2
                    results = cf_search(q)
                    if not results:
                        return
                    sel = 0
                    filter_loader = "all"
            elif k == 'f':
                clear()
                draw_header(1, "FILTROS", "")
                print(f'\033[{3};0H  {cl("c")}Version MC [Actual: {filter_mc or "Todas"}]:{A["0"]}')
                nm = read_text(f'\033[{4};0H  {cl("g")}►{A["0"]} ')
                if nm:
                    filter_mc = nm
                print(f'\033[{5};0H  {cl("c")}Loader [Actual: {filter_loader}]:{A["0"]}')
                print(f'\033[{6};0H  {cl("k")}all | forge | fabric | neoforge | quilt | bukkit | spigot | paper{A["0"]}')
                nl = read_text(f'\033[{7};0H  {cl("g")}►{A["0"]} ')
                if nl in ('all','forge','fabric','neoforge','quilt','bukkit','spigot','paper',''):
                    filter_loader = nl or "all"
                sel = 0
            elif k == 'enter':
                proj = fresults[sel]
                mid = proj.get('id', 0)
                if mid:
                    curseforge_versions_menu(mid, proj.get('name', '?'))
                    results = cf_search(q)
                    if not results:
                        return
                    sel = 0
            elif k in ('q', 'esc'):
                return

def curseforge_versions_menu(mod_id, title):
    cols = get_size()
    lw = int(cols.columns * 0.65)
    rw = cols.columns - lw - 3
    sx = lw + 2
    filter_mc = ""
    sel = 0
    while True:
        files = cf_files(mod_id, filter_mc)
        if not files:
            if filter_mc:
                notify("Sin coincidencias para esa version", 'r')
                filter_mc = ""
                continue
            notify("No se pudieron cargar versiones", 'r')
            return
        sel = min(sel, len(files)-1)
        clear()
        draw_header(1, f"VERSIONES CF: {title}", f"{len(files)} disponibles")
        for yy in range(3, cols.lines - 1):
            print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
        y = 3
        print(f'\033[{y};0H  MC:{cl("k")}[{filter_mc or "Todas"}]{A["0"]}')
        y += 2
        max_vis = (cols.lines - y - 1) // 2
        sc = max(0, min(sel - max_vis + 2, len(files) - max_vis)) if sel >= max_vis else 0
        visible = files[sc:sc+max_vis]
        for i, v in enumerate(visible):
            idx = sc + i
            dn = v.get('displayName', v.get('fileName', '?'))
            gv = v.get('gameVersions', [])
            gv_str = str(gv[0]) if gv else "?"
            flen = v.get('fileLength', 0)
            if flen >= 1048576:
                sz = f"{flen/1048576:.1f}MB"
            elif flen >= 1024:
                sz = f"{flen/1024:.0f}KB"
            else:
                sz = f"{flen}B" if flen else ""
            label = dn[:lw-12] + ".." if len(dn) > lw - 12 else dn
            if y >= cols.lines - 1:
                break
            if idx == sel:
                print(f'\033[{y};0H  \033[7m {label:<{lw-10}} {sz:>7} {A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H  \033[7m {cl("k")}MC:{gv_str:<{lw-12}}{A["0"]}\033[7m {A["0"]}')
            else:
                print(f'\033[{y};0H  {cl("b") if idx%2==0 else cl("c")}{label:<{lw-10}} {cl("k")}{sz:>7}{A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H    {cl("k")}MC:{gv_str}{A["0"]}')
            y += 1
        fx = sx + 2
        fy = 3
        print(f'\033[{fy};{fx}H{cl("c")}{" INFO ":^{rw-2}}{A["0"]}')
        fy += 2
        if sel < len(files):
            v = files[sel]
            print(f'\033[{fy};{fx}H {cl("y")}Archivo:{A["0"]}')
            fy += 1
            fn2 = v.get('fileName', '')
            for line in [fn2[j:j+rw-4] for j in range(0, len(fn2), rw-4)][:2]:
                print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                fy += 1
            flen = v.get('fileLength', 0)
            if flen >= 1048576:
                sz = f"{flen/1048576:.1f} MB"
            elif flen >= 1024:
                sz = f"{flen/1024:.0f} KB"
            else:
                sz = f"{flen} B" if flen else "?"
            print(f'\033[{fy};{fx}H {cl("y")}Tamano:{A["0"]} {cl("k")}{sz:<{rw-10}}{A["0"]}')
            fy += 1
            dc = v.get('downloadCount', 0)
            if dc:
                print(f'\033[{fy};{fx}H {cl("y")}DL:{A["0"]} {cl("k")}{dc:<{rw-6}}{A["0"]}')
                fy += 1
        by = cols.lines - 1
        print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Instalar [Q] Volver [M] Filtrar MC{A["0"]}')
        k = get_key()
        if k == 'up' and sel > 0:
            sel -= 1
        elif k == 'down' and sel < len(files) - 1:
            sel += 1
        elif k == 'm':
            nm = read_text(f'\033[{3};0H  {cl("g")}Filtrar MC:{A["0"]} ').strip()
            if nm:
                filter_mc = nm
            else:
                filter_mc = ""
            sel = 0
        elif k == 'enter':
            fid = files[sel].get('id', 0)
            fname = files[sel].get('fileName', '')
            if fid:
                md = os.path.join(CFG['server_dir'], 'mods')
                os.makedirs(md, exist_ok=True)
                ok, fn = cf_install(mod_id, fid, md, fname)
                if ok:
                    sz = os.path.getsize(os.path.join(md, fn))
                    if sz >= 1048576:
                        szs = f"{sz/1048576:.1f}MB"
                    elif sz >= 1024:
                        szs = f"{sz/1024:.0f}KB"
                    else:
                        szs = f"{sz}B"
                    notify(f"Instalado: {fn} ({szs})", 'g')
                else:
                    notify(f"Error: {fn}", 'r')
                return
        elif k in ('q', 'esc'):
            return

def spigot_browser():
    cols = get_size()
    while True:
        clear()
        draw_header(1, "SPIGOT", "Busca e instala plugins")
        print(f'\033[{3};0H  {cl("c")}Buscar plugins en Spigot{cl("0")}')
        print(f'\033[{4};0H  {cl("k")}Escribe tu busqueda (o Q para volver):{A["0"]}')
        q = read_text(f'\033[{5};0H  {cl("g")}►{A["0"]} ')
        if not q or q.lower() == 'q':
            return
        results = spigot_search(q)
        if not results:
            notify("Sin resultados o error de conexion", 'r')
            continue
        lw = int(cols.columns * 0.68)
        rw = cols.columns - lw - 3
        sx = lw + 2
        sel = 0
        while True:
            fresults = results
            if not fresults:
                notify("Sin coincidencias", 'r')
                return
            sel = min(sel, len(fresults)-1)
            clear()
            draw_header(1, f"RESULTADOS SPIGOT: {q}", f"{len(fresults)} plugins")
            for yy in range(3, cols.lines - 1):
                print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
            max_vis = (cols.lines - 5) // 2
            sc = max(0, min(sel - max_vis + 2, len(fresults) - max_vis)) if sel >= max_vis else 0
            visible = fresults[sc:sc+max_vis]
            for i, m in enumerate(visible):
                idx = sc + i
                name = m.get('name', '?')
                author = m.get('author', {})
                author = author.get('name', str(author.get('id', '?'))) if isinstance(author, dict) else str(author)
                downloads = m.get('downloads', 0) or m.get('file', {}).get('downloads', 0)
                dl_str = f"{downloads//1000}k" if downloads > 999 else str(downloads)
                y = 3 + i * 2
                if y + 1 >= cols.lines - 1:
                    break
                if idx == sel:
                    print(f'\033[{y};0H  \033[7m {cl("c")}{name:<{lw-7}}{A["0"]}\033[7m {cl("k")}{dl_str:>6}{A["0"]}\033[7m {A["0"]}')
                    print(f'\033[{y+1};0H  \033[7m {cl("k")}by {author:<{lw-10}}{A["0"]}\033[7m {A["0"]}')
                else:
                    print(f'\033[{y};0H  {cl("p")}{name:<{lw-12}}{A["0"]} {cl("k")}{dl_str:>6}{A["0"]}')
                    print(f'\033[{y+1};0H    {cl("k")}by {author}{A["0"]}')
            fx = sx + 2
            fy = 3
            print(f'\033[{fy};{fx}H{cl("c")}{" INFORMACION ":^{rw-2}}{A["0"]}')
            fy += 2
            if sel < len(fresults):
                m = fresults[sel]
                icon_url = m.get('icon', {}).get('url', '') if isinstance(m.get('icon'), dict) else ''
                if icon_url:
                    ilines = show_icon(icon_url, min(rw-4, 20), 5)
                    for line in ilines[:5]:
                        if fy >= cols.lines - 3:
                            break
                        print(f'\033[{fy};{fx}H{line:<{rw-2}}{A["0"]}')
                        fy += 1
                author2 = m.get('author', {})
                author2 = author2.get('name', str(author2.get('id', '?'))) if isinstance(author2, dict) else str(author2)
                print(f'\033[{fy};{fx}H {cl("y")}Autor:{A["0"]} {cl("k")}{author2:<{rw-10}}{A["0"]}')
                fy += 1
                tag = m.get('tag', '')
                if tag:
                    print(f'\033[{fy};{fx}H {cl("y")}Tag:{A["0"]} {cl("k")}{tag:<{rw-8}}{A["0"]}')
                    fy += 1
                desc = m.get('description', '')
                if desc:
                    for line in [desc[j:j+rw-4] for j in range(0, len(desc), rw-4)][:4]:
                        if fy >= cols.lines - 2:
                            break
                        print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                        fy += 1
            by = cols.lines - 1
            print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Versiones/Precio [Q] Volver [/] Buscar{A["0"]}')
            k = get_key()
            if k == 'up' and sel > 0:
                sel -= 1
            elif k == 'down' and sel < len(fresults) - 1:
                sel += 1
            elif k == '/':
                clear()
                draw_header(1, "SPIGOT", "Nueva busqueda")
                q2 = read_text(f'\033[{4};0H  {cl("g")}►{A["0"]} ')
                if q2 and q2.lower() != 'q':
                    q = q2
                    results = spigot_search(q)
                    if not results:
                        return
                    sel = 0
            elif k == 'enter':
                rid = fresults[sel].get('id', 0)
                rname = fresults[sel].get('name', '?')
                if rid:
                    spigot_versions_menu(rid, rname)
                    results = spigot_search(q)
                    if not results:
                        return
                    sel = 0
            elif k in ('q', 'esc'):
                return

def spigot_versions_menu(rid, title):
    cols = get_size()
    vers = spigot_versions(rid)
    if not vers:
        notify("No se pudieron cargar versiones", 'r')
        return
    tested = []
    res = spigot_resource(rid)
    if res:
        tested = res.get('testedVersions', [])
    lw = int(cols.columns * 0.65)
    rw = cols.columns - lw - 3
    sx = lw + 2
    sel = 0
    while True:
        fvers = vers
        if not fvers:
            notify("Sin versiones", 'r')
            return
        sel = min(sel, len(fvers)-1)
        clear()
        draw_header(1, f"VERSIONES: {title}", f"{len(fvers)} disponibles")
        for yy in range(3, cols.lines - 1):
            print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
        y = 3
        max_vis = (cols.lines - y - 1) // 2
        sc = max(0, min(sel - max_vis + 2, len(fvers) - max_vis)) if sel >= max_vis else 0
        visible = fvers[sc:sc+max_vis]
        for i, v in enumerate(visible):
            idx = sc + i
            vn = v.get('name', '?')
            rdate = v.get('releaseDate', 0)
            if rdate:
                import datetime as _dt
                rdate = _dt.datetime.fromtimestamp(rdate).strftime('%Y-%m-%d')
            else:
                rdate = ''
            label = f"{vn[:lw-10]}.." if len(vn) > lw - 10 else vn
            if y >= cols.lines - 1:
                break
            if idx == sel:
                print(f'\033[{y};0H  \033[7m {label:<{lw-5}} {A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H  \033[7m {cl("k")}{rdate:<{lw-12}}{A["0"]}\033[7m {A["0"]}')
            else:
                print(f'\033[{y};0H  {cl("p") if idx%2==0 else cl("c")}{label:<{lw-4}}{A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H    {cl("k")}{rdate}{A["0"]}')
            y += 1
        fx = sx + 2
        fy = 3
        print(f'\033[{fy};{fx}H{cl("c")}{" INFO ":^{rw-2}}{A["0"]}')
        fy += 2
        if sel < len(fvers):
            v = fvers[sel]
            print(f'\033[{fy};{fx}H {cl("y")}Version:{A["0"]} {cl("k")}{v.get("name","?"):<{rw-10}}{A["0"]}')
            fy += 1
            rid2 = v.get('id', rid)
            rd2 = v.get('releaseDate', 0)
            if rd2:
                import datetime as _dt
                rd2 = _dt.datetime.fromtimestamp(rd2).strftime('%Y-%m-%d')
            else:
                rd2 = '?'
            print(f'\033[{fy};{fx}H {cl("y")}Fecha:{A["0"]} {cl("k")}{rd2:<{rw-9}}{A["0"]}')
            fy += 1
            if tested:
                tv = ', '.join(tested)
                for tvl in [tv[j:j+rw-14] for j in range(0, len(tv), rw-14)][:2]:
                    print(f'\033[{fy};{fx}H {cl("y")}Testeado:{A["0"]} {cl("k")}{tvl:<{rw-12}}{A["0"]}')
                    fy += 1
            if res:
                sdesc = clean_spiget_desc(res.get('description', ''))
                if sdesc:
                    for sdl in [sdesc[j:j+rw-4] for j in range(0, len(sdesc), rw-4)][:3]:
                        if fy >= cols.lines - 2:
                            break
                        print(f'\033[{fy};{fx}H {cl("k")}{sdl:<{rw-2}}{A["0"]}')
                        fy += 1
        by = cols.lines - 1
        print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Instalar [Q] Volver{A["0"]}')
        k = get_key()
        if k == 'up' and sel > 0:
            sel -= 1
        elif k == 'down' and sel < len(fvers) - 1:
            sel += 1
        elif k == 'enter':
            vname = fvers[sel].get('name', '')
            md = os.path.join(CFG['server_dir'], 'plugins')
            os.makedirs(md, exist_ok=True)
            ok, fn = spigot_install(rid, vname, md)
            if ok:
                sz = os.path.getsize(os.path.join(md, fn))
                if sz >= 1048576:
                    szs = f"{sz/1048576:.1f}MB"
                elif sz >= 1024:
                    szs = f"{sz/1024:.0f}KB"
                else:
                    szs = f"{sz}B"
                notify(f"Instalado: {fn} ({szs})", 'g')
            else:
                notify(f"Error: {fn}", 'r')
            return
        elif k in ('q', 'esc'):
            return

def modrinth_browser():
    cols = get_size()
    while True:
        clear()
        draw_header(1, "MODRINTH", "Busca e instala mods")
        print(f'\033[{3};0H  {cl("c")}Buscar mods en Modrinth{cl("0")}')
        print(f'\033[{4};0H  {cl("k")}Escribe tu busqueda (o Q para volver):{A["0"]}')
        q = read_text(f'\033[{5};0H  {cl("g")}►{A["0"]} ')
        if not q or q.lower() == 'q':
            return
        results = mr_search(q)
        if not results:
            notify("Sin resultados o error de conexion", 'r')
            continue
        lw = int(cols.columns * 0.68)
        rw = cols.columns - lw - 3
        sx = lw + 2
        sel = 0
        filter_mc = ""
        filter_loader = "all"
        while True:
            fresults = results
            if filter_loader != "all":
                fresults = [r for r in fresults if filter_loader in r.get('categories', [])]
            if filter_mc:
                fresults = [r for r in fresults if filter_mc in str(r.get('versions', []))]
            if not fresults:
                notify("Sin coincidencias con filtros", 'r')
                filter_mc = ""
                filter_loader = "all"
                continue
            sel = min(sel, len(fresults)-1)
            clear()
            draw_header(1, f"RESULTADOS: {q}", f"{len(fresults)} mods")
            for yy in range(3, cols.lines - 1):
                print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
            max_vis = (cols.lines - 5) // 2
            sc = max(0, min(sel - max_vis + 2, len(fresults) - max_vis)) if sel >= max_vis else 0
            visible = fresults[sc:sc+max_vis]
            for i, m in enumerate(visible):
                idx = sc + i
                name = m.get('title', m.get('slug', '?'))
                author = m.get('author', '?')
                downloads = m.get('downloads', 0)
                dl_str = f"{downloads//1000}k" if downloads > 999 else str(downloads)
                cats = m.get('categories', [])
                loaders = [c for c in cats if c in ('fabric','forge','quilt','neoforge')]
                tags = [c for c in cats if c not in ('fabric','forge','quilt','neoforge')]
                y = 3 + i * 2
                if y + 1 >= cols.lines - 1:
                    break
                if idx == sel:
                    print(f'\033[{y};0H  \033[7m {cl("c")}{name:<{lw-7}}{A["0"]}\033[7m {cl("k")}{dl_str:>6}{A["0"]}\033[7m {A["0"]}')
                    ltag = " ".join(loaders[:2]) + ("  " + " ".join(tags[:2]) if tags else "")
                    print(f'\033[{y+1};0H  \033[7m {cl("k")}by {author}  {ltag:<{lw-12-len(author)}}{A["0"]}\033[7m {A["0"]}')
                else:
                    print(f'\033[{y};0H  {cl("g")}{name:<{lw-12}}{A["0"]} {cl("k")}{dl_str:>6}{A["0"]}')
                    ltag = " ".join(loaders[:2]) + ("  " + " ".join(tags[:2]) if tags else "")
                    print(f'\033[{y+1};0H    {cl("k")}by {author}  {ltag}{A["0"]}')
            fx = sx + 2
            fy = 3
            print(f'\033[{fy};{fx}H{cl("c")}{" FILTROS ":^{rw-2}}{A["0"]}')
            fy += 2
            mc_label = filter_mc or "Todas"
            print(f'\033[{fy};{fx}H{cl("y")}MC:{A["0"]} {cl("k")}[{mc_label:<{rw-8}}]{A["0"]}')
            fy += 1
            fl = filter_loader if filter_loader != "all" else "Cualquiera"
            print(f'\033[{fy};{fx}H{cl("y")}Loader:{A["0"]} {cl("k")}[{fl:<{rw-10}}]{A["0"]}')
            fy += 2
            all_loaders = set()
            for r in fresults:
                all_loaders.update(c for c in r.get('categories', []) if c in ('fabric','forge','quilt','neoforge'))
            if all_loaders:
                lstr = ", ".join(sorted(all_loaders))
                for line in [lstr[j:j+rw-4] for j in range(0, len(lstr), rw-4)][:2]:
                    if fy >= cols.lines - 6:
                        break
                    print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                    fy += 1
                fy += 1
            if sel < len(fresults):
                m = fresults[sel]
                print(f'\033[{fy};{fx}H{cl("c")}{" INFO ":^{rw-2}}{A["0"]}')
                fy += 1
                icon_url = m.get('icon_url', '')
                if icon_url:
                    ilines = show_icon(icon_url, min(rw-4, 20), 5)
                    for line in ilines[:5]:
                        if fy >= cols.lines - 3:
                            break
                        print(f'\033[{fy};{fx}H{line:<{rw-2}}{A["0"]}')
                        fy += 1
                print(f'\033[{fy};{fx}H {cl("y")}Autor:{A["0"]} {cl("k")}{m.get("author","?"):<{rw-10}}{A["0"]}')
                fy += 1
                desc = m.get('description', '')
                if desc:
                    for line in [desc[j:j+rw-4] for j in range(0, len(desc), rw-4)][:4]:
                        if fy >= cols.lines - 2:
                            break
                        print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                        fy += 1
            by = cols.lines - 1
            print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Versiones [Q] Volver [/] Buscar [F] Filtros{A["0"]}')
            k = get_key()
            if k == 'up' and sel > 0:
                sel -= 1
            elif k == 'down' and sel < len(fresults) - 1:
                sel += 1
            elif k == '/':
                clear()
                draw_header(1, "MODRINTH", "Nueva busqueda")
                q2 = read_text(f'\033[{4};0H  {cl("g")}►{A["0"]} ')
                if q2 and q2.lower() != 'q':
                    q = q2
                    results = mr_search(q)
                    if not results:
                        return
                    sel = 0
            elif k == 'f':
                clear()
                draw_header(1, "FILTROS", "")
                print(f'\033[{3};0H  {cl("c")}Version MC [Actual: {filter_mc or "Todas"}]:{A["0"]}')
                nm = read_text(f'\033[{4};0H  {cl("g")}►{A["0"]} ')
                if nm:
                    filter_mc = nm
                print(f'\033[{5};0H  {cl("c")}Loader [Actual: {filter_loader}]:{A["0"]}')
                print(f'\033[{6};0H  {cl("k")}all | fabric | forge | quilt | neoforge{A["0"]}')
                nl = read_text(f'\033[{7};0H  {cl("g")}►{A["0"]} ')
                if nl in ('all','fabric','forge','quilt','neoforge',''):
                    filter_loader = nl or "all"
                sel = 0
            elif k == 'enter':
                proj = fresults[sel]
                pid = proj.get('project_id', '')
                if pid:
                    modrinth_versions_menu(pid, proj.get('title', '?'))
                    results = mr_search(q)
                    if not results:
                        return
                    sel = 0
            elif k in ('q', 'esc'):
                return

def modrinth_versions_menu(proj_id, title):
    cols = get_size()
    vers = mr_versions(proj_id)
    if not vers:
        notify("No se pudieron cargar versiones", 'r')
        return
    proj = mr_project(proj_id)
    lw = int(cols.columns * 0.65)
    rw = cols.columns - lw - 3
    sx = lw + 2
    sel = 0
    filter_mc = CFG.get('server_version', '')
    filter_loader = "all"
    show_rel = False
    while True:
        fvers = vers
        if filter_mc:
            fvers = [v for v in fvers if filter_mc in v.get('game_versions', [])]
        if filter_loader != "all":
            fvers = [v for v in fvers if filter_loader in v.get('loaders', [])]
        if show_rel:
            fvers = [v for v in fvers if not re.search(r'alpha|beta|pre|snapshot|rc|dev', v.get('version_number',''), re.I)]
        if not fvers:
            notify("Sin coincidencias", 'r')
            if filter_mc:
                filter_mc = ""
                continue
            return
        sel = min(sel, len(fvers)-1)
        clear()
        draw_header(1, f"VERSIONES: {title}", f"{len(fvers)} disponibles")
        for yy in range(3, cols.lines - 1):
            print(f'\033[{yy};{sx}H{cl("k")}│{A["0"]}')
        y = 3
        print(f'\033[{y};0H  MC:{cl("k")}[{filter_mc or "Todas"}]{A["0"]}  {cl("y")}Loader:{cl("k")}[{filter_loader}]{A["0"]}  Rel:{cl("k")}[{"Si" if show_rel else "No"}]{A["0"]}')
        y += 2
        max_vis = (cols.lines - y - 1) // 2
        sc = max(0, min(sel - max_vis + 2, len(fvers) - max_vis)) if sel >= max_vis else 0
        visible = fvers[sc:sc+max_vis]
        for i, v in enumerate(visible):
            idx = sc + i
            vn = v.get('name', v.get('version_number', '?'))
            gv = v.get('game_versions', [])
            ld = v.get('loaders', [])
            gv_str = gv[0] if gv else "?"
            ld_str = ld[0] if ld else "?"
            label = f"{vn[:lw-8]}.." if len(vn) > lw - 8 else vn
            if y >= cols.lines - 1:
                break
            if idx == sel:
                print(f'\033[{y};0H  \033[7m {label:<{lw-5}} {A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H  \033[7m {cl("k")}MC:{gv_str}  {ld_str}{" "*(lw-12-len(gv_str)-len(ld_str))}{A["0"]}\033[7m {A["0"]}')
            else:
                print(f'\033[{y};0H  {cl("c") if idx%2==0 else cl("y")}{label:<{lw-4}}{A["0"]}')
                y += 1
                if y < cols.lines - 1:
                    print(f'\033[{y};0H    {cl("k")}MC:{gv_str}  {ld_str}{A["0"]}')
            y += 1
        fx = sx + 2
        fy = 3
        pname = proj.get('title', title)
        pdesc = proj.get('description', '')
        pauthor = proj.get('author', '?')
        pdownloads = proj.get('downloads', 0)
        picon = proj.get('icon_url', '')
        print(f'\033[{fy};{fx}H{cl("c")}{pname:<{rw-2}}{A["0"]}')
        fy += 1
        print(f'\033[{fy};{fx}H{cl("k")}by {pauthor}{A["0"]}')
        fy += 2
        dl_str = f"{pdownloads//1000}k" if pdownloads > 999 else str(pdownloads)
        print(f'\033[{fy};{fx}H{cl("y")}Descargas:{A["0"]} {cl("k")}{dl_str}{A["0"]}')
        fy += 2
        all_ld = set()
        for v in vers:
            all_ld.update(v.get('loaders', []))
        if all_ld:
            print(f'\033[{fy};{fx}H{cl("y")}Loaders:{A["0"]} {cl("k")}{", ".join(sorted(all_ld))[:rw-12]}{A["0"]}')
            fy += 2
        if pdesc:
            for line in [pdesc[j:j+rw-4] for j in range(0, len(pdesc), rw-4)][:8]:
                if fy >= cols.lines - 2:
                    break
                print(f'\033[{fy};{fx}H {cl("k")}{line:<{rw-2}}{A["0"]}')
                fy += 1
        by = cols.lines - 1
        print(f'\033[{by};0H  {cl("k")}[W/S] Navegar [Enter] Instalar [Q] Volver [M] MC [L] Loader [R] Release{A["0"]}')
        k = get_key()
        if k == 'up' and sel > 0:
            sel -= 1
        elif k == 'down' and sel < len(fvers) - 1:
            sel += 1
        elif k == 'm':
            goto(3, 0)
            print(f'  {cl("g")}Filtrar MC:{A["0"]} ', end='', flush=True)
            nm = ""
            while True:
                ch = os.read(0, 1).decode('utf-8', errors='replace')
                if ch == '\n':
                    break
                if ch == '\x7f':
                    nm = nm[:-1]
                    print('\b \b', end='', flush=True)
                else:
                    nm += ch
                    print(ch, end='', flush=True)
            if nm:
                filter_mc = nm
            sel = 0
        elif k == 'l':
            goto(3, 0)
            print(f'  {cl("g")}Loader (all/fabric/forge/quilt/neoforge):{A["0"]} ', end='', flush=True)
            nl = ""
            while True:
                ch = os.read(0, 1).decode('utf-8', errors='replace')
                if ch == '\n':
                    break
                if ch == '\x7f':
                    nl = nl[:-1]
                    print('\b \b', end='', flush=True)
                else:
                    nl += ch
                    print(ch, end='', flush=True)
            if nl in ('all','fabric','forge','quilt','neoforge',''):
                filter_loader = nl or "all"
            sel = 0
        elif k == 'r':
            show_rel = not show_rel
            sel = 0
        elif k == 'enter':
            vid = fvers[sel].get('id', '')
            if vid:
                md = os.path.join(CFG['server_dir'], 'mods')
                os.makedirs(md, exist_ok=True)
                ok, fn = mr_install(vid, md)
                if ok:
                    sz = os.path.getsize(os.path.join(md, fn))
                    if sz >= 1048576:
                        szs = f"{sz/1048576:.1f}MB"
                    elif sz >= 1024:
                        szs = f"{sz/1024:.0f}KB"
                    else:
                        szs = f"{sz}B"
                    notify(f"Instalado: {fn} ({szs})", 'g')
                else:
                    notify(f"Error: {fn}", 'r')
                return
        elif k in ('q', 'esc'):
            return